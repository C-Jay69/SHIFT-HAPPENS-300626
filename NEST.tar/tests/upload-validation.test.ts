/**
 * Phase 2 — Upload validation tests
 *
 * Per docs/SPEC.md §7: upload controls must validate authenticated user,
 * object ownership/path, MIME type, extension, file size, maximum image
 * dimensions, number of files. Do not trust the browser-provided MIME
 * type alone. Strip unnecessary image metadata, including EXIF.
 *
 * Per §37 Phase 2 acceptance: "Another owner cannot access the property's
 * private image paths." The path-shape validator (isValidPropertyPhotoPath)
 * is the first line of defense against path traversal / IDOR.
 */

import { describe, it, expect } from "vitest";
import {
  validateFileMetadata,
  validateFileBatch,
  isValidPropertyPhotoPath,
  MAX_UPLOAD_FILES,
  MAX_FILE_SIZE_BYTES,
  ALLOWED_MIME_TYPES,
  ALLOWED_EXTENSIONS,
} from "@/lib/storage/upload-validation";

describe("validateFileMetadata", () => {
  it("accepts a valid JPEG within size limit", () => {
    const r = validateFileMetadata({
      name: "photo.jpg",
      type: "image/jpeg",
      size: 1024 * 1024, // 1 MiB
    });
    expect(r.ok).toBe(true);
    expect(r.errors).toEqual([]);
  });

  it("accepts PNG and WebP", () => {
    expect(
      validateFileMetadata({ name: "p.png", type: "image/png", size: 1000 }).ok
    ).toBe(true);
    expect(
      validateFileMetadata({ name: "p.webp", type: "image/webp", size: 1000 }).ok
    ).toBe(true);
  });

  it("rejects GIF", () => {
    const r = validateFileMetadata({
      name: "p.gif",
      type: "image/gif",
      size: 1000,
    });
    expect(r.ok).toBe(false);
    expect(r.errors.some((e) => e.includes("disallowed"))).toBe(true);
  });

  it("rejects .exe even if MIME lies", () => {
    const r = validateFileMetadata({
      name: "malware.exe",
      type: "image/jpeg", // lying
      size: 1000,
    });
    expect(r.ok).toBe(false);
    expect(r.errors.some((e) => e.includes("disallowed extension"))).toBe(true);
  });

  it("rejects MIME type not matching extension (server-side sharp is the actual trust boundary)", () => {
    const r = validateFileMetadata({
      name: "photo.jpg",
      type: "application/octet-stream",
      size: 1000,
    });
    expect(r.ok).toBe(false);
    expect(r.errors.some((e) => e.includes("disallowed MIME"))).toBe(true);
  });

  it("rejects oversized files", () => {
    const r = validateFileMetadata({
      name: "huge.jpg",
      type: "image/jpeg",
      size: MAX_FILE_SIZE_BYTES + 1,
    });
    expect(r.ok).toBe(false);
    expect(r.errors.some((e) => e.includes("MiB"))).toBe(true);
  });

  it("rejects empty files", () => {
    const r = validateFileMetadata({
      name: "empty.jpg",
      type: "image/jpeg",
      size: 0,
    });
    expect(r.ok).toBe(false);
    expect(r.errors.some((e) => e.includes("empty"))).toBe(true);
  });

  it("accepts .jpeg (not just .jpg)", () => {
    const r = validateFileMetadata({
      name: "p.jpeg",
      type: "image/jpeg",
      size: 1000,
    });
    expect(r.ok).toBe(true);
  });
});

describe("validateFileBatch", () => {
  it("rejects empty batch", () => {
    const r = validateFileBatch([]);
    expect(r.ok).toBe(false);
  });

  it("rejects batch exceeding max file count", () => {
    const files = Array(MAX_UPLOAD_FILES + 1).fill(0).map((_, i) => ({
      name: `p${i}.jpg`,
      type: "image/jpeg",
      size: 1000,
    }));
    const r = validateFileBatch(files);
    expect(r.ok).toBe(false);
    expect(r.errors.some((e) => e.includes("Too many files"))).toBe(true);
  });

  it("aggregates errors across all files", () => {
    const files = [
      { name: "p1.jpg", type: "image/jpeg", size: 1000 },
      { name: "p2.gif", type: "image/gif", size: 1000 },
      { name: "p3.exe", type: "application/octet-stream", size: 1000 },
    ];
    const r = validateFileBatch(files);
    expect(r.ok).toBe(false);
    expect(r.errors.length).toBeGreaterThanOrEqual(2);
  });

  it("accepts a valid batch at the boundary", () => {
    const files = Array(MAX_UPLOAD_FILES).fill(0).map((_, i) => ({
      name: `p${i}.jpg`,
      type: "image/jpeg",
      size: 1000,
    }));
    const r = validateFileBatch(files);
    expect(r.ok).toBe(true);
  });
});

describe("isValidPropertyPhotoPath", () => {
  it("accepts the canonical path shape", () => {
    expect(
      isValidPropertyPhotoPath(
        "properties/abc12345-1234-1234-1234-123456789012/abcdef01-2345-6789-abcd-ef0123456789.jpg",
        "abc12345-1234-1234-1234-123456789012"
      )
    ).toBe(true);
  });

  it("accepts short UUIDs (no dashes)", () => {
    expect(
      isValidPropertyPhotoPath(
        "properties/abc12345-1234-1234-1234-123456789012/abcdef0123456789abcdef0123456789.jpg",
        "abc12345-1234-1234-1234-123456789012"
      )
    ).toBe(true);
  });

  it("rejects a path for a different propertyId (IDOR attempt)", () => {
    expect(
      isValidPropertyPhotoPath(
        "properties/different-id-1234-1234-123456789012/abcdef0123456789.jpg",
        "abc12345-1234-1234-1234-123456789012"
      )
    ).toBe(false);
  });

  it("rejects path traversal attempts", () => {
    expect(
      isValidPropertyPhotoPath(
        "properties/abc12345-1234-1234-1234-123456789012/../../../etc/passwd.jpg",
        "abc12345-1234-1234-1234-123456789012"
      )
    ).toBe(false);
    expect(
      isValidPropertyPhotoPath(
        "../properties/abc12345-1234-1234-1234-123456789012/file.jpg",
        "abc12345-1234-1234-1234-123456789012"
      )
    ).toBe(false);
  });

  it("rejects disallowed extensions", () => {
    expect(
      isValidPropertyPhotoPath(
        "properties/abc12345-1234-1234-1234-123456789012/abcdef.jpg.exe",
        "abc12345-1234-1234-1234-123456789012"
      )
    ).toBe(false);
  });

  it("rejects wrong bucket prefix", () => {
    expect(
      isValidPropertyPhotoPath(
        "inspections/abc12345-1234-1234-1234-123456789012/abcdef.jpg",
        "abc12345-1234-1234-1234-123456789012"
      )
    ).toBe(false);
  });

  it("rejects paths with wrong number of segments", () => {
    expect(
      isValidPropertyPhotoPath(
        "properties/abc12345-1234-1234-1234-123456789012.jpg",
        "abc12345-1234-1234-1234-123456789012"
      )
    ).toBe(false);
    expect(
      isValidPropertyPhotoPath(
        "properties/abc12345-1234-1234-1234-123456789012/subdir/abcdef.jpg",
        "abc12345-1234-1234-1234-123456789012"
      )
    ).toBe(false);
  });
});

describe("constants exported from upload-validation", () => {
  it("exports the expected defaults", () => {
    expect(MAX_UPLOAD_FILES).toBe(20);
    expect(MAX_FILE_SIZE_BYTES).toBe(10 * 1024 * 1024);
    expect(ALLOWED_MIME_TYPES).toEqual(["image/jpeg", "image/png", "image/webp"]);
    expect(ALLOWED_EXTENSIONS).toEqual([".jpg", ".jpeg", ".png", ".webp"]);
  });
});
