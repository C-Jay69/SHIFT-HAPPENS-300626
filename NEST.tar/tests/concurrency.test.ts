/**
 * Nest — Booking concurrency test
 *
 * Verifies the PostgreSQL exclusion constraint `no_double_booking`
 * prevents two simultaneous reservations for the same property/date range.
 *
 * Per docs/SPEC.md §5.3: "The database is the final authority. A
 * concurrency test must attempt multiple simultaneous reservations for
 * identical dates. Exactly one may succeed."
 *
 * Per docs/SPEC.md §28 Phase 3 acceptance: "ten concurrent attempts at
 * identical property dates result in exactly one reservation."
 *
 * Note: this test uses the SERVICE ROLE client to simulate the trusted
 * booking endpoint (POST /api/bookings) that would perform the INSERT.
 * RLS client inserts are deliberately blocked per 0002_rls.sql.
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

const SERVICE_URL = process.env.SUPABASE_URL!;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!;

if (!SERVICE_URL || !SERVICE_KEY) {
  throw new Error('Missing required env: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY');
}

let admin: SupabaseClient;
let propertyId: string;
let ownerId: string;
let guestIds: string[] = [];

beforeAll(async () => {
  admin = createClient(SERVICE_URL, SERVICE_KEY, {
    auth: { persistSession: false },
  });

  // 1. Create an owner + 10 guests via auth.admin
  const { data: ownerAuth } = await admin.auth.admin.createUser({
    email: `concurrency+owner@nest.local`,
    password: 'Nest-Test-2026!ccowner',
    email_confirm: true,
    user_metadata: { role: 'owner', full_name: 'CC Owner' },
  });
  ownerId = ownerAuth.user!.id;

  await admin.from('profiles').upsert({
    id: ownerId,
    email: 'concurrency+owner@nest.local',
    full_name: 'CC Owner',
    role: 'owner',
  }, { onConflict: 'id' });

  for (let i = 0; i < 10; i++) {
    const { data: g } = await admin.auth.admin.createUser({
      email: `concurrency+guest${i}@nest.local`,
      password: `Nest-Test-2026!ccg${i}`,
      email_confirm: true,
      user_metadata: { role: 'guest', full_name: `CC Guest ${i}` },
    });
    guestIds.push(g.user!.id);
    await admin.from('profiles').upsert({
      id: g.user!.id,
      email: `concurrency+guest${i}@nest.local`,
      full_name: `CC Guest ${i}`,
      role: 'guest',
    }, { onConflict: 'id' });
  }

  // 2. Create a listed property.
  const { data: prop } = await admin.from('properties').insert({
    owner_id: ownerId,
    title: 'Concurrency Test Property',
    base_price_minor: 10000,
    min_price_minor: 8000,
    max_price_minor: 15000,
    currency: 'USD',
    status: 'listed',
  }).select('id').single();
  propertyId = prop!.id;
}, 120_000);

afterAll(async () => {
  if (propertyId) await admin.from('properties').delete().eq('id', propertyId);
  for (const gid of guestIds) {
    try { await admin.auth.admin.deleteUser(gid); } catch {}
  }
  if (ownerId) {
    try { await admin.auth.admin.deleteUser(ownerId); } catch {}
  }
}, 120_000);

describe('booking concurrency — 10 simultaneous reservations for identical dates', () => {
  it('exactly one reservation may succeed', async () => {
    const checkin = '2027-07-01';
    const checkout = '2027-07-05';

    // Fire 10 parallel reservation attempts via the trusted-server role.
    const attempts = guestIds.map((guestId, i) =>
      admin.from('bookings').insert({
        property_id: propertyId,
        guest_id: guestId,
        owner_id: ownerId,
        checkin,
        checkout,
        guests_count: 1,
        per_night_rate_minor: 10000,
        nightly_subtotal_minor: 40000,
        cleaning_fee_minor: 5000,
        taxes_minor: 3000,
        total_amount_minor: 48000,
        currency: 'USD',
        status: 'reserved',
        cancellation_policy_key: 'moderate',
        cancellation_policy_version: 1,
      }).then(({ data, error }) => ({ ok: !error, error, data, guestIdx: i }))
    );

    const results = await Promise.allSettled(attempts);
    const fulfilled = results
      .filter((r) => r.status === 'fulfilled' && (r as any).value?.ok)
      .map((r) => (r as any).value);

    expect(fulfilled).toHaveLength(1);

    // Cleanup: delete the surviving booking so we don't leave state.
    if (fulfilled[0]?.data?.length) {
      await admin.from('bookings').delete().eq('id', fulfilled[0].data[0].id);
    }
  }, 60_000);
});

describe('booking concurrency — adjacent non-overlapping dates can coexist', () => {
  it('allows back-to-back reservations that do not overlap', async () => {
    // First booking: 2027-08-01 to 2027-08-05
    const { data: booking1, error: err1 } = await admin.from('bookings').insert({
      property_id: propertyId,
      guest_id: guestIds[0],
      owner_id: ownerId,
      checkin: '2027-08-01',
      checkout: '2027-08-05',
      guests_count: 1,
      per_night_rate_minor: 10000,
      nightly_subtotal_minor: 40000,
      cleaning_fee_minor: 5000,
      taxes_minor: 3000,
      total_amount_minor: 48000,
      currency: 'USD',
      status: 'reserved',
      cancellation_policy_key: 'moderate',
      cancellation_policy_version: 1,
    }).select('id').single();
    expect(err1).toBeNull();

    // Second booking: 2027-08-05 to 2027-08-09 (checkin = first checkout, half-open range)
    const { data: booking2, error: err2 } = await admin.from('bookings').insert({
      property_id: propertyId,
      guest_id: guestIds[1],
      owner_id: ownerId,
      checkin: '2027-08-05',
      checkout: '2027-08-09',
      guests_count: 1,
      per_night_rate_minor: 10000,
      nightly_subtotal_minor: 40000,
      cleaning_fee_minor: 5000,
      taxes_minor: 3000,
      total_amount_minor: 48000,
      currency: 'USD',
      status: 'reserved',
      cancellation_policy_key: 'moderate',
      cancellation_policy_version: 1,
    }).select('id').single();
    expect(err2).toBeNull();

    // Cleanup
    await admin.from('bookings').delete().in('id', [booking1!.id, booking2!.id]);
  }, 30_000);
});
