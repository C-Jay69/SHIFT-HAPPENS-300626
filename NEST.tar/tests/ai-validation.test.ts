/**
 * Nest — AI schema validation tests
 *
 * Per docs/SPEC.md §0 rule 3: "Every structured AI response must pass a Zod
 * schema before application code can use it. Never trust model-generated
 * JSON directly. Malformed responses must be retried or rejected safely."
 *
 * Per docs/SPEC.md §31: "Every AI result is treated as untrusted input
 * until validated."
 *
 * These tests pin the Zod schemas for vision analysis, host matching, and
 * dispute assessment. When the AI provider layer is implemented in Phase 2
 * (vision) and Phase 4/5 (matching/disputes), the schemas defined here
 * will be reused by `src/lib/ai/schemas.ts`.
 */

import { describe, it, expect } from 'vitest';
import { z } from 'zod';

// ─── Vision analysis schema (§9) ────────────────────────────────

const QualityTier = z.enum(['budget', 'mid_range', 'premium', 'luxury']);
const Confidence = z.enum(['low', 'medium', 'high']);
const AestheticVibe = z.enum([
  'modern_minimal',
  'scandinavian',
  'industrial',
  'bohemian',
  'coastal',
  'traditional',
  'mid_century',
  'rustic',
  'luxury',
  'other',
]);
const SizeBracket = z.enum(['studio', 'small', 'medium', 'large', 'estate']);
const LightingQuality = z.enum(['poor', 'fair', 'good', 'excellent']);

const VisionAnalysisSchema = z.object({
  quality_tier: QualityTier,
  condition_score: z.number().int().min(1).max(10),
  interior_modernity_score: z.number().int().min(1).max(10),
  curb_appeal_score: z.number().int().min(1).max(10),
  notable_features: z.array(z.string().max(80)).max(20),
  red_flags: z.array(z.string().max(80)).max(20),
  aesthetic_vibe: AestheticVibe,
  estimated_size_bracket: SizeBracket,
  lighting_quality: LightingQuality,
  visual_justification: z.string().max(2000),
  confidence: Confidence,
});

// ─── Host matching schema (§12) ─────────────────────────────────

const HostMatchSchema = z.object({
  score: z.number().min(0).max(100),
  strengths: z.array(z.string().max(300)).max(10),
  concerns: z.array(z.string().max(300)).max(10),
  reasoning: z.string().max(2000),
  recommendation: z.enum(['strong_fit', 'good_fit', 'marginal', 'not_recommended']),
});

// ─── Dispute assessment schema (§13) ───────────────────────────

const DisputeAssessmentSchema = z.object({
  damage_detected: z.boolean(),
  severity: z.enum(['none', 'minor', 'moderate', 'major', 'severe']),
  itemised_findings: z.array(z.object({
    description: z.string().max(500),
    confidence: z.enum(['low', 'medium', 'high']),
  })).max(30),
  evidence_quality: z.enum(['insufficient', 'limited', 'adequate', 'strong']),
  recommended_award_pct: z.number().min(0).max(100),
  rationale: z.string().max(3000),
  requires_human_review: z.boolean(),
});

// ─── Pricing refinement schema (§10 Layer 3) ───────────────────

const PricingRefinementSchema = z.object({
  adjustment_multiplier: z.number().min(0.5).max(2.0), // bounded — see §10 "clamp"
  confidence: z.enum(['low', 'medium', 'high']),
  rationale: z.string().max(2000),
  risk_factors: z.array(z.string().max(200)).max(10),
  reasoning_notes: z.string().max(3000),
});

describe('vision analysis schema', () => {
  it('accepts a well-formed vision response', () => {
    const valid = {
      quality_tier: 'premium',
      condition_score: 8,
      interior_modernity_score: 7,
      curb_appeal_score: 9,
      notable_features: ['ocean_view', 'pool', 'fireplace'],
      red_flags: [],
      aesthetic_vibe: 'modern_minimal',
      estimated_size_bracket: 'medium',
      lighting_quality: 'good',
      visual_justification: 'Bright coastal photos with consistent finishes.',
      confidence: 'high',
    };
    expect(VisionAnalysisSchema.safeParse(valid).success).toBe(true);
  });

  it('rejects condition_score above 10', () => {
    const invalid = {
      quality_tier: 'premium',
      condition_score: 11,
      interior_modernity_score: 7,
      curb_appeal_score: 9,
      notable_features: [],
      red_flags: [],
      aesthetic_vibe: 'modern_minimal',
      estimated_size_bracket: 'medium',
      lighting_quality: 'good',
      visual_justification: 'x',
      confidence: 'high',
    };
    expect(VisionAnalysisSchema.safeParse(invalid).success).toBe(false);
  });

  it('rejects unknown quality tier', () => {
    const invalid = {
      quality_tier: 'ultra_luxury', // not in enum
      condition_score: 8,
      interior_modernity_score: 7,
      curb_appeal_score: 9,
      notable_features: [],
      red_flags: [],
      aesthetic_vibe: 'modern_minimal',
      estimated_size_bracket: 'medium',
      lighting_quality: 'good',
      visual_justification: 'x',
      confidence: 'high',
    };
    expect(VisionAnalysisSchema.safeParse(invalid).success).toBe(false);
  });

  it('rejects too many notable_features', () => {
    const invalid = {
      quality_tier: 'premium',
      condition_score: 8,
      interior_modernity_score: 7,
      curb_appeal_score: 9,
      notable_features: Array(25).fill('x'),
      red_flags: [],
      aesthetic_vibe: 'modern_minimal',
      estimated_size_bracket: 'medium',
      lighting_quality: 'good',
      visual_justification: 'x',
      confidence: 'high',
    };
    expect(VisionAnalysisSchema.safeParse(invalid).success).toBe(false);
  });

  it('rejects empty visual_justification that exceeds 2000 chars', () => {
    const valid = {
      quality_tier: 'premium',
      condition_score: 8,
      interior_modernity_score: 7,
      curb_appeal_score: 9,
      notable_features: [],
      red_flags: [],
      aesthetic_vibe: 'modern_minimal',
      estimated_size_bracket: 'medium',
      lighting_quality: 'good',
      visual_justification: 'x'.repeat(2001),
      confidence: 'high',
    };
    expect(VisionAnalysisSchema.safeParse(valid).success).toBe(false);
  });
});

describe('host matching schema', () => {
  it('accepts a well-formed match response', () => {
    const valid = {
      score: 87.5,
      strengths: ['3 years local hosting experience', 'Top-rated guest reviews'],
      concerns: ['No experience with luxury properties'],
      reasoning: 'Strong fit for this mid-range property.',
      recommendation: 'good_fit',
    };
    expect(HostMatchSchema.safeParse(valid).success).toBe(true);
  });

  it('rejects score > 100', () => {
    const invalid = { score: 150, strengths: [], concerns: [], reasoning: 'x', recommendation: 'strong_fit' };
    expect(HostMatchSchema.safeParse(invalid).success).toBe(false);
  });

  it('rejects score < 0', () => {
    const invalid = { score: -5, strengths: [], concerns: [], reasoning: 'x', recommendation: 'strong_fit' };
    expect(HostMatchSchema.safeParse(invalid).success).toBe(false);
  });

  it('rejects unknown recommendation', () => {
    const invalid = { score: 80, strengths: [], concerns: [], reasoning: 'x', recommendation: 'perfect_fit' };
    expect(HostMatchSchema.safeParse(invalid).success).toBe(false);
  });
});

describe('dispute assessment schema', () => {
  it('accepts a well-formed assessment', () => {
    const valid = {
      damage_detected: true,
      severity: 'moderate',
      itemised_findings: [
        { description: 'Scratched coffee table', confidence: 'high' },
        { description: 'Stain on couch', confidence: 'medium' },
      ],
      evidence_quality: 'adequate',
      recommended_award_pct: 35,
      rationale: 'Visible damage on coffee table matches host claim.',
      requires_human_review: true,
    };
    expect(DisputeAssessmentSchema.safeParse(valid).success).toBe(true);
  });

  it('rejects recommended_award_pct > 100', () => {
    const invalid = {
      damage_detected: true,
      severity: 'moderate',
      itemised_findings: [],
      evidence_quality: 'adequate',
      recommended_award_pct: 150,
      rationale: 'x',
      requires_human_review: false,
    };
    expect(DisputeAssessmentSchema.safeParse(invalid).success).toBe(false);
  });

  it('rejects unknown severity', () => {
    const invalid = {
      damage_detected: true,
      severity: 'catastrophic',
      itemised_findings: [],
      evidence_quality: 'adequate',
      recommended_award_pct: 50,
      rationale: 'x',
      requires_human_review: false,
    };
    expect(DisputeAssessmentSchema.safeParse(invalid).success).toBe(false);
  });
});

describe('pricing refinement schema — AI multiplier must be bounded', () => {
  it('accepts multiplier inside [0.5, 2.0]', () => {
    const valid = {
      adjustment_multiplier: 1.15,
      confidence: 'high',
      rationale: 'High forward occupancy and weekend demand.',
      risk_factors: [],
      reasoning_notes: 'Saturday peak. AI suggests +15%.',
    };
    expect(PricingRefinementSchema.safeParse(valid).success).toBe(true);
  });

  it('rejects multiplier above 2.0 (out-of-range pricing multiplier)', () => {
    const invalid = {
      adjustment_multiplier: 3.5,
      confidence: 'high',
      rationale: 'x',
      risk_factors: [],
      reasoning_notes: 'x',
    };
    expect(PricingRefinementSchema.safeParse(invalid).success).toBe(false);
  });

  it('rejects multiplier below 0.5', () => {
    const invalid = {
      adjustment_multiplier: 0.1,
      confidence: 'high',
      rationale: 'x',
      risk_factors: [],
      reasoning_notes: 'x',
    };
    expect(PricingRefinementSchema.safeParse(invalid).success).toBe(false);
  });
});

describe('arbitrary remote image URL rejection — SSRF prevention', () => {
  it('the dispute assess endpoint must NOT accept arbitrary image URLs', () => {
    // Pseudocode assertion: the API contract requires the client to pass
    // booking_id + inspection kind. The server resolves the photo path
    // from authorized private storage, never from a user-supplied URL.
    type AssessRequest = {
      booking_id: string;
      kind: 'check_in' | 'check_out';
    };
    const sample: AssessRequest = { booking_id: 'b1', kind: 'check_in' };
    expect(typeof sample.booking_id).toBe('string');
    expect(['check_in', 'check_out']).toContain(sample.kind);
    // If a client tries to send image URLs, the request must be rejected
    // at the Zod schema layer before reaching the AI provider.
  });
});
