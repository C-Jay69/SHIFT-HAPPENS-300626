/**
 * Nest — Money arithmetic + payout reconciliation tests
 *
 * Per docs/SPEC.md §30 (Financial invariants):
 *   - settlement components reconcile to settlement base
 *   - refund amount never exceeds refundable amount
 *   - transfer amount never exceeds party's remaining unpaid entitlement
 *   - currency must match throughout a settlement
 *
 * Per docs/SPEC.md §3 (Configurable business policy):
 *   - Money must be integer minor currency units
 *   - Never use JS floating-point arithmetic for payment settlement
 *   - All payout percentages must be snapshotted onto booking/payout
 *     at transaction time
 */

import { describe, it, expect } from 'vitest';

// ─── money helpers ──────────────────────────────────────────────
// These are the Phase 1 reference implementations of the money
// utilities that src/lib/money.ts will expose in Phase 3.

type Minor = bigint;

function toMinor(amount: { dollars: number; cents: number }): Minor {
  if (amount.cents < 0 || amount.cents > 99) {
    throw new Error('cents out of range');
  }
  return BigInt(amount.dollars) * 100n + BigInt(amount.cents);
}

function fromMinor(m: Minor): { dollars: bigint; cents: bigint } {
  return { dollars: m / 100n, cents: m % 100n };
}

interface Split {
  ownerPct: number;       // 0–100, exact e.g. 82
  hostPct: number;        // 0–100, exact e.g. 15
  platformPct: number;   // 0–100, exact e.g. 3
}

/**
 * Deterministic settlement split.
 * Distributes the residual cents to the largest share first to guarantee
 * the three components always sum to exactly settlementBaseMinor.
 */
function settle(baseMinor: Minor, split: Split): {
  ownerMinor: Minor;
  hostMinor: Minor;
  platformMinor: Minor;
} {
  if (split.ownerPct < 0 || split.hostPct < 0 || split.platformPct < 0) {
    throw new Error('percentages must be non-negative');
  }
  const sum = split.ownerPct + split.hostPct + split.platformPct;
  if (Math.abs(sum - 100) > 0.0001) {
    throw new Error(`split must sum to 100, got ${sum}`);
  }

  const ownerRaw = (baseMinor * BigInt(Math.round(split.ownerPct * 10000))) / 1000000n;
  const hostRaw = (baseMinor * BigInt(Math.round(split.hostPct * 10000))) / 1000000n;
  const platformRaw = (baseMinor * BigInt(Math.round(split.platformPct * 10000))) / 1000000n;

  const computed = ownerRaw + hostRaw + platformRaw;
  const residual = baseMinor - computed;

  // Push residual onto the largest share.
  let ownerMinor = ownerRaw;
  let hostMinor = hostRaw;
  let platformMinor = platformRaw;

  if (residual !== 0n) {
    if (split.ownerPct >= split.hostPct && split.ownerPct >= split.platformPct) {
      ownerMinor += residual;
    } else if (split.hostPct >= split.platformPct) {
      hostMinor += residual;
    } else {
      platformMinor += residual;
    }
  }

  // Sanity check — this MUST always hold.
  if (ownerMinor + hostMinor + platformMinor !== baseMinor) {
    throw new Error('settlement components do not reconcile');
  }

  return { ownerMinor, hostMinor, platformMinor };
}

describe('money — integer minor units', () => {
  it('parses dollar+cent to minor units', () => {
    expect(toMinor({ dollars: 0, cents: 0 })).toBe(0n);
    expect(toMinor({ dollars: 1, cents: 0 })).toBe(100n);
    expect(toMinor({ dollars: 12, cents: 34 })).toBe(1234n);
    expect(toMinor({ dollars: 9999, cents: 99 })).toBe(999999n);
  });

  it('rejects cents outside 0–99', () => {
    expect(() => toMinor({ dollars: 1, cents: -1 })).toThrow();
    expect(() => toMinor({ dollars: 1, cents: 100 })).toThrow();
  });

  it('round-trips through fromMinor', () => {
    expect(fromMinor(0n)).toEqual({ dollars: 0n, cents: 0n });
    expect(fromMinor(1234n)).toEqual({ dollars: 12n, cents: 34n });
    expect(fromMinor(999999n)).toEqual({ dollars: 9999n, cents: 99n });
  });
});

describe('settle — 82/15/3 marketplace split', () => {
  it('exact reconciliation on round numbers', () => {
    // 570.00 USD settlement → owner 467.40, host 85.50, platform 17.10
    const base = toMinor({ dollars: 570, cents: 0 });
    const r = settle(base, { ownerPct: 82, hostPct: 15, platformPct: 3 });
    expect(r.ownerMinor).toBe(46740n);
    expect(r.hostMinor).toBe(8550n);
    expect(r.platformMinor).toBe(1710n);
    expect(r.ownerMinor + r.hostMinor + r.platformMinor).toBe(base);
  });

  it('reconciles when the base has cents that do not divide evenly', () => {
    // 100.01 USD settlement
    const base = toMinor({ dollars: 100, cents: 1 });
    const r = settle(base, { ownerPct: 82, hostPct: 15, platformPct: 3 });
    expect(r.ownerMinor + r.hostMinor + r.platformMinor).toBe(base);
    // owner gets the residual cent (largest share)
    expect(r.ownerMinor).toBe(8201n);
    expect(r.hostMinor).toBe(1500n);
    expect(r.platformMinor).toBe(300n);
  });

  it('throws when percentages do not sum to 100', () => {
    expect(() =>
      settle(100n, { ownerPct: 80, hostPct: 15, platformPct: 3 })
    ).toThrow();
  });

  it('throws when any percentage is negative', () => {
    expect(() =>
      settle(100n, { ownerPct: -1, hostPct: 98, platformPct: 3 })
    ).toThrow();
  });
});

describe('refund — never exceeds refundable amount', () => {
  it('allows partial refund below total', () => {
    const totalMinor = toMinor({ dollars: 570, cents: 0 });
    const refundMinor = toMinor({ dollars: 100, cents: 0 });
    expect(refundMinor).toBeLessThan(totalMinor);
    expect(refundMinor).toBeLessThanOrEqual(totalMinor);
  });

  it('rejects refund above total', () => {
    const totalMinor = toMinor({ dollars: 570, cents: 0 });
    const refundMinor = toMinor({ dollars: 600, cents: 0 });
    expect(refundMinor > totalMinor).toBe(true);
    // The DB constraint `booking_refund_not_above_total` enforces this at
    // the database layer; the application must check before issuing a
    // refund intent and never trust client-provided amounts.
  });
});

describe('currency — must match throughout a settlement', () => {
  it('throws if booking currency differs from payout currency', () => {
    function assertSameCurrency(a: string, b: string) {
      if (a !== b) throw new Error(`currency mismatch: ${a} vs ${b}`);
    }
    expect(() => assertSameCurrency('USD', 'EUR')).toThrow();
    expect(() => assertSameCurrency('USD', 'USD')).not.toThrow();
  });
});

describe('payout snapshot — percentages preserved at transaction time', () => {
  it('snapshots owner/host/platform percentages onto the payout row', () => {
    // Simulate creating a payout: the percentages are recorded verbatim,
    // so if platform_settings.revenue_split changes later, the historical
    // payout is unchanged.
    const snapshot = {
      owner_pct: 82,
      host_pct: 15,
      platform_pct: 3,
    };
    expect(snapshot.owner_pct + snapshot.host_pct + snapshot.platform_pct).toBe(100);
  });
});
