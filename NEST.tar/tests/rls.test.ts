/**
 * Nest — Adversarial RLS / authorization test matrix
 *
 * This suite exercises the negative-authorization invariants described in
 * docs/SPEC.md §29 and the §J Phase 1 prompt.
 *
 * Identity matrix:
 *   Alice    — owner
 *   Bob      — owner
 *   Hannah   — verified host
 *   George   — guest
 *   Grace    — second guest
 *   Adam     — admin
 *
 * Test identities are created via the Supabase auth.admin API (service-role)
 * in tests/helpers/users.ts and provisioned with the appropriate profile rows
 * before tests run.
 *
 * Run with:
 *   bun run test:rls
 *
 * Required env:
 *   SUPABASE_URL
 *   SUPABASE_SERVICE_ROLE_KEY
 *   SUPABASE_ANON_KEY
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  ensureTestUsers,
  teardownTestUsers,
  type TestUser,
} from './helpers/users';

const SERVICE_URL = process.env.SUPABASE_URL!;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const ANON_KEY = process.env.SUPABASE_ANON_KEY!;

if (!SERVICE_URL || !SERVICE_KEY || !ANON_KEY) {
  throw new Error(
    'Missing required env: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, SUPABASE_ANON_KEY'
  );
}

let admin: SupabaseClient;
let users: TestUsers;

interface TestUsers {
  alice: TestUser;   // owner
  bob: TestUser;     // owner
  hannah: TestUser;  // host, verified
  george: TestUser;  // guest
  grace: TestUser;   // guest
  adam: TestUser;    // admin
}

beforeAll(async () => {
  admin = createClient(SERVICE_URL, SERVICE_KEY, {
    auth: { persistSession: false },
  });
  users = (await ensureTestUsers(admin)) as TestUsers;
}, 120_000);

afterAll(async () => {
  if (users) await teardownTestUsers(admin, users);
}, 120_000);

describe('profiles — self-promotion to admin is blocked', () => {
  it('Hannah cannot change her own role to admin via direct UPDATE', async () => {
    const { client } = users.hannah;
    const { error } = await client
      .from('profiles')
      .update({ role: 'admin' })
      .eq('id', users.hannah.id);

    expect(error).not.toBeNull();

    // Even if the call did not error, the row should be unchanged.
    const { data } = await admin
      .from('profiles')
      .select('role')
      .eq('id', users.hannah.id)
      .single();
    expect(data?.role).toBe('host');
  });

  it('Hannah cannot change her own KYC status via direct UPDATE', async () => {
    const { client } = users.hannah;
    const { error } = await client
      .from('profiles')
      .update({ kyc_status: 'verified' })
      .eq('id', users.hannah.id);

    expect(error).not.toBeNull();
  });

  it('George cannot self-verify KYC', async () => {
    const { client } = users.george;
    const { error } = await client
      .from('profiles')
      .update({ kyc_status: 'verified', kyc_verified_at: new Date().toISOString() })
      .eq('id', users.george.id);
    expect(error).not.toBeNull();
  });

  it('Hannah can update safe profile fields via the update_my_profile() RPC', async () => {
    const { client } = users.hannah;
    const { data, error } = await client.rpc('update_my_profile', {
      p_full_name: 'Hannah Updated',
      p_avatar_path: null,
      p_location_json: { city: 'Portland' },
      p_bio: 'Local host with hospitality experience.',
    });
    expect(error).toBeNull();
    expect(data?.full_name).toBe('Hannah Updated');
  });
});

describe('properties — cross-owner access blocked', () => {
  it("Alice can read Alice's draft property", async () => {
    const { client } = users.alice;
    const { data, error } = await client
      .from('properties')
      .select('id, title, status')
      .eq('owner_id', users.alice.id);
    expect(error).toBeNull();
    expect(Array.isArray(data)).toBe(true);
  });

  it("Bob cannot read Alice's draft property (drafts are owner-only)", async () => {
    const { client: aliceClient } = users.alice;
    const { data: aliceProps } = await aliceClient
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Alice draft',
        base_price_minor: 5000,
        min_price_minor: 4000,
        max_price_minor: 8000,
        currency: 'USD',
        status: 'draft',
      })
      .select('id')
      .single();
    expect(aliceProps).not.toBeNull();
    const draftId = aliceProps!.id;

    const { client: bobClient } = users.bob;
    const { data, error } = await bobClient
      .from('properties')
      .select('id, title')
      .eq('id', draftId)
      .single();

    // Either error or no rows — Bob must not see Alice's draft.
    expect(error || data === null).toBeTruthy();

    // Cleanup
    await admin.from('properties').delete().eq('id', draftId);
  });

  it('Anonymous cannot read draft property', async () => {
    const anon = createClient(SERVICE_URL, ANON_KEY, {
      auth: { persistSession: false },
    });
    const { client: aliceClient } = users.alice;
    const { data: aliceProps } = await aliceClient
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Alice draft 2',
        base_price_minor: 5000,
        min_price_minor: 4000,
        max_price_minor: 8000,
        currency: 'USD',
        status: 'draft',
      })
      .select('id')
      .single();
    const draftId = aliceProps!.id;

    const { data, error } = await anon
      .from('properties')
      .select('id, title')
      .eq('id', draftId)
      .single();

    expect(error || data === null).toBeTruthy();

    await admin.from('properties').delete().eq('id', draftId);
  });

  it('Alice cannot forge vision_analysis via direct UPDATE', async () => {
    const { client } = users.alice;
    const { data: prop } = await client
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Vision test',
        base_price_minor: 5000,
        min_price_minor: 4000,
        max_price_minor: 8000,
        currency: 'USD',
        status: 'draft',
      })
      .select('id')
      .single();
    expect(prop).not.toBeNull();

    const { error } = await client
      .from('properties')
      .update({
        vision_analysis: { fake: true },
        vision_status: 'complete',
        vision_model: 'forged-model',
      })
      .eq('id', prop!.id);

    expect(error).not.toBeNull();

    await admin.from('properties').delete().eq('id', prop!.id);
  });

  it('Alice cannot forge assigned_host_id via direct UPDATE', async () => {
    const { client } = users.alice;
    const { data: prop } = await client
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Assign test',
        base_price_minor: 5000,
        min_price_minor: 4000,
        max_price_minor: 8000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { error } = await client
      .from('properties')
      .update({ assigned_host_id: users.hannah.id })
      .eq('id', prop!.id);

    expect(error).not.toBeNull();

    await admin.from('properties').delete().eq('id', prop!.id);
  });
});

describe('bookings — guests cannot tamper', () => {
  it("George can read George's booking", async () => {
    // Booking creation must go through server endpoint, so for this test
    // we use the admin client to seed one, then check George can read it.
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Booking test prop',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { data: booking } = await admin.from('bookings').insert({
      property_id: aliceProp!.id,
      guest_id: users.george.id,
      owner_id: users.alice.id,
      checkin: '2026-09-01',
      checkout: '2026-09-05',
      guests_count: 1,
      per_night_rate_minor: 12000,
      nightly_subtotal_minor: 48000,
      cleaning_fee_minor: 5000,
      taxes_minor: 4000,
      total_amount_minor: 57000,
      currency: 'USD',
      status: 'reserved',
      cancellation_policy_key: 'moderate',
      cancellation_policy_version: 1,
    }).select('id').single();

    const { client: georgeClient } = users.george;
    const { data, error } = await georgeClient
      .from('bookings')
      .select('id, total_amount_minor, status')
      .eq('id', booking!.id)
      .single();
    expect(error).toBeNull();
    expect(data?.id).toBe(booking!.id);

    await admin.from('bookings').delete().eq('id', booking!.id);
    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });

  it("Grace cannot read George's booking", async () => {
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Booking privacy test',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { data: booking } = await admin.from('bookings').insert({
      property_id: aliceProp!.id,
      guest_id: users.george.id,
      owner_id: users.alice.id,
      checkin: '2026-10-01',
      checkout: '2026-10-05',
      guests_count: 1,
      per_night_rate_minor: 12000,
      nightly_subtotal_minor: 48000,
      cleaning_fee_minor: 5000,
      taxes_minor: 4000,
      total_amount_minor: 57000,
      currency: 'USD',
      status: 'reserved',
      cancellation_policy_key: 'moderate',
      cancellation_policy_version: 1,
    }).select('id').single();

    const { client: graceClient } = users.grace;
    const { data, error } = await graceClient
      .from('bookings')
      .select('id')
      .eq('id', booking!.id)
      .single();

    expect(error || data === null).toBeTruthy();

    await admin.from('bookings').delete().eq('id', booking!.id);
    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });

  it('George cannot alter booking.total_amount_minor directly', async () => {
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Amount tamper test',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { data: booking } = await admin.from('bookings').insert({
      property_id: aliceProp!.id,
      guest_id: users.george.id,
      owner_id: users.alice.id,
      checkin: '2026-11-01',
      checkout: '2026-11-05',
      guests_count: 1,
      per_night_rate_minor: 12000,
      nightly_subtotal_minor: 48000,
      cleaning_fee_minor: 5000,
      taxes_minor: 4000,
      total_amount_minor: 57000,
      currency: 'USD',
      status: 'reserved',
      cancellation_policy_key: 'moderate',
      cancellation_policy_version: 1,
    }).select('id').single();

    const { client: georgeClient } = users.george;
    const { error } = await georgeClient
      .from('bookings')
      .update({ total_amount_minor: 1 })
      .eq('id', booking!.id);

    expect(error).not.toBeNull();

    await admin.from('bookings').delete().eq('id', booking!.id);
    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });

  it('George cannot alter booking.status directly', async () => {
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Status tamper test',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { data: booking } = await admin.from('bookings').insert({
      property_id: aliceProp!.id,
      guest_id: users.george.id,
      owner_id: users.alice.id,
      checkin: '2026-12-01',
      checkout: '2026-12-05',
      guests_count: 1,
      per_night_rate_minor: 12000,
      nightly_subtotal_minor: 48000,
      cleaning_fee_minor: 5000,
      taxes_minor: 4000,
      total_amount_minor: 57000,
      currency: 'USD',
      status: 'reserved',
      cancellation_policy_key: 'moderate',
      cancellation_policy_version: 1,
    }).select('id').single();

    const { client: georgeClient } = users.george;
    const { error } = await georgeClient
      .from('bookings')
      .update({ status: 'completed' })
      .eq('id', booking!.id);

    expect(error).not.toBeNull();

    await admin.from('bookings').delete().eq('id', booking!.id);
    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });

  it('Alice (owner) cannot alter booking.total_amount_minor directly', async () => {
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Owner tamper test',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { data: booking } = await admin.from('bookings').insert({
      property_id: aliceProp!.id,
      guest_id: users.george.id,
      owner_id: users.alice.id,
      checkin: '2027-01-01',
      checkout: '2027-01-05',
      guests_count: 1,
      per_night_rate_minor: 12000,
      nightly_subtotal_minor: 48000,
      cleaning_fee_minor: 5000,
      taxes_minor: 4000,
      total_amount_minor: 57000,
      currency: 'USD',
      status: 'reserved',
      cancellation_policy_key: 'moderate',
      cancellation_policy_version: 1,
    }).select('id').single();

    const { client: aliceClient } = users.alice;
    const { error } = await aliceClient
      .from('bookings')
      .update({ total_amount_minor: 1 })
      .eq('id', booking!.id);

    expect(error).not.toBeNull();

    await admin.from('bookings').delete().eq('id', booking!.id);
    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });
});

describe('host applications — KYC gate + AI score tampering', () => {
  it('Hannah (verified host) can insert an application', async () => {
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'App test prop',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { client: hannahClient } = users.hannah;
    const { error } = await hannahClient.from('host_applications').insert({
      property_id: aliceProp!.id,
      host_id: users.hannah.id,
      proposed_fee_pct: 12,
      pitch_text: 'I have 3 years of short-term rental experience.',
    });
    expect(error).toBeNull();

    await admin.from('host_applications').delete().eq('property_id', aliceProp!.id);
    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });

  it('George (guest, not host) cannot insert an application', async () => {
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Guest app test prop',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { client: georgeClient } = users.george;
    const { error } = await georgeClient.from('host_applications').insert({
      property_id: aliceProp!.id,
      host_id: users.george.id,
      proposed_fee_pct: 12,
      pitch_text: 'I should not be able to apply.',
    });
    expect(error).not.toBeNull();

    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });

  it('Hannah cannot set ai_match_score on her own application', async () => {
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'AI score test prop',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { client: hannahClient } = users.hannah;
    const { data: app } = await hannahClient.from('host_applications').insert({
      property_id: aliceProp!.id,
      host_id: users.hannah.id,
      proposed_fee_pct: 12,
      pitch_text: 'Score tamper test.',
    }).select('id').single();

    const { error } = await hannahClient
      .from('host_applications')
      .update({ ai_match_score: 99.5, ai_match_reasoning: 'forged', ai_model: 'fake' })
      .eq('id', app!.id);

    expect(error).not.toBeNull();

    await admin.from('host_applications').delete().eq('id', app!.id);
    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });

  it("Alice can see applications to her property; Bob cannot", async () => {
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Visibility test prop',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { client: hannahClient } = users.hannah;
    await hannahClient.from('host_applications').insert({
      property_id: aliceProp!.id,
      host_id: users.hannah.id,
      proposed_fee_pct: 12,
      pitch_text: 'Visibility test.',
    });

    const { client: aliceClient } = users.alice;
    const { data: aliceApps, error: aliceErr } = await aliceClient
      .from('host_applications')
      .select('id')
      .eq('property_id', aliceProp!.id);
    expect(aliceErr).toBeNull();
    expect(aliceApps?.length).toBe(1);

    const { client: bobClient } = users.bob;
    const { data: bobApps, error: bobErr } = await bobClient
      .from('host_applications')
      .select('id')
      .eq('property_id', aliceProp!.id);
    expect(bobErr || (bobApps?.length ?? 0) === 0).toBeTruthy();

    await admin.from('host_applications').delete().eq('property_id', aliceProp!.id);
    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });
});

describe('payouts — party read, nobody writes', () => {
  it('Owner can read her payout', async () => {
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Payout read test',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { data: booking } = await admin.from('bookings').insert({
      property_id: aliceProp!.id,
      guest_id: users.george.id,
      owner_id: users.alice.id,
      checkin: '2027-02-01',
      checkout: '2027-02-05',
      guests_count: 1,
      per_night_rate_minor: 12000,
      nightly_subtotal_minor: 48000,
      cleaning_fee_minor: 5000,
      taxes_minor: 4000,
      total_amount_minor: 57000,
      currency: 'USD',
      status: 'reserved',
      cancellation_policy_key: 'moderate',
      cancellation_policy_version: 1,
    }).select('id').single();

    const { data: payout } = await admin.from('payouts').insert({
      booking_id: booking!.id,
      owner_id: users.alice.id,
      host_id: users.hannah.id,
      settlement_base_minor: 57000,
      owner_amount_minor: 46740,
      host_amount_minor: 8550,
      platform_amount_minor: 1710,
      owner_pct_snapshot: 82,
      host_pct_snapshot: 15,
      platform_pct_snapshot: 3,
      currency: 'USD',
      status: 'held',
      releasable_at: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
    }).select('id').single();

    const { client: aliceClient } = users.alice;
    const { data, error } = await aliceClient
      .from('payouts')
      .select('id, owner_amount_minor')
      .eq('id', payout!.id)
      .single();
    expect(error).toBeNull();
    expect(data?.id).toBe(payout!.id);

    await admin.from('payouts').delete().eq('id', payout!.id);
    await admin.from('bookings').delete().eq('id', booking!.id);
    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });

  it('Guest cannot read payout', async () => {
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Payout privacy test',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { data: booking } = await admin.from('bookings').insert({
      property_id: aliceProp!.id,
      guest_id: users.george.id,
      owner_id: users.alice.id,
      checkin: '2027-03-01',
      checkout: '2027-03-05',
      guests_count: 1,
      per_night_rate_minor: 12000,
      nightly_subtotal_minor: 48000,
      cleaning_fee_minor: 5000,
      taxes_minor: 4000,
      total_amount_minor: 57000,
      currency: 'USD',
      status: 'reserved',
      cancellation_policy_key: 'moderate',
      cancellation_policy_version: 1,
    }).select('id').single();

    const { data: payout } = await admin.from('payouts').insert({
      booking_id: booking!.id,
      owner_id: users.alice.id,
      host_id: users.hannah.id,
      settlement_base_minor: 57000,
      owner_amount_minor: 46740,
      host_amount_minor: 8550,
      platform_amount_minor: 1710,
      owner_pct_snapshot: 82,
      host_pct_snapshot: 15,
      platform_pct_snapshot: 3,
      currency: 'USD',
      status: 'held',
      releasable_at: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
    }).select('id').single();

    const { client: georgeClient } = users.george;
    const { data, error } = await georgeClient
      .from('payouts')
      .select('id')
      .eq('id', payout!.id)
      .single();

    expect(error || data === null).toBeTruthy();

    await admin.from('payouts').delete().eq('id', payout!.id);
    await admin.from('bookings').delete().eq('id', booking!.id);
    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });

  it('Owner cannot alter payout owner_amount_minor directly', async () => {
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Payout tamper test',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { data: booking } = await admin.from('bookings').insert({
      property_id: aliceProp!.id,
      guest_id: users.george.id,
      owner_id: users.alice.id,
      checkin: '2027-04-01',
      checkout: '2027-04-05',
      guests_count: 1,
      per_night_rate_minor: 12000,
      nightly_subtotal_minor: 48000,
      cleaning_fee_minor: 5000,
      taxes_minor: 4000,
      total_amount_minor: 57000,
      currency: 'USD',
      status: 'reserved',
      cancellation_policy_key: 'moderate',
      cancellation_policy_version: 1,
    }).select('id').single();

    const { data: payout } = await admin.from('payouts').insert({
      booking_id: booking!.id,
      owner_id: users.alice.id,
      host_id: users.hannah.id,
      settlement_base_minor: 57000,
      owner_amount_minor: 46740,
      host_amount_minor: 8550,
      platform_amount_minor: 1710,
      owner_pct_snapshot: 82,
      host_pct_snapshot: 15,
      platform_pct_snapshot: 3,
      currency: 'USD',
      status: 'held',
      releasable_at: new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
    }).select('id').single();

    const { client: aliceClient } = users.alice;
    const { error } = await aliceClient
      .from('payouts')
      .update({ owner_amount_minor: 99999 })
      .eq('id', payout!.id);

    expect(error).not.toBeNull();

    await admin.from('payouts').delete().eq('id', payout!.id);
    await admin.from('bookings').delete().eq('id', booking!.id);
    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });
});

describe('disputes — party read, no AI/admin field tampering', () => {
  it('Dispute party can read; unrelated user cannot', async () => {
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Dispute visibility test',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { data: booking } = await admin.from('bookings').insert({
      property_id: aliceProp!.id,
      guest_id: users.george.id,
      owner_id: users.alice.id,
      checkin: '2027-05-01',
      checkout: '2027-05-05',
      guests_count: 1,
      per_night_rate_minor: 12000,
      nightly_subtotal_minor: 48000,
      cleaning_fee_minor: 5000,
      taxes_minor: 4000,
      total_amount_minor: 57000,
      currency: 'USD',
      status: 'completed',
      cancellation_policy_key: 'moderate',
      cancellation_policy_version: 1,
    }).select('id').single();

    // Note: bookings_party_select requires status in a state visible to all parties.
    // Use service role to insert dispute (claimant = George, respondent = Alice).
    const { data: dispute } = await admin.from('disputes').insert({
      booking_id: booking!.id,
      claimant_id: users.george.id,
      respondent_id: users.alice.id,
      amount_claimed_minor: 5000,
      description: 'Broken furniture claim.',
    }).select('id').single();

    const { client: georgeClient } = users.george;
    const { data: georgeRead, error: georgeErr } = await georgeClient
      .from('disputes')
      .select('id')
      .eq('id', dispute!.id)
      .single();
    expect(georgeErr).toBeNull();
    expect(georgeRead?.id).toBe(dispute!.id);

    const { client: graceClient } = users.grace;
    const { data: graceRead, error: graceErr } = await graceClient
      .from('disputes')
      .select('id')
      .eq('id', dispute!.id)
      .single();
    expect(graceErr || graceRead === null).toBeTruthy();

    await admin.from('disputes').delete().eq('id', dispute!.id);
    await admin.from('bookings').delete().eq('id', booking!.id);
    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });

  it('Neither claimant nor respondent can alter ai_assessment', async () => {
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'AI tamper test',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { data: booking } = await admin.from('bookings').insert({
      property_id: aliceProp!.id,
      guest_id: users.george.id,
      owner_id: users.alice.id,
      checkin: '2027-06-01',
      checkout: '2027-06-05',
      guests_count: 1,
      per_night_rate_minor: 12000,
      nightly_subtotal_minor: 48000,
      cleaning_fee_minor: 5000,
      taxes_minor: 4000,
      total_amount_minor: 57000,
      currency: 'USD',
      status: 'completed',
      cancellation_policy_key: 'moderate',
      cancellation_policy_version: 1,
    }).select('id').single();

    const { data: dispute } = await admin.from('disputes').insert({
      booking_id: booking!.id,
      claimant_id: users.george.id,
      respondent_id: users.alice.id,
      amount_claimed_minor: 5000,
      description: 'Tamper test.',
    }).select('id').single();

    const { client: georgeClient } = users.george;
    const { error: georgeErr } = await georgeClient
      .from('disputes')
      .update({ ai_assessment: { forged: true } })
      .eq('id', dispute!.id);
    expect(georgeErr).not.toBeNull();

    const { client: aliceClient } = users.alice;
    const { error: aliceErr } = await aliceClient
      .from('disputes')
      .update({ admin_award_claimant_minor: 99999 })
      .eq('id', dispute!.id);
    expect(aliceErr).not.toBeNull();

    await admin.from('disputes').delete().eq('id', dispute!.id);
    await admin.from('bookings').delete().eq('id', booking!.id);
    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });
});

describe('sensitive machine-only tables are write-blocked for clients', () => {
  it('Ordinary user cannot read processed_webhook_events', async () => {
    const { client: georgeClient } = users.george;
    const { data, error } = await georgeClient
      .from('processed_webhook_events')
      .select('id')
      .limit(1);
    expect(error || (data?.length ?? 0) === 0).toBeTruthy();
  });

  it('Ordinary user cannot write audit_logs', async () => {
    const { client: georgeClient } = users.george;
    const { error } = await georgeClient.from('audit_logs').insert({
      actor_id: users.george.id,
      action: 'forged_event',
    });
    expect(error).not.toBeNull();
  });

  it('Ordinary user cannot alter platform_settings', async () => {
    const { client: georgeClient } = users.george;
    const { error } = await georgeClient
      .from('platform_settings')
      .update({ value_json: { forged: true } })
      .eq('key', 'revenue_split');
    expect(error).not.toBeNull();
  });

  it('Ordinary user cannot read platform_settings', async () => {
    const { client: georgeClient } = users.george;
    const { data, error } = await georgeClient
      .from('platform_settings')
      .select('key');
    expect(error || (data?.length ?? 0) === 0).toBeTruthy();
  });

  it('Ordinary user cannot insert kyc_verifications', async () => {
    const { client: georgeClient } = users.george;
    const { error } = await georgeClient.from('kyc_verifications').insert({
      user_id: users.george.id,
      provider: 'stripe-identity',
      status: 'verified',
    });
    expect(error).not.toBeNull();
  });

  it('Ordinary user cannot insert into pricing_signals', async () => {
    const { data: aliceProp } = await admin
      .from('properties')
      .insert({
        owner_id: users.alice.id,
        title: 'Signal tamper test',
        base_price_minor: 12000,
        min_price_minor: 10000,
        max_price_minor: 20000,
        currency: 'USD',
        status: 'listed',
      })
      .select('id')
      .single();

    const { client: georgeClient } = users.george;
    const { error } = await georgeClient.from('pricing_signals').insert({
      property_id: aliceProp!.id,
      signal_date: '2027-01-01',
      signal_type: 'forged',
    });
    expect(error).not.toBeNull();

    await admin.from('properties').delete().eq('id', aliceProp!.id);
  });
});
