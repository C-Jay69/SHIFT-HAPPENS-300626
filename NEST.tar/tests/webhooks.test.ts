/**
 * Nest — Stripe webhook idempotency test
 *
 * Per docs/SPEC.md §5.13:
 *   "Every Stripe webhook must:
 *     verify the Stripe signature,
 *     identify the event,
 *     check whether it was already processed,
 *     process it inside an idempotent transaction,
 *     record successful processing.
 *     Duplicate delivery must return success without performing the
 *     financial operation again."
 *
 * Per docs/SPEC.md §28 Phase 3 acceptance:
 *   "Duplicate Stripe webhook delivery results in exactly one state
 *    transition / financial effect."
 *
 * This is a unit test for the idempotency record layer
 * (processed_webhook_events) plus a behavioural test for the
 * /api/webhooks/stripe handler. The handler itself is implemented
 * in Phase 3; here we test the idempotency record layer + the helper
 * that determines whether an event has already been processed.
 */

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

const SERVICE_URL = process.env.SUPABASE_URL!;
const SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!;

if (!SERVICE_URL || !SERVICE_KEY) {
  throw new Error('Missing required env: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY');
}

let admin: SupabaseClient;

beforeAll(async () => {
  admin = createClient(SERVICE_URL, SERVICE_KEY, {
    auth: { persistSession: false },
  });
});

/**
 * Simulates the idempotency record pattern from the (Phase 3) webhook handler.
 * The real handler will:
 *   1. INSERT into processed_webhook_events with status='processing'.
 *   2. If unique violation → another worker is processing OR already processed.
 *      Read the row to check; if 'processed', return 200 OK without re-running.
 *   3. Otherwise, process the event inside a transaction.
 *   4. UPDATE status='processed' at the end.
 */
async function recordWebhookEvent(params: {
  provider: string;
  eventId: string;
  eventType: string;
  payloadHash: string;
}): Promise<{ inserted: boolean; existingStatus: string | null }> {
  const { data, error } = await admin.from('processed_webhook_events').insert({
    provider: params.provider,
    event_id: params.eventId,
    event_type: params.eventType,
    payload_hash: params.payloadHash,
    processing_status: 'processing',
  }).select('id').single();

  if (error) {
    // Unique violation — event already seen. Read existing status.
    if (error.code === '23505') {
      const { data: existing } = await admin
        .from('processed_webhook_events')
        .select('processing_status')
        .eq('provider', params.provider)
        .eq('event_id', params.eventId)
        .single();
      return { inserted: false, existingStatus: existing?.processing_status ?? null };
    }
    throw error;
  }

  // Simulate processing then mark processed.
  await admin.from('processed_webhook_events')
    .update({ processing_status: 'processed', processed_at: new Date().toISOString() })
    .eq('id', data!.id);

  return { inserted: true, existingStatus: null };
}

describe('processed_webhook_events — unique constraint', () => {
  it('inserts the first event with status=processing then upgraded to processed', async () => {
    const eventId = `evt_test_${Date.now()}`;
    const r1 = await recordWebhookEvent({
      provider: 'stripe',
      eventId,
      eventType: 'payment_intent.succeeded',
      payloadHash: 'hash-1',
    });
    expect(r1.inserted).toBe(true);

    // Cleanup
    await admin.from('processed_webhook_events')
      .delete()
      .eq('provider', 'stripe')
      .eq('event_id', eventId);
  });

  it('rejects the second insert with same (provider, event_id) and reports existing status', async () => {
    const eventId = `evt_dup_${Date.now()}`;
    await recordWebhookEvent({
      provider: 'stripe',
      eventId,
      eventType: 'payment_intent.succeeded',
      payloadHash: 'hash-2',
    });

    const r2 = await recordWebhookEvent({
      provider: 'stripe',
      eventId,
      eventType: 'payment_intent.succeeded',
      payloadHash: 'hash-2',
    });
    expect(r2.inserted).toBe(false);
    expect(r2.existingStatus).toBe('processed');

    await admin.from('processed_webhook_events')
      .delete()
      .eq('provider', 'stripe')
      .eq('event_id', eventId);
  });

  it('out-of-order delivery: late payment_intent.succeeded after cancellation finalized does not resurrect booking', async () => {
    /**
     * This test simulates the Phase 3 behaviour described in
     * docs/SPEC.md §16: "State transitions must be validated against
     * current database/payment state."
     *
     * Full implementation of the webhook handler lives in Phase 3.
     * Here we test the data-layer precondition: the idempotency record
     * must exist after first processing, so the second delivery (even if
     * out of order) returns processed=already-seen.
     */
    const eventId = `evt_ooo_${Date.now()}`;
    await recordWebhookEvent({
      provider: 'stripe',
      eventId,
      eventType: 'payment_intent.succeeded',
      payloadHash: 'hash-ooo',
    });

    const r2 = await recordWebhookEvent({
      provider: 'stripe',
      eventId,
      eventType: 'payment_intent.succeeded', // could legitimately arrive after a refund event
      payloadHash: 'hash-ooo',
    });

    expect(r2.inserted).toBe(false);
    expect(r2.existingStatus).toBe('processed');

    await admin.from('processed_webhook_events')
      .delete()
      .eq('provider', 'stripe')
      .eq('event_id', eventId);
  });
});
