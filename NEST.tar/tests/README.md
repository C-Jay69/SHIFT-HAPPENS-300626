# Nest — Adversarial test suite

This directory holds the Phase 1 acceptance tests described in `docs/SPEC.md §29` and the §J Phase 1 prompt.

## Test files

| File | What it proves |
| --- | --- |
| `rls.test.ts` | Negative authorization matrix: no self-promotion to admin, no self-KYC, no cross-owner reads, no booking/payout tampering, no AI score forgery, machine-only tables blocked from clients. |
| `concurrency.test.ts` | 10 parallel booking attempts for identical dates → exactly one succeeds (GiST exclusion constraint). |
| `webhooks.test.ts` | Duplicate Stripe event delivery → exactly one transition (processed_webhook_events unique constraint). |
| `money.test.ts` | Settlement components reconcile to base; percentages sum to 100; integer minor units; refund never exceeds total. |
| `ai-validation.test.ts` | Zod schemas for vision / host matching / dispute assessment / pricing refinement reject out-of-range and malformed model output. |

## Required environment

The RLS, concurrency, and webhook tests need a live Supabase instance with all four migrations applied. Create a `.env.test` file (not committed) at the project root:

```bash
SUPABASE_URL=http://127.0.0.1:54321
SUPABASE_SERVICE_ROLE_KEY=eyJ...
SUPABASE_ANON_KEY=eyJ...
```

Apply migrations:

```bash
supabase db reset --linked
# or, against a local Supabase instance:
supabase db reset
```

## Run

```bash
bun run test:rls
bun run test:concurrency
bun run test:webhooks
bun run test:money
bun run test:ai
```

Or all at once:

```bash
bun run test
```

## Identity matrix (auto-provisioned by `helpers/users.ts`)

- **Alice** — owner (`alice+owner@nest.local`)
- **Bob** — owner (`bob+owner@nest.local`)
- **Hannah** — host, KYC verified (`hannah+host@nest.local`)
- **George** — guest (`george+guest@nest.local`)
- **Grace** — guest (`grace+guest@nest.local`)
- **Adam** — admin (`adam+admin@nest.local`)

Passwords for the demo identities are documented in `docs/deploy.md`. These users must never be seeded in production.
