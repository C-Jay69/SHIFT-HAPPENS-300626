/**
 * Phase 2 — Structured AI boundary tests
 *
 * Per docs/SPEC.md §0 rule 3: "Every structured AI response must pass
 * a Zod schema before application code can use it. Never trust model-
 * generated JSON directly. Malformed responses must be retried or
 * rejected safely."
 *
 * Per §8.2: aiJson() must:
 *   - call provider,
 *   - extract structured JSON safely,
 *   - parse JSON,
 *   - validate using Zod,
 *   - retry bounded failures,
 *   - try configured fallback provider,
 *   - return validated output plus model metadata.
 *
 * These tests inject a fake provider that returns canned responses
 * (well-formed JSON, malformed JSON, fenced code blocks, schema-invalid
 * JSON, transport errors, timeouts) and verify that aiJson() handles
 * each case correctly.
 */

import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { z } from "zod";

// ─── Test fixtures ───────────────────────────────────────────────

const TestSchema = z.object({
  score: z.number().min(0).max(100),
  label: z.string().max(50),
});

type TestResult = z.infer<typeof TestSchema>;

// We mock the provider chain via env vars. The structured.ts module
// imports getProviderChain which reads process.env.AI_PROVIDER /
// AI_MODEL / AI_FALLBACK_*_PROVIDER. For Phase 2 tests we monkey-patch
// the provider registry indirectly by mocking the z-ai-web-dev-sdk.

describe("JSON extraction utilities (indirectly via aiJson)", () => {
  // These tests don't need a live provider — they just verify that
  // our schema validation layer correctly accepts/rejects shapes.

  it("accepts a well-formed response matching the schema", () => {
    const candidate = { score: 75, label: "good_fit" };
    const r = TestSchema.safeParse(candidate);
    expect(r.success).toBe(true);
  });

  it("rejects a score above 100", () => {
    const candidate = { score: 150, label: "good_fit" };
    const r = TestSchema.safeParse(candidate);
    expect(r.success).toBe(false);
  });

  it("rejects a label longer than 50 chars", () => {
    const candidate = { score: 50, label: "x".repeat(60) };
    const r = TestSchema.safeParse(candidate);
    expect(r.success).toBe(false);
  });

  it("rejects missing fields", () => {
    const candidate = { score: 50 };
    const r = TestSchema.safeParse(candidate);
    expect(r.success).toBe(false);
  });
});

// ─── JSON extraction strategies (white-box) ─────────────────────
//
// We can't easily unit-test extractJson() directly because it's not
// exported from structured.ts. But the AI provider's chat() method
// returns text that aiJson() runs through extractJson(). To verify
// the extraction strategies work, we mock the ZAI provider's chat
// method to return specific text shapes and confirm aiJson() handles
// each correctly.

import { aiJson, AIError } from "@/lib/ai/structured";

// Mock the provider module so tests don't need a live AI key.
vi.mock("@/lib/ai/provider", () => {
  // We'll override getProviderChain per-test via setMockProvider.
  let mockProvider: any = null;
  return {
    getProviderChain: () => (mockProvider ? [mockProvider] : []),
    setMockProvider: (p: any) => {
      mockProvider = p;
    },
    clearMockProvider: () => {
      mockProvider = null;
    },
  };
});

import { setMockProvider, clearMockProvider } from "@/lib/ai/provider";

beforeEach(() => {
  clearMockProvider();
});

afterEach(() => {
  clearMockProvider();
});

describe("aiJson — JSON extraction strategies", () => {
  it("parses plain JSON response", async () => {
    setMockProvider({
      name: "mock",
      model: "mock-model",
      supportsVision: true,
      supportsStructuredOutput: true,
      chat: vi.fn().mockResolvedValue({
        text: JSON.stringify({ score: 80, label: "good" }),
        model: "mock-model",
      }),
    });

    const result = await aiJson<TestResult>({
      taskType: "test",
      schema: TestSchema,
      systemPrompt: "system",
      userPrompt: "user",
      maxRetries: 0,
    });

    expect(result.data).toEqual({ score: 80, label: "good" });
    expect(result.model).toBe("mock-model");
    expect(result.provider).toBe("mock");
  });

  it("parses JSON wrapped in ```json fences", async () => {
    setMockProvider({
      name: "mock",
      model: "mock-model",
      supportsVision: true,
      supportsStructuredOutput: true,
      chat: vi.fn().mockResolvedValue({
        text: '```json\n{"score": 90, "label": "great"}\n```',
        model: "mock-model",
      }),
    });

    const result = await aiJson<TestResult>({
      taskType: "test",
      schema: TestSchema,
      systemPrompt: "system",
      userPrompt: "user",
      maxRetries: 0,
    });

    expect(result.data).toEqual({ score: 90, label: "great" });
  });

  it("parses JSON prefixed with chatty model text", async () => {
    setMockProvider({
      name: "mock",
      model: "mock-model",
      supportsVision: true,
      supportsStructuredOutput: true,
      chat: vi.fn().mockResolvedValue({
        text:
          'Here is the analysis you requested.\n\n' +
          '{"score": 70, "label": "ok"}',
        model: "mock-model",
      }),
    });

    const result = await aiJson<TestResult>({
      taskType: "test",
      schema: TestSchema,
      systemPrompt: "system",
      userPrompt: "user",
      maxRetries: 0,
    });

    expect(result.data).toEqual({ score: 70, label: "ok" });
  });

  it("throws on completely non-JSON response", async () => {
    setMockProvider({
      name: "mock",
      model: "mock-model",
      supportsVision: true,
      supportsStructuredOutput: true,
      chat: vi.fn().mockResolvedValue({
        text: "I cannot help with that.",
        model: "mock-model",
      }),
    });

    await expect(
      aiJson<TestResult>({
        taskType: "test",
        schema: TestSchema,
        systemPrompt: "system",
        userPrompt: "user",
        maxRetries: 0,
      })
    ).rejects.toThrow();
  });
});

describe("aiJson — schema validation retry behaviour", () => {
  it("retries on schema-invalid response, then succeeds", async () => {
    const chatFn = vi.fn();
    // First call returns out-of-range score.
    chatFn.mockResolvedValueOnce({
      text: JSON.stringify({ score: 150, label: "bad" }),
      model: "mock-model",
    });
    // Second call returns valid response.
    chatFn.mockResolvedValueOnce({
      text: JSON.stringify({ score: 75, label: "good" }),
      model: "mock-model",
    });

    setMockProvider({
      name: "mock",
      model: "mock-model",
      supportsVision: true,
      supportsStructuredOutput: true,
      chat: chatFn,
    });

    const result = await aiJson<TestResult>({
      taskType: "test",
      schema: TestSchema,
      systemPrompt: "system",
      userPrompt: "user",
      maxRetries: 1,
    });

    expect(result.data).toEqual({ score: 75, label: "good" });
    expect(result.retries).toBeGreaterThanOrEqual(1);
    expect(chatFn).toHaveBeenCalledTimes(2);
  });

  it("throws AIError after exhausting retries", async () => {
    const chatFn = vi.fn().mockResolvedValue({
      text: JSON.stringify({ score: 999, label: "always_invalid" }),
      model: "mock-model",
    });

    setMockProvider({
      name: "mock",
      model: "mock-model",
      supportsVision: true,
      supportsStructuredOutput: true,
      chat: chatFn,
    });

    await expect(
      aiJson<TestResult>({
        taskType: "test",
        schema: TestSchema,
        systemPrompt: "system",
        userPrompt: "user",
        maxRetries: 1,
      })
    ).rejects.toThrow();
  });
});

describe("aiJson — transport errors", () => {
  it("throws AIError on transport failure", async () => {
    const chatFn = vi.fn().mockRejectedValue(new Error("network_down"));
    setMockProvider({
      name: "mock",
      model: "mock-model",
      supportsVision: true,
      supportsStructuredOutput: true,
      chat: chatFn,
    });

    await expect(
      aiJson<TestResult>({
        taskType: "test",
        schema: TestSchema,
        systemPrompt: "system",
        userPrompt: "user",
        maxRetries: 0,
      })
    ).rejects.toThrow();
  });

  it("throws AIError on timeout", async () => {
    const chatFn = vi.fn().mockRejectedValue(new Error("AI_REQUEST_TIMEOUT after 30000ms"));
    setMockProvider({
      name: "mock",
      model: "mock-model",
      supportsVision: true,
      supportsStructuredOutput: true,
      chat: chatFn,
    });

    await expect(
      aiJson<TestResult>({
        taskType: "test",
        schema: TestSchema,
        systemPrompt: "system",
        userPrompt: "user",
        maxRetries: 0,
      })
    ).rejects.toThrow();
  });
});

describe("aiJson — no provider configured", () => {
  it("throws when no provider is configured", async () => {
    // Don't call setMockProvider — getProviderChain returns []
    await expect(
      aiJson<TestResult>({
        taskType: "test",
        schema: TestSchema,
        systemPrompt: "system",
        userPrompt: "user",
        maxRetries: 0,
      })
    ).rejects.toThrow();
  });
});

describe("aiJson — observability metadata", () => {
  it("records latency + model + provider in the result", async () => {
    setMockProvider({
      name: "mock",
      model: "mock-model-v1",
      supportsVision: true,
      supportsStructuredOutput: true,
      chat: vi.fn().mockResolvedValue({
        text: JSON.stringify({ score: 50, label: "x" }),
        model: "mock-model-v1",
        usage: { prompt_tokens: 100, completion_tokens: 20 },
      }),
    });

    const result = await aiJson<TestResult>({
      taskType: "test",
      schema: TestSchema,
      systemPrompt: "system",
      userPrompt: "user",
      maxRetries: 0,
    });

    expect(result.latencyMs).toBeGreaterThanOrEqual(0);
    expect(result.model).toBe("mock-model-v1");
    expect(result.provider).toBe("mock");
    expect(result.usage?.promptTokens).toBe(100);
    expect(result.usage?.completionTokens).toBe(20);
  });
});
