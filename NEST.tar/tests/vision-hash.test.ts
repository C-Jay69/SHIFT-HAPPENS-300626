/**
 * Phase 2 — Vision hash + version tracking tests
 *
 * Per docs/SPEC.md §9: "Compute a deterministic hash of the relevant
 * image object identifiers/version metadata. If the hash differs from
 * the last successfully analyzed set: vision_status = pending; queue
 * asynchronous processing."
 *
 * Per §9: "Schema version must be stored."
 */

import { describe, it, expect } from "vitest";
import {
  computePhotosHash,
  VISION_SCHEMA_VERSION,
  propertyPhotoPath,
  VISION_BUCKET,
} from "@/lib/ai/vision";

describe("computePhotosHash", () => {
  it("returns the same hash for the same set of paths in any order", () => {
    const pathsA = [
      "properties/abc/p1.jpg",
      "properties/abc/p2.jpg",
      "properties/abc/p3.jpg",
    ];
    const pathsB = [...pathsA].reverse();
    expect(computePhotosHash(pathsA)).toBe(computePhotosHash(pathsB));
  });

  it("returns a different hash when the set changes", () => {
    const setA = ["properties/abc/p1.jpg", "properties/abc/p2.jpg"];
    const setB = ["properties/abc/p1.jpg", "properties/abc/p3.jpg"];
    expect(computePhotosHash(setA)).not.toBe(computePhotosHash(setB));
  });

  it("returns a different hash when a path is added", () => {
    const before = ["properties/abc/p1.jpg"];
    const after = ["properties/abc/p1.jpg", "properties/abc/p2.jpg"];
    expect(computePhotosHash(before)).not.toBe(computePhotosHash(after));
  });

  it("returns a different hash when a path is removed", () => {
    const before = ["properties/abc/p1.jpg", "properties/abc/p2.jpg"];
    const after = ["properties/abc/p1.jpg"];
    expect(computePhotosHash(before)).not.toBe(computePhotosHash(after));
  });

  it("returns a deterministic SHA-256 hex string", () => {
    const hash = computePhotosHash(["properties/abc/p1.jpg"]);
    expect(hash).toMatch(/^[a-f0-9]{64}$/);
  });

  it("returns the same hash for the same input across invocations", () => {
    const paths = ["properties/abc/p1.jpg", "properties/abc/p2.jpg"];
    expect(computePhotosHash(paths)).toBe(computePhotosHash(paths));
  });

  it("returns a different hash for paths belonging to different properties", () => {
    const a = ["properties/abc/p1.jpg"];
    const b = ["properties/xyz/p1.jpg"];
    expect(computePhotosHash(a)).not.toBe(computePhotosHash(b));
  });
});

describe("VISION_SCHEMA_VERSION", () => {
  it("is pinned to 1 for Phase 2", () => {
    expect(VISION_SCHEMA_VERSION).toBe(1);
  });
});

describe("propertyPhotoPath", () => {
  it("produces the canonical path shape properties/{propertyId}/{uuid}.jpg", () => {
    const path = propertyPhotoPath(
      "abc12345-1234-1234-1234-123456789012",
      "abcdef01-2345-5678-abcd-ef0123456789"
    );
    expect(path).toBe(
      "properties/abc12345-1234-1234-1234-123456789012/abcdef01-2345-5678-abcd-ef0123456789.jpg"
    );
  });

  it("uses POSIX path separators regardless of OS", () => {
    const path = propertyPhotoPath("p1", "u1");
    expect(path).not.toContain("\\");
    expect(path).toBe("properties/p1/u1.jpg");
  });
});

describe("VISION_BUCKET", () => {
  it("points to the property-photos private bucket", () => {
    expect(VISION_BUCKET).toBe("property-photos");
  });
});

describe("vision pipeline contract (no arbitrary remote URLs)", () => {
  it("analyzePropertyVision accepts only storage paths, never URLs", () => {
    // Per docs/SPEC.md §7: "Never allow AI routes to accept arbitrary
    // remote image URLs from users. Resolve authorized storage paths
    // server-side to prevent SSRF."
    //
    // The VisionAnalysisRequest type's photoPaths field is typed as
    // string[] (storage paths), and analyzePropertyVision downloads
    // them via the Supabase service client — it never accepts a URL.
    // This test pins the contract: the function signature requires
    // propertyId + photoPaths, never URLs.
    type VisionAnalysisRequestShape = {
      propertyId: string;
      photoPaths: string[];
      maxImages?: number;
    };
    const sample: VisionAnalysisRequestShape = {
      propertyId: "p1",
      photoPaths: ["properties/p1/u1.jpg"],
    };
    expect(sample.propertyId).toBe("p1");
    expect(Array.isArray(sample.photoPaths)).toBe(true);
    expect(sample.photoPaths.every((p) => !p.startsWith("http"))).toBe(true);
  });
});
