/**
 * Test identity provisioning for the Nest adversarial test suite.
 *
 * Uses the Supabase auth.admin API to create 6 test users, then uses the
 * service-role client to upsert the matching profile rows with the correct
 * role / KYC state. Each test user's anon-key client is returned so tests
 * can call Supabase as that user (RLS-enforced).
 *
 * Idempotent: safe to run before every test suite invocation.
 */

import type { SupabaseClient } from '@supabase/supabase-js';

export interface TestUser {
  id: string;
  email: string;
  password: string;
  role: 'owner' | 'host' | 'guest' | 'admin';
  kycStatus?: 'none' | 'pending' | 'verified';
  client: SupabaseClient;
}

interface SeedSpec {
  key: string;
  email: string;
  password: string;
  role: 'owner' | 'host' | 'guest' | 'admin';
  kycStatus?: 'none' | 'pending' | 'verified';
}

const SEED: SeedSpec[] = [
  { key: 'alice',  email: 'alice+owner@nest.local',  password: 'Nest-Test-2026!alice',  role: 'owner', kycStatus: 'none' },
  { key: 'bob',    email: 'bob+owner@nest.local',    password: 'Nest-Test-2026!bob',    role: 'owner', kycStatus: 'none' },
  { key: 'hannah', email: 'hannah+host@nest.local',  password: 'Nest-Test-2026!hannah', role: 'host',  kycStatus: 'verified' },
  { key: 'george', email: 'george+guest@nest.local', password: 'Nest-Test-2026!george', role: 'guest', kycStatus: 'none' },
  { key: 'grace',  email: 'grace+guest@nest.local',  password: 'Nest-Test-2026!grace',  role: 'guest', kycStatus: 'none' },
  { key: 'adam',    email: 'adam+admin@nest.local',   password: 'Nest-Test-2026!adam',   role: 'admin', kycStatus: 'none' },
];

/**
 * Provision all test users.
 *
 * NOTE: requires a Supabase instance with auth.admin available and the
 * migrations 0001, 0002, 0003 applied. Returns an object keyed by SEED key
 * (alice, bob, hannah, george, grace, adam).
 */
export async function ensureTestUsers(
  admin: SupabaseClient
): Promise<Record<string, TestUser>> {
  const { createClient } = await import('@supabase/supabase-js');
  const url = (admin as unknown as { supabaseUrl?: string }).supabaseUrl ?? process.env.SUPABASE_URL!;
  const anonKey = process.env.SUPABASE_ANON_KEY!;

  const out: Record<string, TestUser> = {};

  for (const spec of SEED) {
    // 1. Create auth user (idempotent — if exists, just sign in).
    const { data: existing } = await admin.auth.admin.listUsers();
    const found = existing.users.find((u) => u.email === spec.email);
    let userId: string;

    if (found) {
      userId = found.id;
    } else {
      const { data, error } = await admin.auth.admin.createUser({
        email: spec.email,
        password: spec.password,
        email_confirm: true,
        user_metadata: { role: spec.role, full_name: spec.key },
      });
      if (error) throw new Error(`Failed to create ${spec.email}: ${error.message}`);
      userId = data.user.id;
    }

    // 2. Upsert profile row with the correct role + KYC state.
    //    (handle_new_user trigger will have inserted a base row, but role
    //    may have come through raw_user_meta_data. We force the desired
    //    state here using the service role.)
    const { error: profileErr } = await admin
      .from('profiles')
      .upsert({
        id: userId,
        email: spec.email,
        full_name: spec.key.charAt(0).toUpperCase() + spec.key.slice(1),
        role: spec.role,
        kyc_status: spec.kycStatus ?? 'none',
        kyc_verified_at: spec.kycStatus === 'verified' ? new Date().toISOString() : null,
      }, { onConflict: 'id' });

    if (profileErr) {
      throw new Error(`Failed to upsert profile for ${spec.email}: ${profileErr.message}`);
    }

    // 3. Sign in as that user via anon key.
    const client = createClient(url, anonKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { error: signInErr } = await client.auth.signInWithPassword({
      email: spec.email,
      password: spec.password,
    });
    if (signInErr) {
      throw new Error(`Failed to sign in as ${spec.email}: ${signInErr.message}`);
    }

    out[spec.key] = {
      id: userId,
      email: spec.email,
      password: spec.password,
      role: spec.role,
      kycStatus: spec.kycStatus,
      client,
    };
  }

  return out;
}

/**
 * Best-effort teardown. Auth admin doesn't allow deletion of users with
 * dependent rows easily, so we just delete the auth users — cascade will
 * handle profiles. This is mainly for repeat-test runs.
 */
export async function teardownTestUsers(
  admin: SupabaseClient,
  users: Record<string, TestUser>
): Promise<void> {
  for (const key of Object.keys(users)) {
    const u = users[key];
    try {
      await admin.auth.admin.deleteUser(u.id);
    } catch {
      // ignore — user may already be gone
    }
  }
}
