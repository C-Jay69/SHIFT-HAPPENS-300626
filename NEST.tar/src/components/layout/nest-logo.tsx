export function NestLogo({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="nest-logo-gradient" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
          <stop stopColor="#FF7A45" />
          <stop offset="1" stopColor="#14B8A6" />
        </linearGradient>
      </defs>
      <path
        d="M16 2 L4 10 v18 l4 -3 v-12 l8 -5.5 8 5.5 v12 l4 3 v-18 z"
        stroke="url(#nest-logo-gradient)"
        strokeWidth="2.2"
        strokeLinejoin="round"
        fill="none"
      />
      <circle cx="16" cy="20" r="2.5" fill="#F5B841" />
    </svg>
  );
}
