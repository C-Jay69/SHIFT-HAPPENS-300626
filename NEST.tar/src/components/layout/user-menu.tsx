"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import type { Profile } from "@/types";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { User, LogOut, LayoutDashboard } from "lucide-react";

export function UserMenu() {
  // Don't call createClient() at module top-level — it throws if env vars
  // are not configured yet, which would crash the layout during preview.
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [configured, setConfigured] = useState(true);

  useEffect(() => {
    let active = true;
    let supabase;
    try {
      supabase = createClient();
    } catch {
      // Defer the setState calls to avoid synchronous cascading renders.
      Promise.resolve().then(() => {
        if (active) {
          setConfigured(false);
          setLoading(false);
        }
      });
      return;
    }
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        if (active) setLoading(false);
        return;
      }
      const { data } = await supabase
        .from("profiles")
        .select("id, email, role, full_name, avatar_path, bio, rating_avg, rating_count, kyc_status, kyc_verified_at, created_at, updated_at")
        .eq("id", user.id)
        .single();
      if (active) {
        setProfile((data as unknown as Profile) ?? null);
        setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  if (!configured) {
    // Supabase env vars not set — show the sign-in / sign-up CTAs as a
    // gentle signal that auth isn't wired yet.
    return (
      <div className="flex items-center gap-2">
        <Link href="/auth/login">
          <Button
            variant="ghost"
            size="sm"
            className="text-foreground-muted hover:text-foreground"
          >
            Sign in
          </Button>
        </Link>
        <Link href="/auth/signup">
          <Button size="sm" className="btn-primary-gradient">
            Get started
          </Button>
        </Link>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="h-9 w-24 rounded-md bg-card animate-pulse" aria-hidden />
    );
  }

  if (!profile) {
    return (
      <div className="flex items-center gap-2">
        <Link href="/auth/login">
          <Button
            variant="ghost"
            size="sm"
            className="text-foreground-muted hover:text-foreground"
          >
            Sign in
          </Button>
        </Link>
        <Link href="/auth/signup">
          <Button size="sm" className="btn-primary-gradient">
            Get started
          </Button>
        </Link>
      </div>
    );
  }

  const dashboardHref =
    profile.role === "owner"
      ? "/dashboard/owner"
      : profile.role === "host"
      ? "/dashboard/host"
      : profile.role === "admin"
      ? "/dashboard"
      : "/dashboard/guest";

  const initials = profile.full_name
    .split(/\s+/)
    .slice(0, 2)
    .map((s) => s[0])
    .join("")
    .toUpperCase();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          className="flex items-center gap-2 rounded-full border border-divider bg-card px-2 py-1 hover:border-teal-500/60 transition-colors"
          aria-label="Account menu"
        >
          <span className="flex h-7 w-7 items-center justify-center rounded-full bg-surface text-xs font-semibold text-teal-300">
            {initials || <User className="h-4 w-4" aria-hidden />}
          </span>
          <span className="hidden sm:inline text-sm text-foreground-muted pr-1">
            {profile.full_name.split(" ")[0]}
          </span>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56 bg-card border-divider">
        <div className="px-2 py-1.5">
          <p className="text-sm font-medium text-foreground truncate">
            {profile.full_name}
          </p>
          <p className="text-xs text-foreground-faint truncate">{profile.email}</p>
          <p className="mt-1 text-xs text-foreground-muted capitalize">
            {profile.role}
            {profile.kyc_status === "verified" && (
              <span className="ml-2 verified-badge">
                Verified
              </span>
            )}
          </p>
        </div>
        <DropdownMenuSeparator className="bg-divider" />
        <DropdownMenuItem asChild>
          <Link href={dashboardHref} className="cursor-pointer text-foreground hover:text-foreground">
            <LayoutDashboard className="mr-2 h-4 w-4" aria-hidden />
            Dashboard
          </Link>
        </DropdownMenuItem>
        <DropdownMenuSeparator className="bg-divider" />
        <DropdownMenuItem
          className="cursor-pointer text-danger focus:text-danger"
          onSelect={async (e) => {
            e.preventDefault();
            await supabase.auth.signOut();
            window.location.href = "/";
          }}
        >
          <LogOut className="mr-2 h-4 w-4" aria-hidden />
          Sign out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
