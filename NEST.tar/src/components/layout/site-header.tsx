import Link from "next/link";
import { Suspense } from "react";
import { NestLogo } from "./nest-logo";
import { UserMenu } from "./user-menu";
import { MobileNav } from "./mobile-nav";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-divider bg-void/95 backdrop-blur supports-[backdrop-filter]:bg-void/80">
      <div className="mx-auto flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center gap-2" aria-label="Nest home">
            <NestLogo className="h-7 w-7" />
            <span className="text-lg font-semibold tracking-tight text-foreground">
              Nest
            </span>
          </Link>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <Link href="/" className="text-foreground-muted hover:text-foreground transition-colors">
              Home
            </Link>
            <Link href="/docs" className="text-foreground-muted hover:text-foreground transition-colors">
              Docs
            </Link>
          </nav>
        </div>

        <div className="hidden md:flex items-center gap-3">
          <Suspense fallback={null}>
            <UserMenu />
          </Suspense>
        </div>

        <div className="md:hidden">
          <MobileNav />
        </div>
      </div>
    </header>
  );
}
