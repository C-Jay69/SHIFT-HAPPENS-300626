"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

export function MobileNav() {
  const [open, setOpen] = useState(false);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="text-foreground-muted hover:text-foreground"
          aria-label="Open navigation menu"
        >
          <Menu className="h-5 w-5" aria-hidden />
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="bg-void border-divider w-72">
        <SheetHeader>
          <SheetTitle className="text-foreground">Navigation</SheetTitle>
        </SheetHeader>
        <div className="mt-6 flex flex-col gap-2">
          <Link
            href="/"
            onClick={() => setOpen(false)}
            className="rounded-md px-3 py-2 text-sm text-foreground-muted hover:bg-card hover:text-foreground transition-colors"
          >
            Home
          </Link>
          <Link
            href="/docs"
            onClick={() => setOpen(false)}
            className="rounded-md px-3 py-2 text-sm text-foreground-muted hover:bg-card hover:text-foreground transition-colors"
          >
            Docs
          </Link>
          <Link
            href="/auth/login"
            onClick={() => setOpen(false)}
            className="rounded-md px-3 py-2 text-sm text-foreground-muted hover:bg-card hover:text-foreground transition-colors"
          >
            Sign in
          </Link>
          <Link
            href="/auth/signup"
            onClick={() => setOpen(false)}
            className="mt-2"
          >
            <Button className="btn-primary-gradient w-full">
              Get started
            </Button>
          </Link>
        </div>
      </SheetContent>
    </Sheet>
  );
}
