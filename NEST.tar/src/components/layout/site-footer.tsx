import Link from "next/link";
import { NestLogo } from "./nest-logo";

export function SiteFooter() {
  return (
    <footer className="mt-auto border-t border-divider bg-surface">
      <div className="mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <Link href="/" className="flex items-center gap-2">
              <NestLogo className="h-6 w-6" />
              <span className="text-base font-semibold text-foreground">Nest</span>
            </Link>
            <p className="mt-3 text-sm text-foreground-muted leading-relaxed">
              A co-hosting marketplace built for trust. Owners, hosts, and
              guests, connected with auditable automation.
            </p>
          </div>
          <FooterColumn
            title="Platform"
            links={[
              { label: "Home", href: "/" },
              { label: "Sign up", href: "/auth/signup" },
              { label: "Sign in", href: "/auth/login" },
              { label: "Docs", href: "/docs" },
            ]}
          />
          <FooterColumn
            title="Roles"
            links={[
              { label: "Owner", href: "/auth/signup?role=owner" },
              { label: "Host", href: "/auth/signup?role=host" },
              { label: "Guest", href: "/auth/signup?role=guest" },
            ]}
          />
          <FooterColumn
            title="Engineering"
            links={[
              { label: "Specification", href: "/docs" },
              { label: "Phase 1 — Foundation", href: "/docs#phase-1" },
              { label: "Security model", href: "/docs" },
            ]}
          />
        </div>
        <div className="mt-10 pt-6 border-t border-divider flex flex-col sm:flex-row justify-between gap-3 text-xs text-foreground-faint">
          <p>
            © {new Date().getFullYear()} Nest. Built per docs/SPEC.md v5.
          </p>
          <p>
            Money in integer minor units · RLS-enforced · AI never moves money.
          </p>
        </div>
      </div>
    </footer>
  );
}

function FooterColumn({
  title,
  links,
}: {
  title: string;
  links: { label: string; href: string }[];
}) {
  return (
    <div>
      <h3 className="text-sm font-semibold text-foreground">{title}</h3>
      <ul className="mt-3 space-y-2 text-sm">
        {links.map((l) => (
          <li key={l.label}>
            <Link
              href={l.href}
              className="text-foreground-muted hover:text-foreground transition-colors"
            >
              {l.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
