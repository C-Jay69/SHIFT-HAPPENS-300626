"use client";

import { useCallback, useState } from "react";
import { Sparkles, Loader2, AlertCircle, RefreshCw, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import type { VisionAnalysis } from "@/lib/ai/schemas";

interface PropertyEyeCardProps {
  propertyId: string;
  visionStatus: "pending" | "processing" | "complete" | "failed" | "stale";
  visionAnalysis: VisionAnalysis | null;
  visionModel: string | null;
  visionAnalyzedAt: string | null;
  visionSchemaVersion: number | null;
  hasPhotos: boolean;
}

/**
 * Property Eye — owner-facing AI vision analysis card.
 *
 * Per docs/SPEC.md §0 rule 1: "Vision is a core product capability.
 * The analysis: runs asynchronously after images change, never blocks
 * the owner's save operation, is schema-validated, is versioned and
 * auditable, contributes controlled signals to pricing, is visible to
 * the owner, can provide clearly labelled AI-assessed highlights to
 * guests, must never be presented as independently verified fact."
 *
 * The card:
 *   - shows current vision_status with appropriate visual treatment
 *   - allows the owner to manually re-trigger analysis
 *   - displays the full validated analysis (guests see a redacted version
 *     via the /api/properties/[id] endpoint)
 *   - clearly labels AI output as AI-assessed, not independently verified
 */
export function PropertyEyeCard({
  propertyId,
  visionStatus,
  visionAnalysis,
  visionModel,
  visionAnalyzedAt,
  visionSchemaVersion,
  hasPhotos,
}: PropertyEyeCardProps) {
  const [triggering, setTriggering] = useState(false);
  const [currentStatus, setCurrentStatus] = useState(visionStatus);

  const triggerAnalysis = useCallback(async () => {
    setTriggering(true);
    setCurrentStatus("processing");
    try {
      const res = await fetch(
        `/api/properties/${propertyId}/analyze-vision`,
        { method: "POST" }
      );
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "vision_failed");
      }
      setCurrentStatus(data.vision_status ?? "complete");
      if (data.vision_status === "complete") {
        toast.success("Vision analysis complete", {
          description: `Model: ${data.model ?? "unknown"}`,
        });
        // Reload the page so the card reflects the freshly-persisted analysis.
        if (typeof window !== "undefined") {
          window.location.reload();
        }
      } else if (data.vision_status === "failed") {
        toast.error("Vision analysis failed", {
          description: data.error || "Unknown error",
        });
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      toast.error("Vision trigger failed", { description: msg });
      setCurrentStatus("failed");
    } finally {
      setTriggering(false);
    }
  }, [propertyId]);

  return (
    <Card className="bg-card-surface border-divider">
      <CardHeader>
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-md bg-surface border border-divider">
              <Eye className="h-5 w-5 text-teal-500" aria-hidden />
            </div>
            <div>
              <CardTitle className="text-foreground flex items-center gap-2">
                Property Eye
                <Badge
                  variant="outline"
                  className="text-xs text-foreground-muted border-divider"
                >
                  AI-assessed
                </Badge>
              </CardTitle>
              <CardDescription className="text-foreground-muted">
                Automated multimodal analysis of your property photos.
              </CardDescription>
            </div>
          </div>
          <Button
            onClick={triggerAnalysis}
            disabled={triggering || !hasPhotos || currentStatus === "processing"}
            size="sm"
            variant="outline"
            className="border-teal-500 text-teal-300 hover:bg-teal-500/10"
          >
            {triggering || currentStatus === "processing" ? (
              <>
                <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" aria-hidden />
                Analyzing…
              </>
            ) : (
              <>
                <RefreshCw className="mr-2 h-3.5 w-3.5" aria-hidden />
                Re-analyze
              </>
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {!hasPhotos ? (
          <div className="rounded-md border border-dashed border-divider p-6 text-center">
            <Sparkles className="h-6 w-6 text-foreground-faint mx-auto mb-2" aria-hidden />
            <p className="text-sm text-foreground-muted">
              Upload photos to enable vision analysis.
            </p>
          </div>
        ) : currentStatus === "pending" ? (
          <StatusBlock
            tone="muted"
            title="Pending"
            body="Photos have changed since the last analysis. Click Re-analyze to run vision on the current photo set."
          />
        ) : currentStatus === "processing" ? (
          <StatusBlock
            tone="info"
            title="Processing"
            body="Vision analysis is running. This usually takes 10-30 seconds. You can leave this page — the result will appear when you return."
          />
        ) : currentStatus === "failed" ? (
          <StatusBlock
            tone="danger"
            title="Analysis failed"
            body="The vision provider returned an error or produced an invalid response. The property is still saved and may be listed. You can retry."
          />
        ) : currentStatus === "complete" && visionAnalysis ? (
          <VisionAnalysisDisplay
            analysis={visionAnalysis}
            model={visionModel}
            analyzedAt={visionAnalyzedAt}
            schemaVersion={visionSchemaVersion}
          />
        ) : (
          <StatusBlock
            tone="muted"
            title="Not analyzed yet"
            body="Click Re-analyze to run vision analysis on your photos."
          />
        )}

        <p className="mt-4 text-xs text-foreground-faint">
          Vision analysis is automated and schema-validated. It is clearly
          labelled to guests as AI-assessed and must never be presented as
          independently verified fact.
        </p>
      </CardContent>
    </Card>
  );
}

function StatusBlock({
  tone,
  title,
  body,
}: {
  tone: "muted" | "info" | "danger";
  title: string;
  body: string;
}) {
  const palette =
    tone === "info"
      ? "border-teal-500/40 bg-teal-500/5 text-teal-300"
      : tone === "danger"
      ? "border-danger/40 bg-danger/10 text-danger"
      : "border-divider bg-surface text-foreground-muted";
  return (
    <div className={`rounded-md border p-4 ${palette}`}>
      <div className="flex items-start gap-2">
        {tone === "danger" ? (
          <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" aria-hidden />
        ) : tone === "info" ? (
          <Loader2 className="h-4 w-4 mt-0.5 flex-shrink-0 animate-spin" aria-hidden />
        ) : (
          <Sparkles className="h-4 w-4 mt-0.5 flex-shrink-0" aria-hidden />
        )}
        <div>
          <p className="font-medium">{title}</p>
          <p className="text-sm mt-1 opacity-90">{body}</p>
        </div>
      </div>
    </div>
  );
}

function VisionAnalysisDisplay({
  analysis,
  model,
  analyzedAt,
  schemaVersion,
}: {
  analysis: VisionAnalysis;
  model: string | null;
  analyzedAt: string | null;
  schemaVersion: number | null;
}) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3">
        <ScoreTile label="Condition" value={analysis.condition_score} max={10} />
        <ScoreTile label="Interior modernity" value={analysis.interior_modernity_score} max={10} />
        <ScoreTile label="Curb appeal" value={analysis.curb_appeal_score} max={10} />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-sm">
        <InfoRow label="Quality tier" value={titleCase(analysis.quality_tier)} />
        <InfoRow label="Aesthetic vibe" value={titleCase(analysis.aesthetic_vibe.replace(/_/g, " "))} />
        <InfoRow label="Size bracket" value={titleCase(analysis.estimated_size_bracket)} />
        <InfoRow label="Lighting" value={titleCase(analysis.lighting_quality)} />
        <InfoRow label="Confidence" value={titleCase(analysis.confidence)} />
        <InfoRow
          label="Analyzed"
          value={analyzedAt ? new Date(analyzedAt).toLocaleString() : "—"}
        />
      </div>

      {analysis.notable_features.length > 0 && (
        <div>
          <p className="text-xs uppercase tracking-wider text-foreground-faint mb-2">
            Notable features
          </p>
          <div className="flex flex-wrap gap-1.5">
            {analysis.notable_features.map((f, i) => (
              <Badge
                key={`${i}-${f}`}
                variant="secondary"
                className="bg-teal-500/10 text-teal-300 border border-teal-500/30"
              >
                {f}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {analysis.red_flags.length > 0 && (
        <div>
          <p className="text-xs uppercase tracking-wider text-foreground-faint mb-2">
            Red flags
          </p>
          <div className="flex flex-wrap gap-1.5">
            {analysis.red_flags.map((f, i) => (
              <Badge
                key={`${i}-${f}`}
                variant="secondary"
                className="bg-danger/10 text-danger border border-danger/30"
              >
                {f}
              </Badge>
            ))}
          </div>
        </div>
      )}

      {analysis.visual_justification && (
        <div>
          <p className="text-xs uppercase tracking-wider text-foreground-faint mb-1">
            Visual justification
          </p>
          <p className="text-sm text-foreground-muted leading-relaxed">
            {analysis.visual_justification}
          </p>
        </div>
      )}

      <div className="pt-3 border-t border-divider text-xs text-foreground-faint flex flex-wrap gap-x-3 gap-y-1">
        {model && <span>Model: <code className="text-foreground-muted">{model}</code></span>}
        {schemaVersion !== null && <span>Schema v{schemaVersion}</span>}
      </div>
    </div>
  );
}

function ScoreTile({ label, value, max }: { label: string; value: number; max: number }) {
  const pct = (value / max) * 100;
  const color =
    value >= 8 ? "#22C55E" : value >= 5 ? "#F5B841" : "#EF4444";
  return (
    <div className="rounded-md border border-divider bg-surface p-3">
      <p className="text-xs text-foreground-faint mb-1">{label}</p>
      <div className="flex items-baseline gap-1">
        <span className="text-2xl font-semibold" style={{ color }}>
          {value}
        </span>
        <span className="text-xs text-foreground-faint">/{max}</span>
      </div>
      <div className="mt-2 h-1.5 rounded-full bg-void overflow-hidden">
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${pct}%`, backgroundColor: color }}
        />
      </div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-foreground-faint">{label}</p>
      <p className="text-sm text-foreground">{value}</p>
    </div>
  );
}

function titleCase(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
