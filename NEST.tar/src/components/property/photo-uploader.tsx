"use client";

import { useCallback, useState, type ChangeEvent, type DragEvent } from "react";
import { UploadCloud, X, Loader2, AlertCircle, ImageOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

interface PhotoItem {
  /** Storage path under property-photos/ — set after successful upload. */
  path: string;
  /** Object URL for local preview before upload. */
  previewUrl: string;
  status: "uploading" | "uploaded" | "error";
  error?: string;
}

interface PropertyPhotoUploaderProps {
  propertyId: string;
  initialPhotos?: Array<{ path: string }>;
  onChange: (paths: string[]) => void;
}

/**
 * Drag-and-drop photo uploader for property images.
 *
 * Per docs/SPEC.md §4: "Upload zone: drag/drop support, accessible
 * keyboard operation, per-file upload and analysis state."
 *
 * Per §7: validates MIME type, extension, file size, max image dimensions,
 * number of files server-side (this client pre-checks for fast feedback
 * but the server is the authority).
 *
 * Per §5.2 + §7: photos are stored as private Supabase Storage objects
 * at paths like `properties/{propertyId}/{uuid}.jpg`. Signed URLs are
 * generated on read (short lifetime, never persisted).
 */
export function PropertyPhotoUploader({
  propertyId,
  initialPhotos = [],
  onChange,
}: PropertyPhotoUploaderProps) {
  const [photos, setPhotos] = useState<PhotoItem[]>(
    initialPhotos.map((p) => ({
      path: p.path,
      previewUrl: `/api/properties/${propertyId}/photo?path=${encodeURIComponent(p.path)}`,
      status: "uploaded" as const,
    }))
  );
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);

  const syncToParent = useCallback(
    (next: PhotoItem[]) => {
      onChange(next.filter((p) => p.status === "uploaded").map((p) => p.path));
    },
    [onChange]
  );

  const handleFiles = useCallback(
    async (fileList: FileList | File[]) => {
      const files = Array.from(fileList);
      if (files.length === 0) return;

      setUploading(true);

      // Use FormData so the server is the real trust boundary for
      // MIME type + size + ownership.
      const form = new FormData();
      for (const f of files) {
        form.append("files", f);
      }

      // Add optimistic previews.
      const optimisticItems: PhotoItem[] = files.map((f) => ({
        path: "",
        previewUrl: URL.createObjectURL(f),
        status: "uploading" as const,
      }));
      setPhotos((prev) => {
        const next = [...prev, ...optimisticItems];
        syncToParent(next);
        return next;
      });

      try {
        const res = await fetch(`/api/properties/${propertyId}/upload`, {
          method: "POST",
          body: form,
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || "upload_failed");
        }
        const newPaths: string[] = data.uploaded_paths || [];

        // Mark optimistic items: those that uploaded get the real path,
        // those that did not get marked error.
        setPhotos((prev) => {
          const updated = [...prev];
          let pathIdx = 0;
          for (let i = updated.length - optimisticItems.length; i < updated.length; i++) {
            if (pathIdx < newPaths.length) {
              updated[i] = {
                ...updated[i],
                path: newPaths[pathIdx],
                status: "uploaded",
              };
              pathIdx++;
              // Revoke the local object URL — server will serve the
              // real signed URL via /api/properties/[id]/photo.
              URL.revokeObjectURL(updated[i].previewUrl);
              updated[i].previewUrl = `/api/properties/${propertyId}/photo?path=${encodeURIComponent(updated[i].path)}`;
            } else {
              updated[i] = {
                ...updated[i],
                status: "error",
                error: "Skipped by server (invalid type or size).",
              };
            }
          }
          syncToParent(updated);
          return updated;
        });
        toast.success(`Uploaded ${newPaths.length} photo(s)`);
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        toast.error("Upload failed", { description: msg });
        // Roll back optimistic items.
        setPhotos((prev) => {
          const next = prev.slice(0, prev.length - optimisticItems.length);
          syncToParent(next);
          return next;
        });
      } finally {
        setUploading(false);
      }
    },
    [propertyId, syncToParent]
  );

  const handleDelete = useCallback(
    async (index: number) => {
      const target = photos[index];
      if (!target) return;
      if (target.status === "uploaded" && target.path) {
        try {
          const res = await fetch(
            `/api/properties/${propertyId}/upload?path=${encodeURIComponent(target.path)}`,
            { method: "DELETE" }
          );
          if (!res.ok) {
            const data = await res.json();
            throw new Error(data.error || "delete_failed");
          }
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          toast.error("Delete failed", { description: msg });
          return;
        }
      } else {
        URL.revokeObjectURL(target.previewUrl);
      }
      setPhotos((prev) => {
        const next = prev.filter((_, i) => i !== index);
        syncToParent(next);
        return next;
      });
    },
    [photos, propertyId, syncToParent]
  );

  const onDrop = useCallback(
    (e: DragEvent<HTMLLabelElement>) => {
      e.preventDefault();
      setDragging(false);
      if (e.dataTransfer.files.length > 0) {
        void handleFiles(e.dataTransfer.files);
      }
    },
    [handleFiles]
  );

  const onInputChange = useCallback(
    (e: ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files.length > 0) {
        void handleFiles(e.target.files);
        // Reset so the same file can be re-selected later.
        e.target.value = "";
      }
    },
    [handleFiles]
  );

  return (
    <div className="space-y-3">
      <label
        htmlFor="property-photo-input"
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        className={`flex flex-col items-center justify-center gap-2 px-4 py-8 rounded-lg border-2 border-dashed cursor-pointer transition-colors ${
          dragging
            ? "border-teal-500 bg-teal-500/5"
            : "border-divider bg-surface hover:border-foreground-faint"
        }`}
      >
        <UploadCloud className="h-7 w-7 text-foreground-muted" aria-hidden />
        <span className="text-sm text-foreground">
          Drag and drop photos here, or click to browse
        </span>
        <span className="text-xs text-foreground-faint">
          JPEG / PNG / WebP · max 10 MiB each · up to 20 photos
        </span>
        <input
          id="property-photo-input"
          type="file"
          accept="image/jpeg,image/png,image/webp"
          multiple
          className="sr-only"
          onChange={onInputChange}
          disabled={uploading}
        />
      </label>

      {uploading && (
        <div className="flex items-center gap-2 text-sm text-foreground-muted">
          <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
          Uploading…
        </div>
      )}

      {photos.length > 0 && (
        <ul className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {photos.map((p, i) => (
            <li
              key={`${i}-${p.path || p.previewUrl}`}
              className="relative rounded-md overflow-hidden border border-divider bg-surface aspect-square"
            >
              { }
              <img
                src={p.previewUrl}
                alt={`Property photo ${i + 1}`}
                className="h-full w-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = "none";
                }}
              />
              <button
                type="button"
                onClick={() => handleDelete(i)}
                aria-label={`Delete photo ${i + 1}`}
                className="absolute top-1 right-1 rounded-full bg-void/80 hover:bg-danger text-foreground p-1.5 transition-colors"
              >
                <X className="h-3.5 w-3.5" aria-hidden />
              </button>
              {p.status === "uploading" && (
                <div className="absolute inset-0 bg-void/60 flex items-center justify-center">
                  <Loader2 className="h-5 w-5 animate-spin text-foreground" aria-hidden />
                </div>
              )}
              {p.status === "error" && (
                <div className="absolute inset-0 bg-danger/80 flex items-center justify-center p-2 text-center">
                  <div className="flex flex-col items-center gap-1">
                    <ImageOff className="h-5 w-5 text-foreground" aria-hidden />
                    <span className="text-xs text-foreground">
                      {p.error || "Failed"}
                    </span>
                  </div>
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
