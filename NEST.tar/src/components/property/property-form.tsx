"use client";

import { useState, type FormEvent, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { PropertyPhotoUploader } from "./photo-uploader";
import { PropertyEyeCard } from "@/components/vision/property-eye-card";
import type { VisionAnalysis } from "@/lib/ai/schemas";
import { Loader2, AlertCircle, Save, ListPlus, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import Link from "next/link";

interface PropertyFormProps {
  /** When set, the form is in edit mode for this property. */
  propertyId?: string;
  initial?: {
    title?: string;
    description?: string;
    bedrooms?: number;
    bathrooms?: number;
    max_guests?: number;
    base_price_minor?: number;
    min_price_minor?: number;
    max_price_minor?: number;
    currency?: string;
    cleaning_fee_minor?: number;
    status?: "draft" | "listed";
    amenities?: string[];
    photos?: string[];
    vision_status?: "pending" | "processing" | "complete" | "failed" | "stale";
    vision_analysis?: VisionAnalysis | null;
    vision_model?: string | null;
    vision_analyzed_at?: string | null;
    vision_schema_version?: number | null;
    latitude?: number | null;
    longitude?: number | null;
  };
}

const AMENITY_OPTIONS = [
  "wifi", "kitchen", "parking", "pool", "hot_tub", "fireplace", "ac",
  "heating", "washer", "dryer", "tv", "workspace", "pet_friendly",
  "garden", "balcony", "ocean_view", "mountain_view", "gym"
];

/**
 * Property create / edit form. Used for both new-property creation
 * and editing an existing property.
 *
 * Per docs/SPEC.md §5.2: the form only allows editing fields that the
 * owner is permitted to change directly. assigned_host_id, vision_*,
 * and admin-only status values are never settable here — the server
 * route enforces this in /api/properties/[id] PATCH.
 *
 * Per §0 rule 1: vision runs asynchronously after images change.
 * The owner can save the property at any time; vision runs in the
 * background and the Property Eye card updates when ready.
 */
export function PropertyForm({ propertyId, initial }: PropertyFormProps) {
  const router = useRouter();
  const isEdit = !!propertyId;

  const [title, setTitle] = useState(initial?.title ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [bedrooms, setBedrooms] = useState(initial?.bedrooms ?? 1);
  const [bathrooms, setBathrooms] = useState(initial?.bathrooms ?? 1);
  const [maxGuests, setMaxGuests] = useState(initial?.max_guests ?? 2);
  const [basePrice, setBasePrice] = useState(initial?.base_price_minor ? (initial.base_price_minor / 100).toFixed(2) : "120.00");
  const [minPrice, setMinPrice] = useState(initial?.min_price_minor ? (initial.min_price_minor / 100).toFixed(2) : "100.00");
  const [maxPrice, setMaxPrice] = useState(initial?.max_price_minor ? (initial.max_price_minor / 100).toFixed(2) : "200.00");
  const [cleaningFee, setCleaningFee] = useState(initial?.cleaning_fee_minor ? (initial.cleaning_fee_minor / 100).toFixed(2) : "50.00");
  const [currency, setCurrency] = useState(initial?.currency ?? "USD");
  const [status, setStatus] = useState<"draft" | "listed">(initial?.status ?? "draft");
  const [amenities, setAmenities] = useState<string[]>(initial?.amenities ?? []);
  const [photos, setPhotos] = useState<string[]>(initial?.photos ?? []);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [createdId, setCreatedId] = useState<string | null>(propertyId ?? null);

  // For edit mode: track vision state so the Property Eye card updates
  // after the owner re-runs analysis.
  const [visionStatus, setVisionStatus] = useState<
    "pending" | "processing" | "complete" | "failed" | "stale"
  >(initial?.vision_status ?? "pending");

  const handleAmenityToggle = useCallback((amenity: string) => {
    setAmenities((prev) =>
      prev.includes(amenity)
        ? prev.filter((a) => a !== amenity)
        : [...prev, amenity]
    );
  }, []);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    const baseMinor = Math.round(parseFloat(basePrice) * 100);
    const minMinor = Math.round(parseFloat(minPrice) * 100);
    const maxMinor = Math.round(parseFloat(maxPrice) * 100);
    const cleaningMinor = Math.round(parseFloat(cleaningFee) * 100);

    if (isNaN(baseMinor) || baseMinor <= 0) {
      setError("Base price must be a positive number.");
      return;
    }
    if (minMinor > baseMinor) {
      setError("Min price must be ≤ base price.");
      return;
    }
    if (baseMinor > maxMinor) {
      setError("Base price must be ≤ max price.");
      return;
    }
    if (title.length < 3 || title.length > 140) {
      setError("Title must be 3-140 characters.");
      return;
    }

    setSubmitting(true);

    const payload = {
      title,
      description: description || undefined,
      bedrooms,
      bathrooms,
      max_guests: maxGuests,
      base_price_minor: baseMinor,
      min_price_minor: minMinor,
      max_price_minor: maxMinor,
      currency,
      cleaning_fee_minor: cleaningMinor,
      status,
      amenities,
    };

    try {
      if (isEdit && createdId) {
        // Patch existing property.
        const res = await fetch(`/api/properties/${createdId}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || "save_failed");
        }
        // If photos changed since last vision analysis, mark vision as stale.
        if (initial?.photos && JSON.stringify(initial.photos) !== JSON.stringify(photos)) {
          setVisionStatus("pending");
        }
        toast.success("Saved", { description: "Property updated." });
      } else {
        // Create new property — status defaults to draft.
        const res = await fetch("/api/properties", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || "create_failed");
        }
        setCreatedId(data.property.id);
        toast.success("Property created", {
          description: "Now you can upload photos and trigger vision analysis.",
        });
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      setError(msg);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        <Card className="bg-card-surface border-divider">
          <CardHeader>
            <CardTitle className="text-foreground">
              {isEdit ? "Edit property" : "New property"}
            </CardTitle>
            <CardDescription className="text-foreground-muted">
              {isEdit
                ? "Update details, photos, and pricing. Vision re-analyzes automatically when photos change."
                : "Start with the basics. You can add photos and trigger vision analysis right after creation."}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="title" className="text-foreground">
                Title <span className="text-danger">*</span>
              </Label>
              <Input
                id="title"
                required
                minLength={3}
                maxLength={140}
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="bg-surface border-divider text-foreground placeholder:text-foreground-faint"
                placeholder="Cozy cabin near the lake"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="text-foreground">
                Description
              </Label>
              <Textarea
                id="description"
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="bg-surface border-divider text-foreground placeholder:text-foreground-faint"
                placeholder="Describe the space, what makes it special, and what guests can expect."
              />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="bedrooms" className="text-foreground">Bedrooms</Label>
                <Input
                  id="bedrooms"
                  type="number"
                  min={0}
                  max={100}
                  value={bedrooms}
                  onChange={(e) => setBedrooms(parseInt(e.target.value) || 0)}
                  className="bg-surface border-divider text-foreground"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="bathrooms" className="text-foreground">Bathrooms</Label>
                <Input
                  id="bathrooms"
                  type="number"
                  min={0}
                  max={100}
                  step={0.5}
                  value={bathrooms}
                  onChange={(e) => setBathrooms(parseFloat(e.target.value) || 0)}
                  className="bg-surface border-divider text-foreground"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="max_guests" className="text-foreground">Max guests</Label>
                <Input
                  id="max_guests"
                  type="number"
                  min={1}
                  max={100}
                  value={maxGuests}
                  onChange={(e) => setMaxGuests(parseInt(e.target.value) || 1)}
                  className="bg-surface border-divider text-foreground"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="base_price" className="text-foreground">Base price</Label>
                <Input
                  id="base_price"
                  type="number"
                  step="0.01"
                  min="0"
                  value={basePrice}
                  onChange={(e) => setBasePrice(e.target.value)}
                  className="bg-surface border-divider text-foreground"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="min_price" className="text-foreground">Min price</Label>
                <Input
                  id="min_price"
                  type="number"
                  step="0.01"
                  min="0"
                  value={minPrice}
                  onChange={(e) => setMinPrice(e.target.value)}
                  className="bg-surface border-divider text-foreground"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="max_price" className="text-foreground">Max price</Label>
                <Input
                  id="max_price"
                  type="number"
                  step="0.01"
                  min="0"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(e.target.value)}
                  className="bg-surface border-divider text-foreground"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cleaning_fee" className="text-foreground">Cleaning fee</Label>
                <Input
                  id="cleaning_fee"
                  type="number"
                  step="0.01"
                  min="0"
                  value={cleaningFee}
                  onChange={(e) => setCleaningFee(e.target.value)}
                  className="bg-surface border-divider text-foreground"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="currency" className="text-foreground">Currency</Label>
                <Select value={currency} onValueChange={setCurrency}>
                  <SelectTrigger id="currency" className="bg-surface border-divider text-foreground">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-divider">
                    <SelectItem value="USD">USD</SelectItem>
                    <SelectItem value="EUR">EUR</SelectItem>
                    <SelectItem value="GBP">GBP</SelectItem>
                    <SelectItem value="CAD">CAD</SelectItem>
                    <SelectItem value="AUD">AUD</SelectItem>
                    <SelectItem value="MXN">MXN</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="status" className="text-foreground">Status</Label>
                <Select
                  value={status}
                  onValueChange={(v) => setStatus(v as "draft" | "listed")}
                >
                  <SelectTrigger id="status" className="bg-surface border-divider text-foreground">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-divider">
                    <SelectItem value="draft">Draft (not visible)</SelectItem>
                    <SelectItem value="listed">Listed (public)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-foreground">Amenities</Label>
              <div className="flex flex-wrap gap-2">
                {AMENITY_OPTIONS.map((a) => {
                  const selected = amenities.includes(a);
                  return (
                    <button
                      type="button"
                      key={a}
                      onClick={() => handleAmenityToggle(a)}
                      aria-pressed={selected}
                      className={`rounded-full px-3 py-1 text-xs border transition-colors ${
                        selected
                          ? "bg-teal-500/15 border-teal-500 text-teal-300"
                          : "bg-surface border-divider text-foreground-muted hover:border-foreground-faint"
                      }`}
                    >
                      {a.replace(/_/g, " ")}
                    </button>
                  );
                })}
              </div>
            </div>
          </CardContent>
          <CardFooter className="border-t border-divider pt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-3 justify-between">
            {error && (
              <div className="rounded-md border border-danger/40 bg-danger/10 px-3 py-2 text-sm text-danger flex items-start gap-2 flex-1">
                <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" aria-hidden />
                <span>{error}</span>
              </div>
            )}
            <div className="flex gap-2 ml-auto">
              <Link href="/dashboard/owner/properties">
                <Button
                  type="button"
                  variant="outline"
                  className="border-divider text-foreground-muted"
                >
                  Cancel
                </Button>
              </Link>
              <Button
                type="submit"
                disabled={submitting}
                className="btn-primary-gradient"
              >
                {submitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden />
                    Saving…
                  </>
                ) : isEdit ? (
                  <>
                    <Save className="mr-2 h-4 w-4" aria-hidden />
                    Save changes
                  </>
                ) : (
                  <>
                    <ListPlus className="mr-2 h-4 w-4" aria-hidden />
                    Create property
                  </>
                )}
              </Button>
            </div>
          </CardFooter>
        </Card>
      </form>

      {createdId && (
        <>
          <Card className="bg-card-surface border-divider">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-teal-500" aria-hidden />
                Photos
              </CardTitle>
              <CardDescription className="text-foreground-muted">
                Photos are private. Vision analysis runs automatically after
                photos change.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <PropertyPhotoUploader
                propertyId={createdId}
                initialPhotos={(initial?.photos ?? []).map((p) => ({ path: p }))}
                onChange={setPhotos}
              />
            </CardContent>
          </Card>

          <PropertyEyeCard
            propertyId={createdId}
            visionStatus={visionStatus}
            visionAnalysis={initial?.vision_analysis ?? null}
            visionModel={initial?.vision_model ?? null}
            visionAnalyzedAt={initial?.vision_analyzed_at ?? null}
            visionSchemaVersion={initial?.vision_schema_version ?? null}
            hasPhotos={photos.length > 0}
          />
        </>
      )}
    </div>
  );
}
