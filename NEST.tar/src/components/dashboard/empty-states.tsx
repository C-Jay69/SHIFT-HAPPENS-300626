import Link from "next/link";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Construction, Home, Sparkles, Users, Search, MessageSquare, Star, ShieldCheck, Plus } from "lucide-react";

interface EmptyStateProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  phase: string;
  cta?: { href: string; label: string };
  ctaVariant?: "primary" | "outline";
}

export function EmptyState({ icon, title, description, phase, cta, ctaVariant = "outline" }: EmptyStateProps) {
  return (
    <Card className="bg-card-surface border-divider border-dashed">
      <CardHeader>
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-md bg-surface border border-divider text-foreground-muted">
            {icon}
          </div>
          <CardTitle className="text-lg text-foreground">{title}</CardTitle>
        </div>
        <CardDescription className="text-foreground-muted">
          {description}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-surface border border-divider px-2.5 py-1 text-xs text-foreground-muted">
            <Construction className="h-3 w-3 text-gold-500" aria-hidden />
            {phase}
          </span>
          {cta && (
            <Link href={cta.href}>
              <Button
                variant={ctaVariant === "primary" ? "default" : "outline"}
                size="sm"
                className={ctaVariant === "primary" ? "btn-primary-gradient" : "border-teal-500 text-teal-300 hover:bg-teal-500/10"}
              >
                {cta.label}
              </Button>
            </Link>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export function OwnerDashboardEmptyStates({ hasProperties = false }: { hasProperties?: boolean }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      <EmptyState
        icon={<Home className="h-5 w-5" aria-hidden />}
        title="Properties"
        description={hasProperties
          ? "Manage your existing properties or create a new one. Photos are stored privately and analyzed asynchronously by the vision pipeline."
          : "Create your first property listing. Photos are stored privately and analyzed asynchronously by the vision pipeline."}
        phase="Phase 2 — live"
        cta={{ href: "/dashboard/owner/properties", label: hasProperties ? "Manage properties" : "Create your first property" }}
        ctaVariant="primary"
      />
      <EmptyState
        icon={<Sparkles className="h-5 w-5" aria-hidden />}
        title="Property Eye"
        description="AI-assessed property highlights become available after your first listing's photos are analyzed. Open any property to view its Property Eye card."
        phase="Phase 2 — live"
        cta={{ href: "/dashboard/owner/properties", label: "View your properties" }}
      />
      <EmptyState
        icon={<Search className="h-5 w-5" aria-hidden />}
        title="Public search"
        description="Browse listed properties on the public search page. AI-assessed highlights are clearly labelled to guests as AI-assessed, not independently verified fact."
        phase="Phase 2 — live"
        cta={{ href: "/search", label: "Open search" }}
      />
      <EmptyState
        icon={<Users className="h-5 w-5" aria-hidden />}
        title="Host applications"
        description="Once a property is listed, verified hosts can apply to manage it. AI matching appears as advisory information only."
        phase="Phase 4 — Trust"
      />
      <EmptyState
        icon={<MessageSquare className="h-5 w-5" aria-hidden />}
        title="Messages"
        description="Communicate with assigned hosts and booking guests through thread-scoped messaging."
        phase="Phase 4 — Trust"
      />
      <EmptyState
        icon={<Star className="h-5 w-5" aria-hidden />}
        title="Reviews"
        description="Reviews from guests who completed stays at your properties will appear here."
        phase="Phase 4 — Trust"
      />
      <EmptyState
        icon={<ShieldCheck className="h-5 w-5" aria-hidden />}
        title="Payouts"
        description="Delayed payouts are calculated server-side with snapshotted percentages and reconciled against bookings."
        phase="Phase 3 — Bookings + Payments"
      />
    </div>
  );
}

export function HostDashboardEmptyStates() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      <EmptyState
        icon={<ShieldCheck className="h-5 w-5" aria-hidden />}
        title="Identity verification"
        description="Complete KYC to unlock host applications. The verification flow uses Stripe Identity and is enforced at the database layer."
        phase="Phase 4 — Trust"
        cta={{ href: "/auth/verify-identity", label: "Start verification" }}
      />
      <EmptyState
        icon={<Search className="h-5 w-5" aria-hidden />}
        title="Property matches"
        description="Browse listed properties and apply to manage them. Advisory AI matching scores help owners review your application."
        phase="Phase 4 — Trust"
      />
      <EmptyState
        icon={<MessageSquare className="h-5 w-5" aria-hidden />}
        title="Messages"
        description="Once assigned to a property, message owners and guests here."
        phase="Phase 4 — Trust"
      />
      <EmptyState
        icon={<Star className="h-5 w-5" aria-hidden />}
        title="Reviews"
        description="Reviews from owners and guests you have worked with will appear here."
        phase="Phase 4 — Trust"
      />
      <EmptyState
        icon={<ShieldCheck className="h-5 w-5" aria-hidden />}
        title="Payouts"
        description="Your compensation share is snapshotted onto each booking and released after the configured delay."
        phase="Phase 3 — Bookings + Payments"
      />
    </div>
  );
}

export function GuestDashboardEmptyStates() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      <EmptyState
        icon={<Search className="h-5 w-5" aria-hidden />}
        title="Search stays"
        description="Find listed properties by location, dates, and amenities. Public listings and price calendars are visible without signing in."
        phase="Phase 2 — live"
        cta={{ href: "/search", label: "Search properties" }}
        ctaVariant="primary"
      />
      <EmptyState
        icon={<Home className="h-5 w-5" aria-hidden />}
        title="Your trips"
        description="Upcoming and past stays will appear here once bookings are live."
        phase="Phase 3 — Bookings + Payments"
      />
      <EmptyState
        icon={<MessageSquare className="h-5 w-5" aria-hidden />}
        title="Messages"
        description="Message owners and hosts about your bookings."
        phase="Phase 4 — Trust"
      />
      <EmptyState
        icon={<Star className="h-5 w-5" aria-hidden />}
        title="Reviews"
        description="Leave reviews after completed stays. Review eligibility is enforced server-side."
        phase="Phase 4 — Trust"
      />
      <EmptyState
        icon={<ShieldCheck className="h-5 w-5" aria-hidden />}
        title="Disputes"
        description="Open a qualifying dispute if something goes wrong. Disputes freeze the relevant payout and an AI assessment provides advisory analysis."
        phase="Phase 5 — Pricing + Disputes"
      />
    </div>
  );
}
