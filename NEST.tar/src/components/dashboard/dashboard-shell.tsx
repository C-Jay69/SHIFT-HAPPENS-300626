import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { Profile, UserRole } from "@/types";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { AlertCircle, ArrowLeft } from "lucide-react";

interface DashboardShellProps {
  role: UserRole;
  children: React.ReactNode;
}

export async function DashboardShell({ role, children }: DashboardShellProps) {
  let supabase: Awaited<ReturnType<typeof createClient>>;
  try {
    supabase = await createClient();
  } catch {
    return (
      <div className="bg-void min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4">
        <Card className="bg-card-surface border-divider max-w-lg w-full">
          <CardHeader>
            <CardTitle className="text-foreground flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-warning" aria-hidden />
              Supabase not configured
            </CardTitle>
            <CardDescription className="text-foreground-muted">
              The dashboard requires Supabase credentials to authenticate
              users. Phase 1 is wired and ready — you just need to plug in
              your project keys.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ol className="list-decimal list-inside space-y-2 text-sm text-foreground-muted">
              <li>Copy <code className="text-foreground">.env.example</code> to <code className="text-foreground">.env.local</code>.</li>
              <li>Fill in <code className="text-foreground">NEXT_PUBLIC_SUPABASE_URL</code> and <code className="text-foreground">NEXT_PUBLIC_SUPABASE_ANON_KEY</code> from your Supabase Dashboard.</li>
              <li>Apply migrations: <code className="text-foreground">supabase db reset</code> against a clean local Supabase instance.</li>
              <li>Restart <code className="text-foreground">bun run dev</code>.</li>
            </ol>
            <div className="mt-6">
              <Link href="/">
                <Button variant="outline" className="border-divider text-foreground-muted">
                  <ArrowLeft className="mr-2 h-4 w-4" aria-hidden />
                  Back to home
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect("/auth/login");
  }

  const { data: profileRow } = await supabase
    .from("profiles")
    .select(
      "id, email, role, full_name, avatar_path, bio, rating_avg, rating_count, kyc_status, kyc_verified_at, created_at, updated_at"
    )
    .eq("id", user.id)
    .single();

  const profile = profileRow as unknown as Profile | null;

  if (!profile) {
    redirect("/auth/login");
  }

  // Server-side role gate. The browser cannot fake this because RLS
  // only returns the user's own profile row, and even if they could
  // see another profile, they cannot change their own role (the
  // update_my_profile() RPC forbids it).
  if (profile.role !== role) {
    redirect(
      profile.role === "owner"
        ? "/dashboard/owner"
        : profile.role === "host"
        ? "/dashboard/host"
        : profile.role === "admin"
        ? "/dashboard"
        : "/dashboard/guest"
    );
  }

  return (
    <div className="bg-void min-h-[calc(100vh-4rem)]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <DashboardHeader profile={profile} role={role} />
        <div className="mt-8">{children}</div>
      </div>
    </div>
  );
}

function DashboardHeader({ profile, role }: { profile: Profile; role: UserRole }) {
  const roleLabel =
    role === "owner"
      ? "Owner"
      : role === "host"
      ? "Host"
      : role === "admin"
      ? "Admin"
      : "Guest";

  return (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
      <div className="flex items-center gap-4">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-surface border border-divider text-teal-300 font-semibold">
          {profile.full_name
            .split(/\s+/)
            .slice(0, 2)
            .map((s) => s[0])
            .join("")
            .toUpperCase() || "?"}
        </div>
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
            Welcome, {profile.full_name.split(" ")[0]}
          </h1>
          <p className="text-sm text-foreground-muted mt-1 flex items-center gap-2">
            <span className="capitalize">{roleLabel}</span>
            {profile.kyc_status === "verified" && (
              <span className="verified-badge">Verified</span>
            )}
            <span className="text-foreground-faint">·</span>
            <span className="text-foreground-faint">{profile.email}</span>
          </p>
        </div>
      </div>
    </div>
  );
}
