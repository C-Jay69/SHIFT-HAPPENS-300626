"use client";

import { useState, type FormEvent } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import type { UserRole } from "@/types";
import { SIGNUP_ROLES } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Home, Users, Star, ShieldCheck, Eye, EyeOff, Loader2, AlertCircle } from "lucide-react";
import { toast } from "sonner";

const ROLE_OPTIONS: {
  value: UserRole;
  label: string;
  description: string;
  icon: React.ReactNode;
  accent: string;
}[] = [
  {
    value: "owner",
    label: "Owner",
    description: "List properties, manage pricing, receive host applications and payouts.",
    icon: <Home className="h-5 w-5" aria-hidden />,
    accent: "border-ember-500/60 bg-ember-500/5",
  },
  {
    value: "host",
    label: "Host",
    description: "Complete KYC, apply to manage properties, communicate, receive compensation.",
    icon: <Users className="h-5 w-5" aria-hidden />,
    accent: "border-teal-500/60 bg-teal-500/5",
  },
  {
    value: "guest",
    label: "Guest",
    description: "Search properties, get deterministic quotes, book stays, leave reviews.",
    icon: <Star className="h-5 w-5" aria-hidden />,
    accent: "border-gold-500/60 bg-gold-500/5",
  },
];

export function SignupForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initialRole = (searchParams.get("role") as UserRole | null);
  const [role, setRole] = useState<UserRole | null>(
    initialRole && SIGNUP_ROLES.includes(initialRole) ? initialRole : null
  );
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (!role) {
      setError("Please pick a role.");
      return;
    }
    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }

    setSubmitting(true);
    const supabase = createClient();
    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          role,
          full_name: fullName,
        },
      },
    });

    if (signUpError) {
      setSubmitting(false);
      setError(signUpError.message);
      return;
    }

    // Per the spec, the `handle_new_user()` trigger creates a profile row
    // with the chosen role (owner/host/guest) — admin is NEVER selectable
    // at signup. Unknown / malformed roles collapse to 'guest'.

    toast.success("Account created", {
      description: "Check your email for a confirmation link, then sign in.",
    });

    setSubmitting(false);
    router.push(`/auth/login?email=${encodeURIComponent(email)}`);
  }

  return (
    <Card className="bg-card-surface border-divider">
      <CardHeader>
        <CardTitle className="text-foreground">Create your Nest account</CardTitle>
        <CardDescription className="text-foreground-muted">
          Pick the role that fits you. Admin role cannot be self-selected.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-5">
          <fieldset>
            <legend className="text-sm font-medium text-foreground mb-2">
              Role <span className="text-danger">*</span>
            </legend>
            <div className="grid gap-3 sm:grid-cols-3">
              {ROLE_OPTIONS.map((opt) => {
                const selected = role === opt.value;
                return (
                  <button
                    type="button"
                    key={opt.value}
                    onClick={() => setRole(opt.value)}
                    aria-pressed={selected}
                    className={`text-left rounded-lg border p-3 transition-all ${
                      selected
                        ? `${opt.accent} ring-2 ring-offset-2 ring-offset-void ring-teal-500`
                        : "border-divider bg-surface hover:border-foreground-faint"
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      {opt.icon}
                      <span className="font-medium text-foreground">{opt.label}</span>
                    </div>
                    <p className="text-xs text-foreground-muted leading-snug">
                      {opt.description}
                    </p>
                  </button>
                );
              })}
            </div>
            <p className="mt-2 text-xs text-foreground-faint flex items-center gap-1">
              <ShieldCheck className="h-3 w-3" aria-hidden />
              Role is enforced server-side. The <code className="text-foreground-muted">admin</code> role is intentionally absent.
            </p>
          </fieldset>

          <div className="space-y-2">
            <Label htmlFor="full_name" className="text-foreground">
              Full name
            </Label>
            <Input
              id="full_name"
              type="text"
              autoComplete="name"
              required
              minLength={1}
              maxLength={120}
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="bg-surface border-divider text-foreground placeholder:text-foreground-faint"
              placeholder="Alex Rivera"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email" className="text-foreground">
              Email
            </Label>
            <Input
              id="email"
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-surface border-divider text-foreground placeholder:text-foreground-faint"
              placeholder="you@example.com"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-foreground">
              Password
            </Label>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                autoComplete="new-password"
                required
                minLength={8}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-surface border-divider text-foreground placeholder:text-foreground-faint pr-10"
                placeholder="At least 8 characters"
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-foreground-faint hover:text-foreground-muted"
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4" aria-hidden />
                ) : (
                  <Eye className="h-4 w-4" aria-hidden />
                )}
              </button>
            </div>
          </div>

          {error && (
            <div className="rounded-md border border-danger/40 bg-danger/10 px-3 py-2 text-sm text-danger flex items-start gap-2">
              <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" aria-hidden />
              <span>{error}</span>
            </div>
          )}

          <Button
            type="submit"
            disabled={submitting}
            className="btn-primary-gradient w-full"
          >
            {submitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden />
                Creating account…
              </>
            ) : (
              "Create account"
            )}
          </Button>
        </form>
      </CardContent>
      <CardFooter className="border-t border-divider pt-4">
        <p className="text-sm text-foreground-muted">
          Already have an account?{" "}
          <Link href="/auth/login" className="text-teal-300 hover:text-teal-500 underline">
            Sign in
          </Link>
        </p>
      </CardFooter>
    </Card>
  );
}
