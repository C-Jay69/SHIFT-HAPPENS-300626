import { NextRequest, NextResponse } from "next/server";
import { createProperty, getAuthenticatedProfile, listOwnerProperties } from "@/lib/properties";
import type { PropertyCreateInput } from "@/lib/properties";

/**
 * GET /api/properties
 *   Returns the authenticated user's own properties (owner scope).
 *   Public listings are served from /api/properties?scope=public.
 *
 * POST /api/properties
 *   Creates a new property owned by the authenticated user.
 *   Only `owner` role may create properties.
 */
export async function GET(req: NextRequest) {
  const scope = req.nextUrl.searchParams.get("scope") ?? "own";
  const profile = await getAuthenticatedProfile();
  if (!profile) {
    return NextResponse.json({ error: "unauthenticated" }, { status: 401 });
  }

  if (scope === "public") {
    // Public listings — no auth needed strictly, but the caller is
    // already authenticated so we just return public-listed rows.
    // (RLS on the anon client already filters to status in listed/managed
    // OR owned by caller.)
    const supabase = await import("@/lib/supabase/server").then((m) => m.createClient());
    const { data, error } = await (await supabase)
      .from("properties")
      .select("id, title, description, base_price_minor, currency, bedrooms, bathrooms, max_guests, photos, cover_photo, status, latitude, longitude, address_json")
      .in("status", ["listed", "managed"])
      .order("created_at", { ascending: false });
    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    return NextResponse.json({ properties: data });
  }

  if (profile.role !== "owner") {
    return NextResponse.json({ error: "must_be_owner" }, { status: 403 });
  }

  const properties = await listOwnerProperties(profile.id);
  return NextResponse.json({ properties });
}

export async function POST(req: NextRequest) {
  const profile = await getAuthenticatedProfile();
  if (!profile) {
    return NextResponse.json({ error: "unauthenticated" }, { status: 401 });
  }
  if (profile.role !== "owner") {
    return NextResponse.json({ error: "must_be_owner" }, { status: 403 });
  }

  let body: Partial<PropertyCreateInput>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "invalid_json" }, { status: 400 });
  }

  if (!body.title || body.title.length < 3 || body.title.length > 140) {
    return NextResponse.json({ error: "title must be 3-140 chars" }, { status: 400 });
  }
  if (!body.base_price_minor || body.base_price_minor <= 0) {
    return NextResponse.json({ error: "base_price_minor required and > 0" }, { status: 400 });
  }
  if (!body.min_price_minor || !body.max_price_minor) {
    return NextResponse.json({ error: "min_price_minor and max_price_minor required" }, { status: 400 });
  }
  if (body.min_price_minor > body.base_price_minor) {
    return NextResponse.json({ error: "min_price must be <= base_price" }, { status: 400 });
  }
  if (body.base_price_minor > body.max_price_minor) {
    return NextResponse.json({ error: "base_price must be <= max_price" }, { status: 400 });
  }

  try {
    const property = await createProperty(profile.id, {
      title: body.title,
      description: body.description,
      address_json: body.address_json,
      latitude: body.latitude,
      longitude: body.longitude,
      bedrooms: body.bedrooms,
      bathrooms: body.bathrooms,
      max_guests: body.max_guests,
      amenities: body.amenities,
      base_price_minor: body.base_price_minor,
      min_price_minor: body.min_price_minor,
      max_price_minor: body.max_price_minor,
      currency: body.currency,
      cleaning_fee_minor: body.cleaning_fee_minor,
      status: body.status,
    });
    return NextResponse.json({ property }, { status: 201 });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
