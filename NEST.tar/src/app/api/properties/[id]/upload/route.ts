import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import {
  getProperty,
  getAuthenticatedProfile,
  updateProperty,
} from "@/lib/properties";
import {
  validateFileMetadata,
  isValidPropertyPhotoPath,
  MAX_UPLOAD_FILES,
  MAX_FILE_SIZE_BYTES,
} from "@/lib/storage/upload-validation";
import { resizeImageForStorage } from "@/lib/storage/resize";
import { propertyPhotoPath } from "@/lib/ai/vision";
import { createServiceClient } from "@/lib/supabase/service";

/**
 * POST /api/properties/[id]/upload
 *
 * Upload one or more property photos.
 *
 * Per docs/SPEC.md §7:
 *   - Validate authenticated user, object ownership/path, MIME type,
 *     extension, file size, maximum image dimensions, number of files.
 *   - Re-encode uploaded property images server-side before AI processing.
 *   - Do not trust the browser-provided MIME type alone.
 *   - Strip unnecessary image metadata, including EXIF.
 *
 * Authorization: only the property's owner may upload photos.
 *
 * Returns the updated photo paths array. The client should then trigger
 * /api/properties/[id]/analyze-vision to re-run vision analysis on the
 * new photo set.
 *
 * Path shape (per §7 + vision.ts):
 *   property-photos/properties/{propertyId}/{uuid}.jpg
 */
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const profile = await getAuthenticatedProfile();
  if (!profile) {
    return NextResponse.json({ error: "unauthenticated" }, { status: 401 });
  }
  if (profile.role !== "owner") {
    return NextResponse.json({ error: "must_be_owner" }, { status: 403 });
  }

  const property = await getProperty(id);
  if (!property) {
    return NextResponse.json({ error: "not_found" }, { status: 404 });
  }
  if (property.owner_id !== profile.id) {
    return NextResponse.json({ error: "not_authorized" }, { status: 403 });
  }

  // Reject if already at max file count.
  if (property.photos.length >= MAX_UPLOAD_FILES) {
    return NextResponse.json(
      { error: `max_files_reached:${MAX_UPLOAD_FILES}` },
      { status: 400 }
    );
  }

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return NextResponse.json({ error: "invalid_form_data" }, { status: 400 });
  }

  const files = form.getAll("files").filter(
    (f): f is File => f instanceof File
  );

  if (files.length === 0) {
    return NextResponse.json({ error: "no_files" }, { status: 400 });
  }
  if (property.photos.length + files.length > MAX_UPLOAD_FILES) {
    return NextResponse.json(
      {
        error: `too_many_files:would_exceed_max:${MAX_UPLOAD_FILES}`,
      },
      { status: 400 }
    );
  }

  // Validate each file's metadata.
  const validationErrors: string[] = [];
  for (const file of files) {
    const r = validateFileMetadata(
      { name: file.name, type: file.type, size: file.size },
      { maxBytes: MAX_FILE_SIZE_BYTES }
    );
    if (!r.ok) validationErrors.push(...r.errors);
  }
  if (validationErrors.length > 0) {
    return NextResponse.json(
      { error: "validation_failed", details: validationErrors },
      { status: 400 }
    );
  }

  // Resize + upload each file.
  const serviceClient = createServiceClient();
  const newPaths: string[] = [];

  for (const file of files) {
    try {
      const rawBuf = Buffer.from(await file.arrayBuffer());

      // The actual MIME trust boundary (§7): sharp re-encodes, so a file
      // lying about Content-Type will fail here.
      const resized = await resizeImageForStorage(rawBuf);

      const fileUuid = randomUUID();
      const objectPath = propertyPhotoPath(id, fileUuid);

      if (!isValidPropertyPhotoPath(objectPath, id)) {
        // Should never happen because we generated the path ourselves.
        throw new Error("invalid_path_generated");
      }

      const { error: uploadErr } = await serviceClient.storage
        .from("property-photos")
        .upload(objectPath, resized, {
          contentType: "image/jpeg",
          cacheControl: "3600",
          upsert: false,
        });

      if (uploadErr) {
        // Skip this file but keep going with the others.
        continue;
      }

      newPaths.push(objectPath);
    } catch {
      // Skip the file that failed to decode; do not abort the whole batch.
      continue;
    }
  }

  if (newPaths.length === 0) {
    return NextResponse.json(
      { error: "all_files_failed_to_process" },
      { status: 422 }
    );
  }

  // Append to the property's photos array + clear vision_status so the
  // next /analyze-vision call knows to re-run.
  const updatedPhotos = [...property.photos, ...newPaths];
  try {
    const updated = await updateProperty(id, profile.id, {
      photos: updatedPhotos,
    });
    return NextResponse.json({
      property: updated,
      uploaded_paths: newPaths,
      vision_stale: true,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

/**
 * DELETE /api/properties/[id]/upload?path=properties/{id}/{uuid}.jpg
 *
 * Remove a single photo. Validates ownership AND path shape before
 * deleting from storage and the database row.
 */
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const profile = await getAuthenticatedProfile();
  if (!profile) {
    return NextResponse.json({ error: "unauthenticated" }, { status: 401 });
  }
  if (profile.role !== "owner") {
    return NextResponse.json({ error: "must_be_owner" }, { status: 403 });
  }

  const property = await getProperty(id);
  if (!property) {
    return NextResponse.json({ error: "not_found" }, { status: 404 });
  }
  if (property.owner_id !== profile.id) {
    return NextResponse.json({ error: "not_authorized" }, { status: 403 });
  }

  const objectPath = req.nextUrl.searchParams.get("path");
  if (!objectPath) {
    return NextResponse.json({ error: "path_param_required" }, { status: 400 });
  }

  // Per §7: never trust a client-supplied path without verifying shape.
  if (!isValidPropertyPhotoPath(objectPath, id)) {
    return NextResponse.json({ error: "invalid_path" }, { status: 400 });
  }
  if (!property.photos.includes(objectPath)) {
    return NextResponse.json({ error: "path_not_in_property" }, { status: 404 });
  }

  const serviceClient = createServiceClient();
  const { error: delErr } = await serviceClient.storage
    .from("property-photos")
    .remove([objectPath]);
  if (delErr) {
    // Continue — we still want to remove the path from the photos array.
  }

  const updatedPhotos = property.photos.filter((p) => p !== objectPath);
  const cover_photo =
    property.cover_photo === objectPath ? null : property.cover_photo;

  try {
    const updated = await updateProperty(id, profile.id, {
      photos: updatedPhotos,
      cover_photo,
    });
    return NextResponse.json({
      property: updated,
      deleted_path: objectPath,
      vision_stale: true,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
