import { NextRequest, NextResponse } from "next/server";
import {
  getProperty,
  getAuthenticatedProfile,
  updateProperty,
  type PropertyPatchInput,
} from "@/lib/properties";
import { createSignedUrls } from "@/lib/storage/signed-urls";

/**
 * GET /api/properties/[id]
 *   Returns the property if visible to the caller (RLS enforces:
 *   public-listed/managed OR owned by caller OR assigned host OR admin).
 *   Private photo paths are resolved to short-lived signed URLs.
 *
 * PATCH /api/properties/[id]
 *   Updates allowed fields. Only the owner may patch. Only fields
 *   explicitly listed in PropertyPatchInput are accepted — assigned_host_id,
 *   vision_*, status='managed'|'pending_host'|'suspended' cannot be
 *   set through this endpoint.
 */
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const profile = await getAuthenticatedProfile();

  const property = await getProperty(id);
  if (!property) {
    return NextResponse.json({ error: "not_found" }, { status: 404 });
  }

  // Check visibility per RLS rules:
  //   - status listed/managed → public
  //   - status draft/etc → only owner / assigned_host / admin
  const isVisible =
    property.status === "listed" ||
    property.status === "managed" ||
    (profile && property.owner_id === profile.id) ||
    (profile && property.assigned_host_id === profile.id) ||
    (profile && profile.role === "admin");

  if (!isVisible) {
    return NextResponse.json({ error: "not_found" }, { status: 404 });
  }

  // Resolve photo paths to short-lived signed URLs for the caller.
  // Per §5.2 + §7: never persist signed URLs; never log them.
  let photosWithUrls: Array<{ path: string; url: string | null }> = [];
  if (property.photos.length > 0) {
    const urls = await createSignedUrls("property-photos", property.photos);
    photosWithUrls = property.photos.map((path, i) => ({
      path,
      url: urls[i] ?? null,
    }));
  }

  // Vision analysis is visible to: owner, assigned_host, admin.
  // Guests see only a redacted version (the "AI-assessed highlights"
  // mentioned in §0 rule 1: "can provide clearly labelled AI-assessed
  // highlights to guests").
  const includeFullVision =
    profile && (
      property.owner_id === profile.id ||
      property.assigned_host_id === profile.id ||
      profile.role === "admin"
    );

  return NextResponse.json({
    property: {
      ...property,
      photos_with_urls: photosWithUrls,
      vision_analysis: includeFullVision ? property.vision_analysis : redactVisionForGuest(property.vision_analysis),
      vision_full_access: includeFullVision,
    },
    viewer: profile
      ? { id: profile.id, role: profile.role }
      : null,
  });
}

function redactVisionForGuest(
  analysis: Record<string, unknown> | null
): Record<string, unknown> | null {
  if (!analysis) return null;
  // Per §0 rule 1: guests see "clearly labelled AI-assessed highlights".
  // We expose a curated subset: quality_tier, notable_features (up to 5),
  // aesthetic_vibe, estimated_size_bracket, lighting_quality, confidence.
  // We DO NOT expose: condition_score, interior_modernity_score,
  // curb_appeal_score, red_flags, visual_justification. Owners see those.
  return {
    quality_tier: (analysis as Record<string, unknown>).quality_tier ?? null,
    notable_features: ((analysis as Record<string, unknown>).notable_features as string[] | undefined)?.slice(0, 5) ?? [],
    aesthetic_vibe: (analysis as Record<string, unknown>).aesthetic_vibe ?? null,
    estimated_size_bracket: (analysis as Record<string, unknown>).estimated_size_bracket ?? null,
    lighting_quality: (analysis as Record<string, unknown>).lighting_quality ?? null,
    confidence: (analysis as Record<string, unknown>).confidence ?? null,
    _disclaimer: "AI-assessed highlights. Not independently verified fact.",
  };
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const profile = await getAuthenticatedProfile();
  if (!profile) {
    return NextResponse.json({ error: "unauthenticated" }, { status: 401 });
  }
  if (profile.role !== "owner") {
    return NextResponse.json({ error: "must_be_owner" }, { status: 403 });
  }

  let body: Partial<PropertyPatchInput>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "invalid_json" }, { status: 400 });
  }

  // Reject any attempt to set forbidden fields.
  const forbidden = [
    "assigned_host_id",
    "vision_analysis",
    "vision_status",
    "vision_analyzed_at",
    "vision_model",
    "vision_schema_version",
    "vision_photos_hash",
    "owner_id",
    "id",
    "created_at",
    "updated_at",
  ];
  for (const f of forbidden) {
    if (f in body) {
      return NextResponse.json(
        { error: `field_not_allowed: ${f}` },
        { status: 400 }
      );
    }
  }
  // Only allow status values draft/listed through this route.
  // managed/pending_host/suspended are admin-only.
  if (body.status && !["draft", "listed"].includes(body.status)) {
    return NextResponse.json(
      { error: "status_not_allowed_through_this_route" },
      { status: 400 }
    );
  }

  try {
    const updated = await updateProperty(id, profile.id, body);
    return NextResponse.json({ property: updated });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes("NOT_AUTHORIZED")) {
      return NextResponse.json({ error: "not_authorized" }, { status: 403 });
    }
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
