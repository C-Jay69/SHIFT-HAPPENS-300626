import { NextRequest, NextResponse } from "next/server";
import {
  getProperty,
  getAuthenticatedProfile,
} from "@/lib/properties";
import { createSignedUrl } from "@/lib/storage/signed-urls";
import { isValidPropertyPhotoPath } from "@/lib/storage/upload-validation";

/**
 * GET /api/properties/[id]/photo?path=properties/{id}/{uuid}.jpg
 *
 * Returns a 302 redirect to a short-lived signed URL for a private
 * property photo. The signed URL is generated server-side from the
 * authorized storage path — never from a client-supplied URL (§7:
 * "Never allow AI routes to accept arbitrary remote image URLs from
 * users. Resolve authorized storage paths server-side.").
 *
 * Authorization:
 *   - For listed/managed properties: anyone may view (public listings).
 *   - For draft properties: only the owner, assigned host, or admin.
 */
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const objectPath = req.nextUrl.searchParams.get("path");
  if (!objectPath) {
    return NextResponse.json({ error: "path_required" }, { status: 400 });
  }
  if (!isValidPropertyPhotoPath(objectPath, id)) {
    return NextResponse.json({ error: "invalid_path" }, { status: 400 });
  }

  const property = await getProperty(id);
  if (!property) {
    return NextResponse.json({ error: "not_found" }, { status: 404 });
  }

  // Visibility check (mirrors /api/properties/[id] GET).
  if (property.status !== "listed" && property.status !== "managed") {
    const profile = await getAuthenticatedProfile();
    const isVisible =
      profile &&
      (property.owner_id === profile.id ||
        property.assigned_host_id === profile.id ||
        profile.role === "admin");
    if (!isVisible) {
      return NextResponse.json({ error: "not_found" }, { status: 404 });
    }
  }

  // Confirm the path actually belongs to this property's photo set.
  if (!property.photos.includes(objectPath)) {
    return NextResponse.json({ error: "not_in_property" }, { status: 404 });
  }

  const url = await createSignedUrl("property-photos", objectPath, 60);
  if (!url) {
    return NextResponse.json(
      { error: "signed_url_failed" },
      { status: 500 }
    );
  }

  // 302 to the short-lived signed URL. The signed URL is never persisted
  // by the client (it lives only in the redirect hop).
  return NextResponse.redirect(url, 302);
}
