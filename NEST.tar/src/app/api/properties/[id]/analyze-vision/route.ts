import { NextRequest, NextResponse } from "next/server";
import {
  getProperty,
  getAuthenticatedProfile,
  setVisionStatus,
  persistVisionAnalysis,
} from "@/lib/properties";
import { analyzePropertyVision, isVisionEnabled, computePhotosHash } from "@/lib/ai/vision";

/**
 * POST /api/properties/[id]/analyze-vision
 *
 * Triggers vision analysis on a property's photos.
 *
 * Per docs/SPEC.md §9:
 *   - Vision begins after property photographs change.
 *   - Compute a deterministic hash of the relevant image object identifiers.
 *   - If the hash differs from the last successfully analyzed set:
 *       vision_status = pending → queue processing.
 *
 * Per §0 rule 1: vision runs asynchronously, never blocks the owner's
 * save operation. For Phase 2 we run it inline (no n8n yet — that's
 * Phase 6) but still return immediately if the photos haven't changed
 * since the last analysis.
 *
 * Per §37 Phase 2 acceptance:
 *   - Vision processing starts asynchronously (here: kicks off inline).
 *   - A schema-valid analysis is persisted with model/schema metadata.
 *   - A provider failure produces a safe failed/retryable state instead
 *     of crashing the property page.
 *
 * Authorization: owner only (or admin). Assigned host may not trigger
 * vision analysis — only the owner controls the photo set.
 */
export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const profile = await getAuthenticatedProfile();
  if (!profile) {
    return NextResponse.json({ error: "unauthenticated" }, { status: 401 });
  }
  if (profile.role !== "owner" && profile.role !== "admin") {
    return NextResponse.json({ error: "must_be_owner_or_admin" }, { status: 403 });
  }

  const property = await getProperty(id);
  if (!property) {
    return NextResponse.json({ error: "not_found" }, { status: 404 });
  }
  if (property.owner_id !== profile.id && profile.role !== "admin") {
    return NextResponse.json({ error: "not_authorized" }, { status: 403 });
  }

  if (!isVisionEnabled()) {
    return NextResponse.json(
      { error: "vision_disabled", vision_status: property.vision_status },
      { status: 400 }
    );
  }

  if (property.photos.length === 0) {
    return NextResponse.json(
      { error: "no_photos", vision_status: property.vision_status },
      { status: 400 }
    );
  }

  // Compute the deterministic hash. If it matches the last successful
  // analysis, return the cached result instead of re-running.
  const currentHash = computePhotosHash(property.photos);
  if (
    property.vision_status === "complete" &&
    property.vision_photos_hash === currentHash &&
    property.vision_analysis
  ) {
    return NextResponse.json({
      status: "complete",
      cached: true,
      vision_status: "complete",
      photos_hash: currentHash,
    });
  }

  // Mark as processing.
  await setVisionStatus(id, "processing");

  try {
    const result = await analyzePropertyVision({
      propertyId: id,
      photoPaths: property.photos,
    });

    await persistVisionAnalysis(id, {
      vision_analysis: result.analysis as unknown as Record<string, unknown>,
      vision_status: "complete",
      vision_analyzed_at: new Date().toISOString(),
      vision_model: result.model,
      vision_schema_version: result.schemaVersion,
      vision_photos_hash: result.photosHash,
    });

    return NextResponse.json({
      status: "complete",
      cached: false,
      vision_status: "complete",
      model: result.model,
      provider: result.provider,
      schema_version: result.schemaVersion,
      photos_hash: result.photosHash,
      latency_ms: result.latencyMs,
      retries: result.retries,
    });
  } catch (err) {
    // Per §9: vision failure produces a safe failed/retryable state.
    // The property itself remains intact (vision failure must not
    // prevent the property from being saved/listed).
    const errMsg = err instanceof Error ? err.message : String(err);
    await persistVisionAnalysis(id, {
      vision_analysis: { error: "vision_failed", error_message: errMsg.slice(0, 500) },
      vision_status: "failed",
      vision_analyzed_at: new Date().toISOString(),
      vision_model: null,
      vision_schema_version: null,
      vision_photos_hash: currentHash,
    });
    return NextResponse.json(
      {
        status: "failed",
        vision_status: "failed",
        error: errMsg.slice(0, 500),
      },
      { status: 200 }
    );
  }
}
