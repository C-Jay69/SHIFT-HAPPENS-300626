import { promises as fs } from "fs";
import path from "path";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, ArrowLeft, Construction } from "lucide-react";

export default async function DocsPage() {
  let specContent = "";
  let specError: string | null = null;

  try {
    const specPath = path.join(process.cwd(), "docs", "SPEC.md");
    specContent = await fs.readFile(specPath, "utf8");
  } catch (err) {
    specError = err instanceof Error ? err.message : String(err);
  }

  const phases = [
    { id: "phase-1", title: "Phase 1 — Foundation", status: "IN PROGRESS", color: "text-teal-300" },
    { id: "phase-2", title: "Phase 2 — Property + Vision", status: "NOT STARTED", color: "text-foreground-faint" },
    { id: "phase-3", title: "Phase 3 — Bookings + Payments", status: "NOT STARTED", color: "text-foreground-faint" },
    { id: "phase-4", title: "Phase 4 — Trust", status: "NOT STARTED", color: "text-foreground-faint" },
    { id: "phase-5", title: "Phase 5 — Pricing + Disputes", status: "NOT STARTED", color: "text-foreground-faint" },
    { id: "phase-6", title: "Phase 6 — Admin + Automation", status: "NOT STARTED", color: "text-foreground-faint" },
    { id: "phase-7", title: "Phase 7 — Security + Operations + Launch", status: "NOT STARTED", color: "text-foreground-faint" },
  ];

  return (
    <div className="bg-void min-h-[calc(100vh-4rem)]">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-12">
        <Link href="/" className="inline-flex items-center text-sm text-foreground-muted hover:text-foreground mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" aria-hidden />
          Back to home
        </Link>

        <div className="flex items-center gap-3 mb-3">
          <FileText className="h-7 w-7 text-teal-500" aria-hidden />
          <h1 className="text-3xl sm:text-4xl font-bold text-foreground">Nest Specification</h1>
        </div>
        <p className="text-foreground-muted max-w-2xl">
          The authoritative product and engineering specification for Nest v5.
          This document is the single source of truth — if implementation
          code conflicts with this specification, the implementation is
          considered incorrect unless this specification has first been
          deliberately amended.
        </p>

        {/* Phase tracker */}
        <Card className="bg-card-surface border-divider mt-8">
          <CardHeader>
            <CardTitle className="text-foreground flex items-center gap-2">
              <Construction className="h-5 w-5 text-gold-500" aria-hidden />
              Build phases
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {phases.map((p) => (
                <li key={p.id} id={p.id} className="flex items-center justify-between gap-4 py-1.5 border-b border-divider last:border-b-0">
                  <span className="text-sm text-foreground">{p.title}</span>
                  <span className={`text-xs font-mono ${p.color}`}>{p.status}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Spec content */}
        <Card className="bg-card-surface border-divider mt-8">
          <CardHeader>
            <CardTitle className="text-foreground">docs/SPEC.md</CardTitle>
          </CardHeader>
          <CardContent>
            {specError ? (
              <div className="text-sm text-danger">
                Failed to load SPEC.md: {specError}
              </div>
            ) : (
              <pre className="text-xs text-foreground-muted whitespace-pre-wrap font-mono leading-relaxed max-h-[600px] overflow-y-auto bg-surface p-4 rounded border border-divider">
                {specContent}
              </pre>
            )}
          </CardContent>
        </Card>

        <div className="mt-8 flex flex-wrap gap-3">
          <Link href="/auth/signup">
            <Button className="btn-primary-gradient">Create your account</Button>
          </Link>
          <Link href="/auth/login">
            <Button variant="outline" className="border-divider text-foreground-muted">
              Sign in
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
