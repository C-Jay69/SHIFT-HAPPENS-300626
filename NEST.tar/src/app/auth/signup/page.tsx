import { SignupForm } from "@/components/auth/signup-form";

export default function SignupPage() {
  return (
    <div className="min-h-[calc(100vh-4rem)] bg-void py-12 sm:py-16">
      <div className="mx-auto max-w-lg px-4 sm:px-6">
        <SignupForm />
      </div>
    </div>
  );
}
