import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ShieldCheck, ArrowRight } from "lucide-react";

export default function VerifyIdentityPage() {
  return (
    <div className="min-h-[calc(100vh-4rem)] bg-void py-12 sm:py-16">
      <div className="mx-auto max-w-lg px-4 sm:px-6">
        <Card className="bg-card-surface border-divider">
          <CardHeader>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 rounded-md bg-surface border border-divider">
                <ShieldCheck className="h-5 w-5 text-gold-500" aria-hidden />
              </div>
              <CardTitle className="text-foreground">Identity verification</CardTitle>
            </div>
            <CardDescription className="text-foreground-muted">
              Hosts must complete KYC before applying to manage properties.
              Identity verification is enforced at the UI, server API, and
              database layers (see docs/SPEC.md §14, §5.6).
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border border-divider bg-surface p-4 text-sm text-foreground-muted">
              <p className="font-medium text-foreground mb-1">
                Phase 1 — Foundation
              </p>
              <p>
                The full KYC flow (Stripe Identity session creation, document
                capture, webhook verification) ships in Phase 4 — Trust.
                The database schema, RLS policies, and{" "}
                <code className="text-foreground-muted">enforce_host_application_kyc</code>{" "}
                trigger are already in place and tested by the adversarial
                suite (<code className="text-foreground-muted">tests/rls.test.ts</code>).
              </p>
            </div>
            <div className="mt-6 flex flex-col sm:flex-row gap-3">
              <Link href="/dashboard/host">
                <Button variant="outline" className="border-divider text-foreground-muted w-full sm:w-auto">
                  Back to dashboard
                </Button>
              </Link>
              <Link href="/docs">
                <Button className="btn-primary-gradient w-full sm:w-auto">
                  Read the spec
                  <ArrowRight className="ml-2 h-4 w-4" aria-hidden />
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
