import { LoginForm } from "@/components/auth/login-form";

export default function LoginPage() {
  return (
    <div className="min-h-[calc(100vh-4rem)] bg-void py-12 sm:py-16">
      <div className="mx-auto max-w-md px-4 sm:px-6">
        <LoginForm />
      </div>
    </div>
  );
}
