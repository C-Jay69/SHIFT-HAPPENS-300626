import Link from "next/link";
import { listPublicProperties, type PropertyRow } from "@/lib/properties";
import { formatMinor } from "@/lib/money";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search, MapPin, BedDouble, Bath, Users, Sparkles, Eye, AlertCircle, ArrowLeft } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const sp = await searchParams;
  const query = (sp.q ?? "").trim().toLowerCase();

  let all: PropertyRow[] = [];
  let notConfigured = false;
  try {
    all = await listPublicProperties();
  } catch {
    notConfigured = true;
  }

  // Client-side filter as a lightweight stand-in for Postgres full-text
  // search. Phase 5 will swap to a proper pg_trgm + GiST index.
  const filtered = query
    ? all.filter(
        (p) =>
          p.title.toLowerCase().includes(query) ||
          (p.description ?? "").toLowerCase().includes(query) ||
          (Array.isArray(p.amenities) && p.amenities.some((a: string) => a.toLowerCase().includes(query)))
      )
    : all;

  return (
    <div className="bg-void min-h-[calc(100vh-4rem)]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground flex items-center gap-2">
            <Search className="h-7 w-7 text-teal-500" aria-hidden />
            Find your next stay
          </h1>
          <p className="text-sm text-foreground-muted mt-1">
            {notConfigured
              ? "Search is wired and ready — connect Supabase to see listings."
              : `${filtered.length} ${filtered.length === 1 ? "property" : "properties"} available`}
          </p>
        </div>

        {notConfigured ? (
          <Card className="bg-card-surface border-divider">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-warning" aria-hidden />
                Supabase not configured
              </CardTitle>
              <CardDescription className="text-foreground-muted">
                Public property listings come from Supabase. Phase 2 is wired
                and ready — copy <code className="text-foreground">.env.example</code> to
                <code className="text-foreground"> .env.local</code>, fill in your
                Supabase keys, and apply migrations.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/">
                <Button variant="outline" className="border-divider text-foreground-muted">
                  <ArrowLeft className="mr-2 h-4 w-4" aria-hidden />
                  Back to home
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <>
            <form className="mb-8">
              <label htmlFor="q" className="sr-only">
                Search by title, description, or amenity
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-foreground-faint" aria-hidden />
                <input
                  id="q"
                  name="q"
                  type="search"
                  defaultValue={query}
                  placeholder="Search by title, description, or amenity"
                  className="w-full pl-10 pr-4 py-2.5 rounded-md border border-divider bg-surface text-foreground placeholder:text-foreground-faint focus:border-teal-500 focus:outline-none focus:ring-1 focus:ring-teal-500"
                />
              </div>
            </form>

            {filtered.length === 0 ? (
              <Card className="bg-card-surface border-divider border-dashed">
                <CardHeader>
                  <CardTitle className="text-foreground">No properties found</CardTitle>
                  <CardDescription className="text-foreground-muted">
                    {query
                      ? `No matches for "${query}". Try a different search.`
                      : "No properties have been listed yet. Owners can list properties from their dashboard."}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Link href="/auth/signup?role=owner">
                    <Button className="btn-primary-gradient">Become an owner</Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                {filtered.map((p) => (
                  <PropertyCard key={p.id} property={p} />
                ))}
              </ul>
            )}
          </>
        )}
      </div>
    </div>
  );
}

function PropertyCard({ property: p }: { property: PropertyRow }) {
  const coverPhoto = p.cover_photo ?? p.photos[0] ?? null;
  const hasVision = p.vision_status === "complete" && p.vision_analysis;

  return (
    <li>
      <Link href={`/property/${p.id}`}>
        <Card className="bg-card-surface border-divider hover:border-teal-500/60 transition-colors overflow-hidden h-full">
          <div className="aspect-[16/10] bg-surface relative overflow-hidden">
            {coverPhoto ? (
               
              <img
                src={`/api/properties/${p.id}/photo?path=${encodeURIComponent(coverPhoto)}`}
                alt={p.title}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="h-full w-full flex items-center justify-center text-foreground-faint">
                <Sparkles className="h-8 w-8" aria-hidden />
              </div>
            )}
            {hasVision && (
              <span className="absolute top-2 right-2 inline-flex items-center gap-1 rounded-full bg-void/80 backdrop-blur px-2 py-0.5 text-xs text-teal-300 border border-teal-500/40">
                <Eye className="h-3 w-3" aria-hidden />
                AI-assessed
              </span>
            )}
          </div>
          <CardHeader>
            <CardTitle className="text-foreground text-base line-clamp-1">
              {p.title}
            </CardTitle>
            <CardDescription className="text-foreground-muted text-xs flex items-center gap-1">
              <MapPin className="h-3 w-3" aria-hidden />
              {p.address_json && typeof p.address_json === "object" && "city" in p.address_json
                ? String((p.address_json as Record<string, unknown>).city)
                : "Location not set"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-3 gap-2 text-xs text-foreground-muted">
              <span className="flex items-center gap-1">
                <BedDouble className="h-3 w-3" aria-hidden />
                {p.bedrooms} bd
              </span>
              <span className="flex items-center gap-1">
                <Bath className="h-3 w-3" aria-hidden />
                {p.bathrooms} ba
              </span>
              <span className="flex items-center gap-1">
                <Users className="h-3 w-3" aria-hidden />
                {p.max_guests} guests
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-foreground">
                {formatMinor(BigInt(p.base_price_minor), p.currency)}
                <span className="text-xs text-foreground-faint">/night</span>
              </span>
              {p.amenities.length > 0 && (
                <span className="text-xs text-foreground-faint">
                  {p.amenities.slice(0, 3).join(" · ")}
                  {p.amenities.length > 3 ? " · …" : ""}
                </span>
              )}
            </div>
          </CardContent>
        </Card>
      </Link>
    </li>
  );
}
