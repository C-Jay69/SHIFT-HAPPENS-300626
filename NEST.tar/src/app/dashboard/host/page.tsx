import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { HostDashboardEmptyStates } from "@/components/dashboard/empty-states";

export default function HostDashboardPage() {
  return (
    <DashboardShell role="host">
      <HostDashboardEmptyStates />
    </DashboardShell>
  );
}
