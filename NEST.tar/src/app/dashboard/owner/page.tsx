import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { OwnerDashboardEmptyStates } from "@/components/dashboard/empty-states";
import { listOwnerProperties } from "@/lib/properties";

export default async function OwnerDashboardPage() {
  // We need the property count to show the right empty-state copy.
  // Wrap in try/catch so the dashboard still renders if Supabase
  // isn't configured yet (Phase 1 graceful-degradation pattern).
  let hasProperties = false;
  try {
    // We don't import the auth-redirecting wrapper — we just need a
    // property count. The shell already gates auth + role.
    const profile = await (await import("@/lib/properties")).getAuthenticatedProfile();
    if (profile) {
      const properties = await listOwnerProperties(profile.id);
      hasProperties = properties.length > 0;
    }
  } catch {
    // ignore — shell will handle the "not configured" message
  }

  return (
    <DashboardShell role="owner">
      <OwnerDashboardEmptyStates hasProperties={hasProperties} />
    </DashboardShell>
  );
}
