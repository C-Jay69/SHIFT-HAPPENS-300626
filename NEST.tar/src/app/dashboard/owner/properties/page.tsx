import Link from "next/link";
import { redirect } from "next/navigation";
import { getAuthenticatedProfile, listOwnerProperties, type PropertyRow } from "@/lib/properties";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Home, Eye, MapPin, BedDouble, Bath, Users, AlertCircle, ArrowLeft } from "lucide-react";
import { formatMinor } from "@/lib/money";

export default async function OwnerPropertiesPage() {
  let profile;
  try {
    profile = await getAuthenticatedProfile();
  } catch {
    // Supabase not configured — show the friendly fallback below.
    return renderNotConfigured();
  }

  if (!profile) {
    // Not signed in — redirect to login.
    redirect("/auth/login");
  }
  if (profile.role !== "owner") {
    redirect("/dashboard");
  }

  let properties: PropertyRow[] = [];
  let notConfigured = false;
  try {
    properties = await listOwnerProperties(profile.id);
  } catch {
    notConfigured = true;
  }

  if (notConfigured) {
    return renderNotConfigured();
  }

  return (
    <div className="bg-void min-h-[calc(100vh-4rem)]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <div className="flex items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
              Your properties
            </h1>
            <p className="text-sm text-foreground-muted mt-1">
              {properties.length === 0
                ? "You don't have any properties yet."
                : `${properties.length} ${properties.length === 1 ? "property" : "properties"}`}
            </p>
          </div>
          <Link href="/dashboard/owner/properties/new">
            <Button className="btn-primary-gradient">
              <Plus className="mr-2 h-4 w-4" aria-hidden />
              New property
            </Button>
          </Link>
        </div>

        {properties.length === 0 ? (
          <Card className="bg-card-surface border-divider border-dashed">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <Home className="h-5 w-5 text-foreground-muted" aria-hidden />
                No properties yet
              </CardTitle>
              <CardDescription className="text-foreground-muted">
                Create your first property to start receiving host applications
                and guest bookings. Vision analysis will run automatically on
                your uploaded photos.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/dashboard/owner/properties/new">
                <Button className="btn-primary-gradient">
                  <Plus className="mr-2 h-4 w-4" aria-hidden />
                  Create your first property
                </Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {properties.map((p) => (
              <PropertyListItem key={p.id} property={p} />
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function PropertyListItem({ property: p }: { property: PropertyRow }) {
  const visionTone =
    p.vision_status === "complete"
      ? "bg-teal-500/15 text-teal-300 border-teal-500/40"
      : p.vision_status === "failed"
      ? "bg-danger/15 text-danger border-danger/40"
      : p.vision_status === "processing"
      ? "bg-ember-500/15 text-ember-500 border-ember-500/40"
      : "bg-surface text-foreground-muted border-divider";
  const statusTone =
    p.status === "listed"
      ? "bg-teal-500/15 text-teal-300 border-teal-500/40"
      : p.status === "managed"
      ? "bg-gold-500/15 text-gold-500 border-gold-500/40"
      : "bg-surface text-foreground-muted border-divider";

  return (
    <li>
      <Link href={`/dashboard/owner/properties/${p.id}`}>
        <Card className="bg-card-surface border-divider hover:border-teal-500/60 transition-colors h-full">
          <CardHeader>
            <div className="flex items-start justify-between gap-2">
              <CardTitle className="text-foreground text-base line-clamp-2">
                {p.title}
              </CardTitle>
              <span className={`text-xs px-2 py-0.5 rounded-full border whitespace-nowrap ${statusTone}`}>
                {p.status}
              </span>
            </div>
            <CardDescription className="text-foreground-muted text-xs flex items-center gap-1">
              <MapPin className="h-3 w-3" aria-hidden />
              {p.address_json && typeof p.address_json === "object" && "city" in p.address_json
                ? String((p.address_json as Record<string, unknown>).city)
                : "No address set"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-3 gap-2 text-xs text-foreground-muted">
              <span className="flex items-center gap-1">
                <BedDouble className="h-3 w-3" aria-hidden />
                {p.bedrooms} bd
              </span>
              <span className="flex items-center gap-1">
                <Bath className="h-3 w-3" aria-hidden />
                {p.bathrooms} ba
              </span>
              <span className="flex items-center gap-1">
                <Users className="h-3 w-3" aria-hidden />
                {p.max_guests} guests
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-foreground">
                {formatMinor(BigInt(p.base_price_minor), p.currency)}
                <span className="text-xs text-foreground-faint">/night</span>
              </span>
              <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border ${visionTone}`}>
                <Eye className="h-3 w-3" aria-hidden />
                {p.vision_status}
              </span>
            </div>
            {p.photos.length > 0 && (
              <p className="text-xs text-foreground-faint">
                {p.photos.length} photo{p.photos.length === 1 ? "" : "s"}
              </p>
            )}
          </CardContent>
        </Card>
      </Link>
    </li>
  );
}

function renderNotConfigured() {
  return (
    <div className="bg-void min-h-[calc(100vh-4rem)]">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 py-12">
        <Card className="bg-card-surface border-divider">
          <CardHeader>
            <CardTitle className="text-foreground flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-warning" aria-hidden />
              Supabase not configured
            </CardTitle>
            <CardDescription className="text-foreground-muted">
              Property management requires Supabase credentials. Phase 2 is
              wired and ready — copy <code className="text-foreground">.env.example</code> to
              <code className="text-foreground"> .env.local</code>, fill in your Supabase
              keys, and apply migrations.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/dashboard/owner">
              <Button variant="outline" className="border-divider text-foreground-muted">
                <ArrowLeft className="mr-2 h-4 w-4" aria-hidden />
                Back to dashboard
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
