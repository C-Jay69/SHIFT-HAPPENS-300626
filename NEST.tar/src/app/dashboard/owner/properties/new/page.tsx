import { getAuthenticatedProfile } from "@/lib/properties";
import { PropertyForm } from "@/components/property/property-form";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { AlertCircle, ArrowLeft } from "lucide-react";

export default async function NewPropertyPage() {
  let profile;
  try {
    profile = await getAuthenticatedProfile();
  } catch {
    return (
      <div className="bg-void min-h-[calc(100vh-4rem)]">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 py-12">
          <Card className="bg-card-surface border-divider">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-warning" aria-hidden />
                Supabase not configured
              </CardTitle>
              <CardDescription className="text-foreground-muted">
                Creating a property requires Supabase credentials. Phase 2 is
                wired and ready — copy <code className="text-foreground">.env.example</code> to
                <code className="text-foreground"> .env.local</code>, fill in your Supabase
                keys, and apply migrations.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/dashboard/owner">
                <Button variant="outline" className="border-divider text-foreground-muted">
                  <ArrowLeft className="mr-2 h-4 w-4" aria-hidden />
                  Back to dashboard
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="bg-void min-h-[calc(100vh-4rem)]">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 py-12">
          <Card className="bg-card-surface border-divider">
            <CardHeader>
              <CardTitle className="text-foreground">Sign in required</CardTitle>
              <CardDescription className="text-foreground-muted">
                You need to be signed in as an owner to create a property.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/auth/login">
                <Button className="btn-primary-gradient">Sign in</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (profile.role !== "owner") {
    return (
      <div className="bg-void min-h-[calc(100vh-4rem)]">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 py-12">
          <Card className="bg-card-surface border-divider">
            <CardHeader>
              <CardTitle className="text-foreground">Owner role required</CardTitle>
              <CardDescription className="text-foreground-muted">
                Only owner accounts can create properties. Your current role
                is <code className="text-foreground">{profile.role}</code>.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/dashboard">
                <Button variant="outline" className="border-divider text-foreground-muted">
                  <ArrowLeft className="mr-2 h-4 w-4" aria-hidden />
                  Back to dashboard
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-void min-h-[calc(100vh-4rem)]">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 py-8 sm:py-12">
        <PropertyForm />
      </div>
    </div>
  );
}
