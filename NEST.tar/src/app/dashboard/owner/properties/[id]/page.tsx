import { getAuthenticatedProfile, getProperty } from "@/lib/properties";
import { PropertyForm } from "@/components/property/property-form";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ArrowLeft, AlertCircle } from "lucide-react";
import type { VisionAnalysis } from "@/lib/ai/schemas";

export default async function EditPropertyPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  let profile;
  try {
    profile = await getAuthenticatedProfile();
  } catch {
    return (
      <div className="bg-void min-h-[calc(100vh-4rem)]">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 py-12">
          <Card className="bg-card-surface border-divider">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-warning" aria-hidden />
                Supabase not configured
              </CardTitle>
              <CardDescription className="text-foreground-muted">
                Editing a property requires Supabase credentials. Phase 2 is
                wired and ready — copy <code className="text-foreground">.env.example</code> to
                <code className="text-foreground"> .env.local</code>, fill in your Supabase
                keys, and apply migrations.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/dashboard/owner">
                <Button variant="outline" className="border-divider text-foreground-muted">
                  <ArrowLeft className="mr-2 h-4 w-4" aria-hidden />
                  Back to dashboard
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="bg-void min-h-[calc(100vh-4rem)]">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 py-12">
          <Card className="bg-card-surface border-divider">
            <CardHeader>
              <CardTitle className="text-foreground">Sign in required</CardTitle>
              <CardDescription className="text-foreground-muted">
                You need to be signed in as an owner to edit a property.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/auth/login">
                <Button className="btn-primary-gradient">Sign in</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (profile.role !== "owner") {
    return (
      <div className="bg-void min-h-[calc(100vh-4rem)]">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 py-12">
          <Card className="bg-card-surface border-divider">
            <CardHeader>
              <CardTitle className="text-foreground">Owner role required</CardTitle>
              <CardDescription className="text-foreground-muted">
                Only owner accounts can edit properties. Your current role is{" "}
                <code className="text-foreground">{profile.role}</code>.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/dashboard">
                <Button variant="outline" className="border-divider text-foreground-muted">
                  <ArrowLeft className="mr-2 h-4 w-4" aria-hidden />
                  Back to dashboard
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const property = await getProperty(id);
  if (!property) {
    return (
      <div className="bg-void min-h-[calc(100vh-4rem)]">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 py-12">
          <Card className="bg-card-surface border-divider">
            <CardHeader>
              <CardTitle className="text-foreground">Property not found</CardTitle>
              <CardDescription className="text-foreground-muted">
                This property doesn't exist or you don't have access to it.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/dashboard/owner/properties">
                <Button variant="outline" className="border-divider text-foreground-muted">
                  <ArrowLeft className="mr-2 h-4 w-4" aria-hidden />
                  Back to properties
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }
  if (property.owner_id !== profile.id) {
    return (
      <div className="bg-void min-h-[calc(100vh-4rem)]">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 py-12">
          <Card className="bg-card-surface border-divider">
            <CardHeader>
              <CardTitle className="text-foreground">Not your property</CardTitle>
              <CardDescription className="text-foreground-muted">
                You can only edit properties you own.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/dashboard/owner/properties">
                <Button variant="outline" className="border-divider text-foreground-muted">
                  <ArrowLeft className="mr-2 h-4 w-4" aria-hidden />
                  Back to properties
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-void min-h-[calc(100vh-4rem)]">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 py-8 sm:py-12">
        <Link href="/dashboard/owner/properties" className="inline-flex items-center text-sm text-foreground-muted hover:text-foreground mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" aria-hidden />
          Back to properties
        </Link>
        <PropertyForm
          propertyId={property.id}
          initial={{
            title: property.title,
            description: property.description ?? undefined,
            bedrooms: property.bedrooms,
            bathrooms: Number(property.bathrooms),
            max_guests: property.max_guests,
            base_price_minor: property.base_price_minor,
            min_price_minor: property.min_price_minor,
            max_price_minor: property.max_price_minor,
            currency: property.currency,
            cleaning_fee_minor: property.cleaning_fee_minor,
            status: property.status === "listed" ? "listed" : "draft",
            amenities: property.amenities,
            photos: property.photos,
            vision_status: property.vision_status,
            vision_analysis: (property.vision_analysis as unknown as VisionAnalysis) ?? null,
            vision_model: property.vision_model,
            vision_analyzed_at: property.vision_analyzed_at,
            vision_schema_version: property.vision_schema_version,
            latitude: property.latitude,
            longitude: property.longitude,
          }}
        />
      </div>
    </div>
  );
}
