import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { GuestDashboardEmptyStates } from "@/components/dashboard/empty-states";

export default function GuestDashboardPage() {
  return (
    <DashboardShell role="guest">
      <GuestDashboardEmptyStates />
    </DashboardShell>
  );
}
