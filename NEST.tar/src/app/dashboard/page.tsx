import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { AlertCircle, ArrowLeft } from "lucide-react";

export default async function DashboardIndex() {
  let supabase: Awaited<ReturnType<typeof createClient>>;
  try {
    supabase = await createClient();
  } catch {
    return (
      <div className="bg-void min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4">
        <Card className="bg-card-surface border-divider max-w-lg w-full">
          <CardHeader>
            <CardTitle className="text-foreground flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-warning" aria-hidden />
              Supabase not configured
            </CardTitle>
            <CardDescription className="text-foreground-muted">
              The dashboard requires Supabase credentials to authenticate
              users. Phase 1 is wired and ready — you just need to plug in
              your project keys.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ol className="list-decimal list-inside space-y-2 text-sm text-foreground-muted">
              <li>Copy <code className="text-foreground">.env.example</code> to <code className="text-foreground">.env.local</code>.</li>
              <li>Fill in <code className="text-foreground">NEXT_PUBLIC_SUPABASE_URL</code> and <code className="text-foreground">NEXT_PUBLIC_SUPABASE_ANON_KEY</code> from your Supabase Dashboard.</li>
              <li>Apply migrations: <code className="text-foreground">supabase db reset</code> against a clean local Supabase instance.</li>
              <li>Restart <code className="text-foreground">bun run dev</code>.</li>
            </ol>
            <div className="mt-6">
              <Link href="/">
                <Button variant="outline" className="border-divider text-foreground-muted">
                  <ArrowLeft className="mr-2 h-4 w-4" aria-hidden />
                  Back to home
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect("/auth/login");
  }

  const { data } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single();

  const role = (data as unknown as { role: string } | null)?.role;
  redirect(
    role === "owner"
      ? "/dashboard/owner"
      : role === "host"
      ? "/dashboard/host"
      : role === "admin"
      ? "/dashboard"
      : "/dashboard/guest"
  );
}
