import Link from "next/link";
import { notFound } from "next/navigation";
import { getProperty } from "@/lib/properties";
import { formatMinor } from "@/lib/money";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, BedDouble, Bath, Users, Eye, Sparkles, ShieldCheck, ArrowLeft, Calendar, AlertCircle } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function PropertyDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  let property;
  try {
    property = await getProperty(id);
  } catch {
    // Supabase not configured — show a friendly fallback rather than 500.
    return (
      <div className="bg-void min-h-[calc(100vh-4rem)]">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 py-12">
          <Card className="bg-card-surface border-divider">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-warning" aria-hidden />
                Supabase not configured
              </CardTitle>
              <CardDescription className="text-foreground-muted">
                Property detail pages come from Supabase. Phase 2 is wired and
                ready — copy <code className="text-foreground">.env.example</code> to
                <code className="text-foreground"> .env.local</code>, fill in your
                Supabase keys, and apply migrations.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/search">
                <Button variant="outline" className="border-divider text-foreground-muted">
                  <ArrowLeft className="mr-2 h-4 w-4" aria-hidden />
                  Back to search
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!property) notFound();

  // Public visibility gate per RLS rules.
  if (property.status !== "listed" && property.status !== "managed") {
    notFound();
  }

  const coverPhoto = property.cover_photo ?? property.photos[0] ?? null;
  const photoGallery = property.photos.length > 0 ? property.photos : [];

  // Per §0 rule 1: "can provide clearly labelled AI-assessed highlights
  // to guests; must never be presented as independently verified fact."
  // Guests see a redacted version (curated by /api/properties/[id] GET).
  // Here we render the same redacted view from the server.
  const vision = property.vision_analysis as Record<string, unknown> | null;
  const guestVision = vision
    ? {
        quality_tier: vision.quality_tier ?? null,
        notable_features: (vision.notable_features as string[] | undefined)?.slice(0, 5) ?? [],
        aesthetic_vibe: vision.aesthetic_vibe ?? null,
        estimated_size_bracket: vision.estimated_size_bracket ?? null,
        lighting_quality: vision.lighting_quality ?? null,
        confidence: vision.confidence ?? null,
      }
    : null;
  const hasVision = property.vision_status === "complete" && guestVision;

  return (
    <div className="bg-void min-h-[calc(100vh-4rem)]">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <Link href="/search" className="inline-flex items-center text-sm text-foreground-muted hover:text-foreground mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" aria-hidden />
          Back to search
        </Link>

        {/* Cover photo */}
        {coverPhoto && (
          <div className="aspect-[16/9] sm:aspect-[21/9] rounded-xl overflow-hidden bg-surface border border-divider mb-6">
            { }
            <img
              src={`/api/properties/${property.id}/photo?path=${encodeURIComponent(coverPhoto)}`}
              alt={property.title}
              className="h-full w-full object-cover"
            />
          </div>
        )}

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div>
              <div className="flex items-start justify-between gap-4">
                <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
                  {property.title}
                </h1>
                {property.status === "managed" && (
                  <Badge className="bg-gold-500/15 text-gold-500 border border-gold-500/40">
                    Professionally managed
                  </Badge>
                )}
              </div>
              <p className="text-sm text-foreground-muted mt-2 flex items-center gap-1">
                <MapPin className="h-3.5 w-3.5" aria-hidden />
                {property.address_json && typeof property.address_json === "object" && "city" in property.address_json
                  ? `${(property.address_json as Record<string, unknown>).city ?? ""}, ${(property.address_json as Record<string, unknown>).country ?? ""}`.replace(/^,\s*/, "") || "Location details on booking"
                  : "Location details provided on booking"}
              </p>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <DetailTile icon={<BedDouble className="h-4 w-4" aria-hidden />} label="Bedrooms" value={String(property.bedrooms)} />
              <DetailTile icon={<Bath className="h-4 w-4" aria-hidden />} label="Bathrooms" value={String(property.bathrooms)} />
              <DetailTile icon={<Users className="h-4 w-4" aria-hidden />} label="Max guests" value={String(property.max_guests)} />
            </div>

            {property.description && (
              <div>
                <h2 className="text-lg font-semibold text-foreground mb-2">About this property</h2>
                <p className="text-foreground-muted whitespace-pre-line leading-relaxed">
                  {property.description}
                </p>
              </div>
            )}

            {property.amenities.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold text-foreground mb-2">Amenities</h2>
                <div className="flex flex-wrap gap-2">
                  {property.amenities.map((a: string) => (
                    <Badge
                      key={a}
                      variant="secondary"
                      className="bg-surface text-foreground-muted border border-divider capitalize"
                    >
                      {a.replace(/_/g, " ")}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* AI-assessed highlights (guest view) */}
            {hasVision && guestVision && (
              <Card className="bg-card-surface border-divider">
                <CardHeader>
                  <CardTitle className="text-foreground flex items-center gap-2">
                    <Eye className="h-5 w-5 text-teal-500" aria-hidden />
                    AI-assessed highlights
                  </CardTitle>
                  <CardDescription className="text-foreground-muted">
                    Automated analysis of the property photos. Clearly labelled
                    as AI-assessed and never presented as independently verified
                    fact.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-sm">
                    {guestVision.quality_tier && (
                      <DetailRow label="Quality tier" value={titleCase(String(guestVision.quality_tier).replace(/_/g, " "))} />
                    )}
                    {guestVision.aesthetic_vibe && (
                      <DetailRow label="Aesthetic" value={titleCase(String(guestVision.aesthetic_vibe).replace(/_/g, " "))} />
                    )}
                    {guestVision.estimated_size_bracket && (
                      <DetailRow label="Size" value={titleCase(String(guestVision.estimated_size_bracket))} />
                    )}
                    {guestVision.lighting_quality && (
                      <DetailRow label="Lighting" value={titleCase(String(guestVision.lighting_quality))} />
                    )}
                    {guestVision.confidence && (
                      <DetailRow label="Confidence" value={titleCase(String(guestVision.confidence))} />
                    )}
                  </div>
                  {guestVision.notable_features.length > 0 && (
                    <div>
                      <p className="text-xs uppercase tracking-wider text-foreground-faint mb-2">Notable features</p>
                      <div className="flex flex-wrap gap-1.5">
                        {guestVision.notable_features.map((f) => (
                          <Badge
                            key={f}
                            variant="secondary"
                            className="bg-teal-500/10 text-teal-300 border border-teal-500/30"
                          >
                            {f}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                  <p className="pt-3 border-t border-divider text-xs text-foreground-faint">
                    <ShieldCheck className="inline h-3 w-3 mr-1" aria-hidden />
                    AI-generated assessment. Not a verified fact.
                  </p>
                </CardContent>
              </Card>
            )}

            {photoGallery.length > 1 && (
              <div>
                <h2 className="text-lg font-semibold text-foreground mb-3">Photos</h2>
                <ul className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {photoGallery.map((path: string, i: number) => (
                    <li
                      key={path}
                      className="aspect-square rounded-md overflow-hidden bg-surface border border-divider"
                    >
                      { }
                      <img
                        src={`/api/properties/${property.id}/photo?path=${encodeURIComponent(path)}`}
                        alt={`${property.title} — photo ${i + 1}`}
                        className="h-full w-full object-cover"
                      />
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Pricing + booking CTA sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-20 space-y-4">
              <Card className="bg-card-surface border-divider">
                <CardHeader>
                  <CardTitle className="text-foreground flex items-baseline gap-1">
                    {formatMinor(BigInt(property.base_price_minor), property.currency)}
                    <span className="text-sm text-foreground-faint">/night</span>
                  </CardTitle>
                  {property.cleaning_fee_minor > 0 && (
                    <CardDescription className="text-foreground-muted">
                      + {formatMinor(BigInt(property.cleaning_fee_minor), property.currency)} cleaning fee
                    </CardDescription>
                  )}
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="rounded-md border border-divider bg-surface p-3 text-sm text-foreground-muted">
                    <p className="flex items-center gap-1.5 mb-1">
                      <Calendar className="h-3.5 w-3.5" aria-hidden />
                      Booking &amp; payments
                    </p>
                    <p className="text-xs">
                      Booking flow, calendar availability, and Stripe checkout
                      ship in Phase 3 — Bookings + Payments. The deterministic
                      quote engine and live price calendar are also part of
                      Phase 3.
                    </p>
                  </div>
                  <Button className="btn-primary-gradient w-full" disabled>
                    Book this stay
                  </Button>
                  <p className="text-xs text-foreground-faint text-center">
                    Booking opens in Phase 3
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-card-surface border-divider">
                <CardHeader>
                  <CardTitle className="text-foreground text-base flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-gold-500" aria-hidden />
                    Trust &amp; safety
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-xs text-foreground-muted">
                    <li>Photos stored privately. Vision analysis is automated.</li>
                    <li>Host KYC required before accepting applications (Phase 4).</li>
                    <li>Delayed payouts protect all parties (Phase 3).</li>
                    <li>Disputes freeze payouts and trigger AI assessment (Phase 5).</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function DetailTile({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-md border border-divider bg-surface p-3 text-center">
      <div className="flex justify-center text-foreground-muted mb-1">{icon}</div>
      <p className="text-sm font-medium text-foreground">{value}</p>
      <p className="text-xs text-foreground-faint">{label}</p>
    </div>
  );
}

function DetailRow({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-foreground-faint">{label}</p>
      <p className="text-sm text-foreground">{value}</p>
    </div>
  );
}

function titleCase(s: string): string {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
