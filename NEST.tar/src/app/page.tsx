import Link from "next/link";
import { Compass, ShieldCheck, Sparkles, ArrowRight, Home as HomeIcon, Users, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function Home() {
  return (
    <div className="flex-1">
      {/* Hero */}
      <section className="relative overflow-hidden bg-void">
        <div
          aria-hidden
          className="absolute inset-0 opacity-30 pointer-events-none"
          style={{
            backgroundImage:
              "radial-gradient(circle at 15% 20%, rgba(255,122,69,0.35) 0%, transparent 40%), radial-gradient(circle at 85% 80%, rgba(20,184,166,0.35) 0%, transparent 40%)",
          }}
        />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28 lg:py-36">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-card border border-divider text-foreground-muted text-xs sm:text-sm mb-6">
              <Sparkles className="h-3.5 w-3.5 text-gold-500" aria-hidden />
              Vision-assisted property analysis · Phase 1 foundation live
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-foreground">
              A co-hosting marketplace{" "}
              <span className="bg-clip-text text-transparent" style={{
                backgroundImage: "linear-gradient(135deg, #FF7A45 0%, #14B8A6 100%)",
              }}>
                built for trust
              </span>
              .
            </h1>
            <p className="mt-6 text-lg sm:text-xl text-foreground-muted max-w-2xl leading-relaxed">
              Owners list properties. Hosts manage them. Guests book stays.
              Nest wires those three groups together with property vision analysis,
              KYC verification, deterministic pricing, delayed payouts, and
              human-oversight dispute adjudication.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-3">
              <Link href="/auth/signup">
                <Button className="btn-primary-gradient w-full sm:w-auto" size="lg">
                  Get started
                  <ArrowRight className="ml-2 h-4 w-4" aria-hidden />
                </Button>
              </Link>
              <Link href="/auth/login">
                <Button
                  variant="outline"
                  size="lg"
                  className="w-full sm:w-auto border-teal-500 text-teal-300 hover:bg-teal-500/10"
                >
                  Sign in
                </Button>
              </Link>
            </div>
            <p className="mt-4 text-xs text-foreground-faint">
              Admin role cannot be self-selected at signup. See{" "}
              <Link href="/docs" className="underline hover:text-foreground-muted">
                docs/SPEC.md §5.1
              </Link>
              .
            </p>
          </div>
        </div>
      </section>

      {/* Role cards */}
      <section className="bg-surface py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground">
              Three roles. One platform.
            </h2>
            <p className="mt-4 text-foreground-muted">
              Nest treats owners, hosts, and guests as first-class participants
              with different capabilities, dashboards, and trust requirements.
            </p>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            <RoleCard
              icon={<HomeIcon className="h-6 w-6 text-ember-500" aria-hidden />}
              title="Owners"
              description="Create properties, upload photos, review AI property analysis, receive host applications, control pricing, and receive payouts."
              ctaHref="/auth/signup?role=owner"
              ctaLabel="Sign up as owner"
              accent="ember"
            />
            <RoleCard
              icon={<Users className="h-6 w-6 text-teal-500" aria-hidden />}
              title="Hosts"
              description="Complete identity verification, discover eligible properties, apply to manage them, communicate with parties, and receive compensation."
              ctaHref="/auth/signup?role=host"
              ctaLabel="Sign up as host"
              accent="teal"
            />
            <RoleCard
              icon={<Star className="h-6 w-6 text-gold-500" aria-hidden />}
              title="Guests"
              description="Search properties, get deterministic quotes, book, pay, communicate, complete optional inspections, and leave reviews."
              ctaHref="/auth/signup?role=guest"
              ctaLabel="Sign up as guest"
              accent="gold"
            />
          </div>
        </div>
      </section>

      {/* Principles */}
      <section className="bg-void py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
            <Principle
              icon={<Compass className="h-5 w-5 text-teal-500" aria-hidden />}
              title="Vision is a core product capability"
              body="Every property listing with photographs is eligible for automated multimodal analysis. The analysis runs asynchronously, never blocks the owner's save operation, is schema-validated, versioned and auditable, contributes controlled signals to pricing, and is clearly labelled to guests."
            />
            <Principle
              icon={<ShieldCheck className="h-5 w-5 text-ember-500" aria-hidden />}
              title="AI does not control money"
              body="AI models never calculate, authorize, transfer, refund, or release money. For pricing, AI may return bounded classifications, multipliers, confidence and explanatory text. TypeScript performs all financial arithmetic. Every structured AI response must pass a Zod schema before application code can use it."
            />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-surface py-16 sm:py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground">
            Built vertically, phase by phase.
          </h2>
          <p className="mt-4 text-foreground-muted">
            Phase 1 ships the foundation: design system, role-based signup,
            server-enforced authorization, and adversarial tests that prove
            the security invariants hold. Subsequent phases add property + vision,
            bookings + payments, KYC + messaging, pricing + disputes, admin +
            n8n automation, and finally security + operations hardening.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row justify-center gap-3">
            <Link href="/auth/signup">
              <Button className="btn-primary-gradient" size="lg">
                Create your account
              </Button>
            </Link>
            <Link href="/docs">
              <Button variant="outline" size="lg" className="border-divider text-foreground-muted hover:bg-card">
                Read the spec
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

function RoleCard({
  icon,
  title,
  description,
  ctaHref,
  ctaLabel,
  accent,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  ctaHref: string;
  ctaLabel: string;
  accent: "ember" | "teal" | "gold";
}) {
  const accentBorder =
    accent === "ember"
      ? "hover:border-ember-500/60"
      : accent === "teal"
      ? "hover:border-teal-500/60"
      : "hover:border-gold-500/60";
  return (
    <Card className={`bg-card-surface border-divider ${accentBorder} transition-colors`}>
      <CardHeader>
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-md bg-surface border border-divider">{icon}</div>
          <CardTitle className="text-foreground">{title}</CardTitle>
        </div>
        <CardDescription className="text-foreground-muted pt-2">
          {description}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Link href={ctaHref}>
          <Button variant="link" className="px-0 text-teal-300 hover:text-teal-500">
            {ctaLabel}
            <ArrowRight className="ml-1 h-4 w-4" aria-hidden />
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}

function Principle({
  icon,
  title,
  body,
}: {
  icon: React.ReactNode;
  title: string;
  body: string;
}) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        {icon}
        <h3 className="text-lg font-semibold text-foreground">{title}</h3>
      </div>
      <p className="text-foreground-muted leading-relaxed">{body}</p>
    </div>
  );
}
