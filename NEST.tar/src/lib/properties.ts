/**
 * Property CRUD server helpers.
 *
 * Per docs/SPEC.md §5.2: properties have many sensitive fields
 * (assigned_host_id, vision_analysis, vision_model, vision_status,
 * moderation-sensitive status). The browser must NEVER directly
 * mutate these.
 *
 * Per 0003_safe_mutations.sql: REVOKE of client INSERT/UPDATE/DELETE
 * on properties means the anon client cannot write at all. All property
 * mutations go through this server boundary which uses the service-role
 * client (RLS-bypassing, server-only) after authenticating the user
 * and verifying authorization.
 *
 * This module exposes narrowly-scoped functions for each allowed
 * operation. They never accept arbitrary field sets from the client —
 * only explicitly allowed editable fields.
 */

import "server-only";
import { createClient } from "@/lib/supabase/server";
import { createServiceClient } from "@/lib/supabase/service";
import type { Profile } from "@/types";

export interface PropertyRow {
  id: string;
  owner_id: string;
  assigned_host_id: string | null;
  title: string;
  description: string | null;
  address_json: Record<string, unknown> | null;
  latitude: number | null;
  longitude: number | null;
  bedrooms: number;
  bathrooms: number;
  max_guests: number;
  amenities: string[];
  base_price_minor: number;
  min_price_minor: number;
  max_price_minor: number;
  currency: string;
  cleaning_fee_minor: number;
  status: "draft" | "listed" | "pending_host" | "managed" | "suspended";
  photos: string[];
  cover_photo: string | null;
  vision_analysis: Record<string, unknown> | null;
  vision_status: "pending" | "processing" | "complete" | "failed" | "stale";
  vision_analyzed_at: string | null;
  vision_model: string | null;
  vision_schema_version: number | null;
  vision_photos_hash: string | null;
  created_at: string;
  updated_at: string;
}

export interface PropertyCreateInput {
  title: string;
  description?: string;
  address_json?: Record<string, unknown>;
  latitude?: number;
  longitude?: number;
  bedrooms?: number;
  bathrooms?: number;
  max_guests?: number;
  amenities?: string[];
  base_price_minor: number;
  min_price_minor: number;
  max_price_minor: number;
  currency?: string;
  cleaning_fee_minor?: number;
  status?: "draft" | "listed";
}

export interface PropertyPatchInput {
  title?: string;
  description?: string;
  address_json?: Record<string, unknown>;
  latitude?: number;
  longitude?: number;
  bedrooms?: number;
  bathrooms?: number;
  max_guests?: number;
  amenities?: string[];
  base_price_minor?: number;
  min_price_minor?: number;
  max_price_minor?: number;
  currency?: string;
  cleaning_fee_minor?: number;
  status?: "draft" | "listed";
  photos?: string[];
  cover_photo?: string | null;
}

/**
 * Fetch the authenticated user's profile. Returns null if not signed in.
 * Server-side only — uses the cookie-scoped Supabase client.
 */
export async function getAuthenticatedProfile(): Promise<Profile | null> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data } = await supabase
    .from("profiles")
    .select(
      "id, email, role, full_name, avatar_path, bio, rating_avg, rating_count, kyc_status, kyc_verified_at, created_at, updated_at"
    )
    .eq("id", user.id)
    .single();
  return (data as unknown as Profile) ?? null;
}

/**
 * List all properties owned by a given user.
 */
export async function listOwnerProperties(ownerId: string): Promise<PropertyRow[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("properties")
    .select("*")
    .eq("owner_id", ownerId)
    .order("created_at", { ascending: false });
  if (error) throw new Error(`listOwnerProperties: ${error.message}`);
  return (data as unknown as PropertyRow[]) ?? [];
}

/**
 * List publicly listed properties (status in listed / managed).
 * Does not require authentication.
 */
export async function listPublicProperties(): Promise<PropertyRow[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("properties")
    .select("*")
    .in("status", ["listed", "managed"])
    .order("created_at", { ascending: false });
  if (error) throw new Error(`listPublicProperties: ${error.message}`);
  return (data as unknown as PropertyRow[]) ?? [];
}

/**
 * Fetch a single property. Returns null if not found or not visible
 * to the caller (RLS handles visibility).
 */
export async function getProperty(propertyId: string): Promise<PropertyRow | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("properties")
    .select("*")
    .eq("id", propertyId)
    .single();
  if (error) return null;
  return (data as unknown as PropertyRow) ?? null;
}

/**
 * Create a property. Uses the service-role client because RLS blocks
 * client INSERT on properties (per 0003_safe_mutations.sql) and we want
 * to set the owner_id explicitly to the authenticated user.
 *
 * The caller must already be authenticated as an owner.
 */
export async function createProperty(
  ownerId: string,
  input: PropertyCreateInput
): Promise<PropertyRow> {
  // Validate price band per §5.2: min_price <= base_price <= max_price
  if (input.min_price_minor > input.base_price_minor) {
    throw new Error("min_price_minor must be <= base_price_minor");
  }
  if (input.base_price_minor > input.max_price_minor) {
    throw new Error("base_price_minor must be <= max_price_minor");
  }
  if (input.base_price_minor <= 0) {
    throw new Error("base_price_minor must be > 0");
  }

  const supabase = createServiceClient();
  const { data, error } = await supabase
    .from("properties")
    .insert({
      owner_id: ownerId,
      title: input.title,
      description: input.description ?? null,
      address_json: input.address_json ?? {},
      latitude: input.latitude ?? null,
      longitude: input.longitude ?? null,
      bedrooms: input.bedrooms ?? 1,
      bathrooms: input.bathrooms ?? 1,
      max_guests: input.max_guests ?? 2,
      amenities: input.amenities ?? [],
      base_price_minor: input.base_price_minor,
      min_price_minor: input.min_price_minor,
      max_price_minor: input.max_price_minor,
      currency: input.currency ?? "USD",
      cleaning_fee_minor: input.cleaning_fee_minor ?? 0,
      status: input.status ?? "draft",
    })
    .select("*")
    .single();
  if (error) throw new Error(`createProperty: ${error.message}`);
  return data as unknown as PropertyRow;
}

/**
 * Update allowed fields on a property. Uses the service-role client
 * because RLS blocks client UPDATE on properties.
 *
 * The caller must verify ownership before invoking this. Only the
 * explicitly-listed editable fields in PropertyPatchInput are accepted —
 * assigned_host_id, vision_*, status='managed'|'pending_host'|'suspended'
 * are intentionally NOT settable here.
 */
export async function updateProperty(
  propertyId: string,
  ownerId: string,
  input: PropertyPatchInput
): Promise<PropertyRow> {
  // First verify the caller actually owns this property.
  const supabase = createServiceClient();
  const { data: existing, error: fetchErr } = await supabase
    .from("properties")
    .select("owner_id")
    .eq("id", propertyId)
    .single();
  if (fetchErr || !existing) {
    throw new Error("Property not found");
  }
  if (existing.owner_id !== ownerId) {
    throw new Error("NOT_AUTHORIZED: caller does not own this property");
  }

  // Validate price band if any price fields are being changed.
  const merged = {
    base_price_minor: input.base_price_minor ?? null,
    min_price_minor: input.min_price_minor ?? null,
    max_price_minor: input.max_price_minor ?? null,
  };
  if (
    merged.min_price_minor !== null &&
    merged.base_price_minor !== null &&
    merged.min_price_minor > merged.base_price_minor
  ) {
    throw new Error("min_price_minor must be <= base_price_minor");
  }
  if (
    merged.base_price_minor !== null &&
    merged.max_price_minor !== null &&
    merged.base_price_minor > merged.max_price_minor
  ) {
    throw new Error("base_price_minor must be <= max_price_minor");
  }

  // Build the patch object from ONLY the allowed fields.
  const patch: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(input)) {
    if (value !== undefined) {
      patch[key] = value;
    }
  }

  const { data, error } = await supabase
    .from("properties")
    .update(patch)
    .eq("id", propertyId)
    .select("*")
    .single();
  if (error) throw new Error(`updateProperty: ${error.message}`);
  return data as unknown as PropertyRow;
}

/**
 * Persist the result of vision analysis. Server-only — the browser
 * cannot write vision_analysis / vision_model / vision_status fields
 * (RLS + 0003_safe_mutations revokes client writes).
 */
export async function persistVisionAnalysis(
  propertyId: string,
  patch: {
    vision_analysis: Record<string, unknown>;
    vision_status: "complete" | "failed";
    vision_analyzed_at: string;
    vision_model: string | null;
    vision_schema_version: number | null;
    vision_photos_hash: string;
    vision_error?: string | null;
  }
): Promise<void> {
  const supabase = createServiceClient();
  const { error } = await supabase
    .from("properties")
    .update({
      vision_analysis: patch.vision_analysis,
      vision_status: patch.vision_status,
      vision_analyzed_at: patch.vision_analyzed_at,
      vision_model: patch.vision_model,
      vision_schema_version: patch.vision_schema_version,
      vision_photos_hash: patch.vision_photos_hash,
    })
    .eq("id", propertyId);
  if (error) {
    throw new Error(`persistVisionAnalysis: ${error.message}`);
  }
}

/**
 * Set vision_status to a transient state (pending / processing) without
 * touching the analysis payload.
 */
export async function setVisionStatus(
  propertyId: string,
  status: "pending" | "processing"
): Promise<void> {
  const supabase = createServiceClient();
  const { error } = await supabase
    .from("properties")
    .update({ vision_status: status })
    .eq("id", propertyId);
  if (error) {
    throw new Error(`setVisionStatus: ${error.message}`);
  }
}
