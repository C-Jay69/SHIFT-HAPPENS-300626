/**
 * Image resize + EXIF strip.
 *
 * Per docs/SPEC.md §7: "Re-encode uploaded property images server-side
 * before AI processing where practical. Do not trust the browser-provided
 * MIME type alone. Strip unnecessary image metadata, including EXIF
 * location information where appropriate."
 *
 * Per §9: "Limit number/size of images. Resize before model ingestion.
 * Use controlled image quality."
 */

import sharp from "sharp";

export const MAX_VISION_IMAGES = 20;
export const VISION_IMAGE_MAX_PX = 1600; // longest edge
export const VISION_JPEG_QUALITY = 85;

/**
 * Resize + re-encode an image buffer for vision submission.
 *
 * - Longest edge capped at VISION_IMAGE_MAX_PX.
 * - Re-encoded as JPEG at VISION_JPEG_QUALITY.
 * - EXIF and all metadata stripped.
 *
 * If the input is not a valid image (bad MIME, corrupt bytes), this
 * throws — callers should catch and treat as a per-image failure
 * (skipping that image and continuing with the others).
 *
 * Per §7: this is the actual MIME trust boundary. The browser can lie
 * about Content-Type, but sharp can only decode a real JPEG/PNG/WebP.
 */
export async function resizeImageForVision(
  input: Buffer
): Promise<Buffer> {
  return sharp(input, {
    // fail fast if the input is corrupt
    failOn: "truncated",
  })
    .rotate() // honor EXIF orientation before resize
    .resize(VISION_IMAGE_MAX_PX, VISION_IMAGE_MAX_PX, {
      fit: "inside",
      withoutEnlargement: true,
    })
    .jpeg({
      quality: VISION_JPEG_QUALITY,
      mozjpeg: true,
    })
    .toBuffer();
}

/**
 * Resize for storage (used during upload to keep the canonical stored
 * image reasonably sized, but without aggressive downscaling — we want
 * the original detail to remain for guest browsing).
 */
export async function resizeImageForStorage(
  input: Buffer
): Promise<Buffer> {
  return sharp(input, {
    failOn: "truncated",
  })
    .rotate()
    .resize(2048, 2048, {
      fit: "inside",
      withoutEnlargement: true,
    })
    .jpeg({
      quality: 90,
      mozjpeg: true,
    })
    .toBuffer();
}
