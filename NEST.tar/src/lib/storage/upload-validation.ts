/**
 * Upload validation.
 *
 * Per docs/SPEC.md §7:
 *   "Upload controls must validate:
 *     authenticated user,
 *     object ownership/path,
 *     MIME type,
 *     extension,
 *     file size,
 *     maximum image dimensions,
 *     number of files.
 *
 *   Re-encode uploaded property images server-side before AI processing
 *   where practical. Do not trust the browser-provided MIME type alone.
 *   Strip unnecessary image metadata, including EXIF location information
 *   where appropriate."
 */

import path from "node:path";

export const MAX_UPLOAD_FILES = 20;
export const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024; // 10 MiB
export const MAX_IMAGE_DIMENSION_PX = 4096;
export const ALLOWED_MIME_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
] as const;
export const ALLOWED_EXTENSIONS = [".jpg", ".jpeg", ".png", ".webp"] as const;

export interface UploadValidationResult {
  ok: boolean;
  errors: string[];
}

/**
 * Validate a single file's metadata (MIME type, size, extension).
 *
 * This function does NOT verify MIME magic bytes — that happens inside
 * `resizeImageForVision` (which uses sharp to actually decode the image).
 * Here we just do the cheap checks that don't require reading the file.
 *
 * Per §7: "Do not trust the browser-provided MIME type alone." The
 * sharp decode in resize.ts is the actual MIME trust boundary.
 */
export function validateFileMetadata(
  file: { name: string; type: string; size: number },
  options?: { maxFiles?: number; maxBytes?: number }
): UploadValidationResult {
  const errors: string[] = [];

  // Extension check
  const ext = path.extname(file.name).toLowerCase();
  if (!(ALLOWED_EXTENSIONS as readonly string[]).includes(ext)) {
    errors.push(
      `File "${file.name}" has disallowed extension "${ext}". Allowed: ${ALLOWED_EXTENSIONS.join(", ")}`
    );
  }

  // MIME type check (browser-reported; verified by sharp later)
  if (!(ALLOWED_MIME_TYPES as readonly string[]).includes(file.type as any)) {
    errors.push(
      `File "${file.name}" has disallowed MIME type "${file.type}". Allowed: ${ALLOWED_MIME_TYPES.join(", ")}`
    );
  }

  // Size check
  const maxBytes = options?.maxBytes ?? MAX_FILE_SIZE_BYTES;
  if (file.size > maxBytes) {
    errors.push(
      `File "${file.name}" is ${(file.size / 1024 / 1024).toFixed(2)} MiB. Max: ${maxBytes / 1024 / 1024} MiB.`
    );
  }
  if (file.size === 0) {
    errors.push(`File "${file.name}" is empty.`);
  }

  return { ok: errors.length === 0, errors };
}

/**
 * Validate a batch of files: individual metadata + total file count.
 */
export function validateFileBatch(
  files: Array<{ name: string; type: string; size: number }>,
  options?: { maxFiles?: number; maxBytes?: number }
): UploadValidationResult {
  const maxFiles = options?.maxFiles ?? MAX_UPLOAD_FILES;
  const errors: string[] = [];

  if (files.length === 0) {
    errors.push("No files provided.");
  }
  if (files.length > maxFiles) {
    errors.push(
      `Too many files: ${files.length}. Max: ${maxFiles}.`
    );
  }

  for (const f of files) {
    const r = validateFileMetadata(f, options);
    if (!r.ok) errors.push(...r.errors);
  }

  return { ok: errors.length === 0, errors };
}

/**
 * Verify that a property photo storage path matches the expected
 * shape: properties/{propertyId}/{uuid}.jpg
 *
 * Used by /api/properties/[id]/upload to reject attempts to upload to
 * an arbitrary path.
 *
 * Per §7: "Never trust a client-supplied propertyId without checking
 * ownership first."
 */
export function isValidPropertyPhotoPath(
  objectPath: string,
  expectedPropertyId: string
): boolean {
  const parts = objectPath.split("/");
  if (parts.length !== 3) return false;
  if (parts[0] !== "properties") return false;
  if (parts[1] !== expectedPropertyId) return false;
  const fileName = parts[2];
  // UUID-like filename with allowed extension
  const ext = path.extname(fileName).toLowerCase();
  if (!(ALLOWED_EXTENSIONS as readonly string[]).includes(ext)) return false;
  const base = fileName.slice(0, -ext.length);
  // Loose UUID check (handles both v4 dashes and stripped)
  return /^[a-f0-9-]{8,36}$/i.test(base);
}
