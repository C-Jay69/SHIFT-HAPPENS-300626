/**
 * Signed URL helpers for private Supabase Storage objects.
 *
 * Per docs/SPEC.md §5.2: "Do not persist signed URLs."
 * Per §7: "Signed URLs should use short lifetimes. Never log signed URLs
 * containing access tokens."
 */

import { createServiceClient } from "@/lib/supabase/service";

const DEFAULT_SIGNED_URL_TTL_SEC = 60; // 1 minute

/**
 * Generate a short-lived signed URL for a single private storage object.
 * Returns null if the object cannot be resolved (does not throw — caller
 * should treat null as "image not available").
 *
 * Per §7: signed URLs use short lifetimes. The default is 60 seconds —
 * long enough for a page render, short enough that a leaked URL becomes
 * useless quickly. The client never persists these URLs in the database
 * or in localStorage.
 */
export async function createSignedUrl(
  bucket: string,
  objectPath: string,
  ttlSec: number = DEFAULT_SIGNED_URL_TTL_SEC
): Promise<string | null> {
  const supabase = createServiceClient();
  const { data, error } = await supabase.storage
    .from(bucket)
    .createSignedUrl(objectPath, ttlSec);

  if (error || !data?.signedUrl) {
    return null;
  }
  return data.signedUrl;
}

/**
 * Generate signed URLs for a batch of objects in the same bucket.
 * More efficient than calling createSignedUrl one at a time.
 */
export async function createSignedUrls(
  bucket: string,
  objectPaths: string[],
  ttlSec: number = DEFAULT_SIGNED_URL_TTL_SEC
): Promise<(string | null)[]> {
  if (objectPaths.length === 0) return [];

  const supabase = createServiceClient();
  const { data, error } = await supabase.storage
    .from(bucket)
    .createSignedUrls(objectPaths, ttlSec);

  if (error || !data) {
    // If batch fails, fall back to per-item so a single bad object
    // doesn't blackhole the whole batch.
    return Promise.all(
      objectPaths.map((p) => createSignedUrl(bucket, p, ttlSec))
    );
  }

  // Supabase returns the array in the same order as the input paths.
  return data.map((item) => item?.signedUrl ?? null);
}

export const SIGNED_URL_DEFAULT_TTL_SEC = DEFAULT_SIGNED_URL_TTL_SEC;
