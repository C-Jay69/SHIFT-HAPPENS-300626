/**
 * Browser Supabase client (anon key, RLS-enforced).
 *
 * Use this in client components. It is subject to RLS — it can only do
 * what the user's role allows. It MUST NEVER be used with the service-role
 * key. Service-role operations belong in src/lib/supabase/service.ts and
 * may only be imported by server modules.
 */

import { createBrowserClient } from '@supabase/ssr';

export function createClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !anonKey) {
    throw new Error(
      'Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY. ' +
      'Copy .env.example to .env.local and fill in your Supabase project credentials.'
    );
  }

  return createBrowserClient(url, anonKey);
}
