/**
 * Service-role Supabase client (server-only, bypasses RLS).
 *
 * DANGER: This client can do anything. It MUST NEVER be imported by a
 * client component (any file with 'use client' or anything imported by one).
 * Use only in:
 *   - Server Actions / Route Handlers under /api/*
 *   - Server Components where elevated access is genuinely required
 *   - Cron / n8n-machinery routes
 *
 * Per docs/SPEC.md §20: "Service-role key: server only. A build/CI check
 * must look for accidental exposure."
 */

import { createClient } from '@supabase/supabase-js';

export function createServiceClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceRoleKey) {
    throw new Error(
      'Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY. ' +
      'The service-role client is server-only and requires these env vars.'
    );
  }

  return createClient(url, serviceRoleKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });
}
