/**
 * Money utilities for Nest.
 *
 * Money is stored as integer minor currency units (e.g. USD 123.45 = 12345).
 * All financial arithmetic in the application goes through these helpers.
 *
 * See docs/SPEC.md §3 (Configurable business policy) and §30 (Financial
 * invariants).
 */

export type Minor = bigint;

export interface SplitPercentages {
  ownerPct: number;
  hostPct: number;
  platformPct: number;
}

export interface Settlement {
  ownerMinor: Minor;
  hostMinor: Minor;
  platformMinor: Minor;
}

/**
 * Convert dollars + cents to integer minor units.
 * Throws if cents is outside 0–99.
 */
export function toMinor(amount: { dollars: number; cents: number }): Minor {
  if (!Number.isInteger(amount.dollars) || amount.dollars < 0) {
    throw new Error(`invalid dollars: ${amount.dollars}`);
  }
  if (!Number.isInteger(amount.cents) || amount.cents < 0 || amount.cents > 99) {
    throw new Error(`invalid cents: ${amount.cents}`);
  }
  return BigInt(amount.dollars) * 100n + BigInt(amount.cents);
}

/**
 * Convert minor units back to { dollars, cents } for display.
 */
export function fromMinor(m: Minor): { dollars: bigint; cents: bigint } {
  if (m < 0n) throw new Error('minor must be non-negative');
  return { dollars: m / 100n, cents: m % 100n };
}

/**
 * Format minor units as a localized currency string.
 */
export function formatMinor(m: Minor, currency = 'USD'): string {
  const { dollars, cents } = fromMinor(m);
  const centsStr = cents.toString().padStart(2, '0');
  return `${dollars.toString()}.${centsStr} ${currency}`;
}

/**
 * Deterministic settlement split.
 *
 * Distributes any residual cents (caused by integer division) onto the
 * largest share so the three components always sum to exactly settlementBaseMinor.
 *
 * Throws if the percentages do not sum to 100 or are negative.
 */
export function settle(baseMinor: Minor, split: SplitPercentages): Settlement {
  if (split.ownerPct < 0 || split.hostPct < 0 || split.platformPct < 0) {
    throw new Error('percentages must be non-negative');
  }
  const sum = split.ownerPct + split.hostPct + split.platformPct;
  if (Math.abs(sum - 100) > 0.0001) {
    throw new Error(`split must sum to 100, got ${sum}`);
  }

  // Multiply by 10000 to preserve 4 decimal places of percentage precision.
  const ownerRaw = (baseMinor * BigInt(Math.round(split.ownerPct * 10000))) / 1000000n;
  const hostRaw = (baseMinor * BigInt(Math.round(split.hostPct * 10000))) / 1000000n;
  const platformRaw = (baseMinor * BigInt(Math.round(split.platformPct * 10000))) / 1000000n;

  const computed = ownerRaw + hostRaw + platformRaw;
  const residual = baseMinor - computed;

  let ownerMinor = ownerRaw;
  let hostMinor = hostRaw;
  let platformMinor = platformRaw;

  if (residual !== 0n) {
    if (split.ownerPct >= split.hostPct && split.ownerPct >= split.platformPct) {
      ownerMinor += residual;
    } else if (split.hostPct >= split.platformPct) {
      hostMinor += residual;
    } else {
      platformMinor += residual;
    }
  }

  // Invariant: components must always reconcile.
  if (ownerMinor + hostMinor + platformMinor !== baseMinor) {
    throw new Error('settlement components do not reconcile');
  }

  return { ownerMinor, hostMinor, platformMinor };
}

/**
 * Refund guard — refund amount must never exceed total.
 *
 * The DB constraint `booking_refund_not_above_total` enforces this at the
 * database layer. The application must also check before issuing a refund
 * intent — never trust client-provided amounts.
 */
export function assertRefundWithinTotal(refundMinor: Minor, totalMinor: Minor): void {
  if (refundMinor < 0n) {
    throw new Error('refund must be non-negative');
  }
  if (refundMinor > totalMinor) {
    throw new Error(`refund ${refundMinor} exceeds total ${totalMinor}`);
  }
}

/**
 * Currency match guard.
 */
export function assertSameCurrency(a: string, b: string): void {
  if (a !== b) {
    throw new Error(`currency mismatch: ${a} vs ${b}`);
  }
}
