/**
 * Dispute AI arbitration module.
 *
 * Per docs/SPEC.md §13: "Use separately labelled before/after image
 * sets. The AI is instructed: compare only what is visible, do not
 * infer causation, identify uncertainty, reduce evidence confidence
 * when images are missing, do not invent repair costs."
 *
 * Output schema: DisputeAssessmentSchema (in schemas.ts).
 * The recommendation is advisory. It never moves money.
 *
 * Per §13: "The assessment endpoint requires: authenticated session,
 * booking/dispute relationship or admin authorization, authorized
 * private storage access, rate limiting. No arbitrary image URLs."
 *
 * The actual dispute-arbitration implementation ships in Phase 5 —
 * Pricing + Disputes. This file exists to:
 *   1. Hold the system prompt + aiJson() call site when Phase 5 lands.
 *   2. Make the spec-mandated file path exist (§8 lists src/lib/ai/arbitration.ts).
 *
 * Per §0 rule 7 ("no fake completeness"), this file does NOT contain
 * a working implementation yet — just the prompt scaffold + a clearly
 * marked TODO(phase-5) entry point that throws.
 */

import { aiJson } from "./structured";
import { DisputeAssessmentSchema, type DisputeAssessment } from "./schemas";

const DISPUTE_SYSTEM_PROMPT = `You are a dispute-assessment AI for the Nest co-hosting marketplace.
You receive before/after inspection photographs from a booking and must
return a structured JSON damage assessment.

Strict rules:
- Compare ONLY what is visible in the photos.
- Do NOT infer causation. Do NOT speculate about how damage occurred.
- If images are missing for either side, reduce evidence_quality and
  note the gap in rationale.
- Do NOT invent repair costs. recommended_award_pct is a percentage
  from 0 to 100 representing how much of the claimed amount the
  evidence supports — it is advisory only.
- Return ONLY valid JSON. No prose. No code fences.
- This assessment is ADVISORY. It never moves money. A human admin
  always makes the final adjudication.`;

export interface DisputeAssessmentRequest {
  disputeId: string;
  bookingId: string;
  claimAmountMinor: number;
  description: string;
  /** Storage paths under inspection-photos/inspections/{bookingId}/check_in/... */
  checkInPhotoPaths: string[];
  /** Storage paths under inspection-photos/inspections/{bookingId}/check_out/... */
  checkOutPhotoPaths: string[];
}

/**
 * Run dispute AI assessment.
 *
 * Ships in Phase 5 — Pricing + Disputes. The schema, system prompt,
 * and aiJson() boundary are already in place.
 */
export async function assessDispute(
  _req: DisputeAssessmentRequest
): Promise<DisputeAssessment> {
  // TODO(phase-5): wire the actual aiJson() call + private storage
  // downloads (same pattern as vision.ts).
  throw new Error(
    "assessDispute() is implemented in Phase 5 — Pricing + Disputes. " +
      "Phase 2 only ships vision. See docs/SPEC.md §13, §28."
  );
}

// Exported for Phase 5 reuse:
export { aiJson, DisputeAssessmentSchema, DISPUTE_SYSTEM_PROMPT };
