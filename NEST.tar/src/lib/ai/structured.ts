/**
 * Structured AI output boundary — single `aiJson()` entry point.
 *
 * Per docs/SPEC.md §0 rule 3: "Every structured AI response must pass a
 * Zod schema before application code can use it."
 *
 * Per §8.2: "Implement a single aiJson() boundary. Responsibilities:
 * call provider, extract structured JSON safely, parse JSON, validate
 * using Zod, retry bounded failures, optionally provide validation
 * feedback, try configured fallback provider, return validated output
 * plus model metadata.
 *
 * `JSON.parse` is allowed inside this controlled extraction layer because
 * JSON eventually has to be parsed. The rule is: no call site may
 * directly JSON.parse() untrusted model output."
 *
 * Per §8.3: every AI task records operational metadata (task type,
 * provider, model, start/end time, latency, success/failure, retry
 * count, schema version, approximate request size, token/usage metadata
 * when supplied, error category).
 */

import { z, ZodSchema } from "zod";
import {
  getProviderChain,
  type AIProvider,
  type ChatMessage,
  type VisionImageInput,
} from "./provider";

// ─── Types ──────────────────────────────────────────────────────

export interface AIJsonResult<T> {
  data: T;
  model: string;
  provider: string;
  usage?: { promptTokens?: number; completionTokens?: number };
  retries: number;
  latencyMs: number;
}

export interface AICallOptions {
  /** Schema to validate the parsed JSON against. */
  schema: ZodSchema;
  /** System prompt that describes the task and the required JSON shape. */
  systemPrompt: string;
  /** User prompt with the actual task payload. */
  userPrompt: string;
  /** Optional images to attach (vision tasks). */
  visionImages?: VisionImageInput[];
  /** Per-request timeout in ms. Default 30_000. */
  timeoutMs?: number;
  /** Sampling temperature. Default 0.2 for deterministic-ish tasks. */
  temperature?: number;
  /** Task type for observability — e.g. "vision_property_analysis". */
  taskType: string;
  /** Max retries on schema-validation failure before falling back. */
  maxRetries?: number;
}

export type AIErrorCategory =
  | "transport"
  | "timeout"
  | "empty_response"
  | "json_parse"
  | "schema_validation"
  | "no_provider_configured"
  | "unknown";

export class AIError extends Error {
  readonly category: AIErrorCategory;
  readonly provider: string;
  readonly model: string;
  readonly taskType: string;
  constructor(
    category: AIErrorCategory,
    message: string,
    opts: { provider: string; model: string; taskType: string }
  ) {
    super(message);
    this.name = "AIError";
    this.category = category;
    this.provider = opts.provider;
    this.model = opts.model;
    this.taskType = opts.taskType;
  }
}

// ─── Safe JSON extraction ───────────────────────────────────────
//
// Models sometimes wrap JSON in ```json fences or prefix it with
// chatty text like "Here is the result:". We try multiple strategies
// before giving up and falling back.

function extractJson(raw: string): unknown {
  // Strategy 1: direct parse (fast path for well-behaved providers).
  const trimmed = raw.trim();
  try {
    return JSON.parse(trimmed);
  } catch {
    // fall through
  }

  // Strategy 2: unwrap ```json ... ``` or ``` ... ``` fences.
  const fenceMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenceMatch) {
    try {
      return JSON.parse(fenceMatch[1].trim());
    } catch {
      // fall through
    }
  }

  // Strategy 3: find the first `{` and the last `}` and parse that
  // substring. Useful when the model emits chatty prefixes.
  const firstBrace = trimmed.indexOf("{");
  const lastBrace = trimmed.lastIndexOf("}");
  if (firstBrace >= 0 && lastBrace > firstBrace) {
    try {
      return JSON.parse(trimmed.slice(firstBrace, lastBrace + 1));
    } catch {
      // fall through
    }
  }

  // Strategy 4: same as above but for array-typed responses.
  const firstBracket = trimmed.indexOf("[");
  const lastBracket = trimmed.lastIndexOf("]");
  if (firstBracket >= 0 && lastBracket > firstBracket) {
    try {
      return JSON.parse(trimmed.slice(firstBracket, lastBracket + 1));
    } catch {
      // fall through
    }
  }

  throw new AIError(
    "json_parse",
    "Could not extract JSON from model response.",
    { provider: "unknown", model: "unknown", taskType: "extract" }
  );
}

// ─── aiJson boundary ────────────────────────────────────────────

export async function aiJson<T>(
  options: AICallOptions
): Promise<AIJsonResult<T>> {
  const chain: AIProvider[] = getProviderChain();
  const maxRetries = options.maxRetries ?? 2;
  let totalRetries = 0;

  for (let i = 0; i < chain.length; i++) {
    const provider = chain[i];
    let lastError: AIError | null = null;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      const startTime = Date.now();
      const messages: ChatMessage[] = [
        { role: "system", content: options.systemPrompt },
        { role: "user", content: options.userPrompt },
      ];

      try {
        const result = await provider.chat(messages, {
          visionImages: options.visionImages,
          timeoutMs: options.timeoutMs,
          temperature: options.temperature,
        });
        const latencyMs = Date.now() - startTime;

        // Per §8.2: JSON.parse is allowed inside this controlled layer.
        const parsed = extractJson(result.text);

        // Validate against the schema. Failure here means the model
        // produced something structurally wrong — retry with a hint
        // about what was wrong.
        const validation = options.schema.safeParse(parsed);
        if (validation.success) {
          // Normalize usage shape — providers may use snake_case
          // (prompt_tokens) or camelCase (promptTokens). Normalize to
          // camelCase for the caller.
          const rawUsage = result.usage as
            | { promptTokens?: number; completionTokens?: number; prompt_tokens?: number; completion_tokens?: number }
            | undefined;
          const usage = rawUsage
            ? {
                promptTokens: rawUsage.promptTokens ?? rawUsage.prompt_tokens,
                completionTokens: rawUsage.completionTokens ?? rawUsage.completion_tokens,
              }
            : undefined;
          return {
            data: validation.data as T,
            model: result.model,
            provider: provider.name,
            usage,
            retries: totalRetries,
            latencyMs,
          };
        }

        // Schema validation failed — give the model one more shot with
        // feedback about what was wrong.
        const errorMsg = validation.error.issues
          .slice(0, 5)
          .map((iss) => `  - path "${iss.path.join(".")}" ${iss.message}`)
          .join("\n");

        lastError = new AIError(
          "schema_validation",
          `Schema validation failed:\n${errorMsg}`,
          {
            provider: provider.name,
            model: result.model,
            taskType: options.taskType,
          }
        );
        totalRetries++;

        // If we have retries left, append a feedback message and loop.
        if (attempt < maxRetries) {
          messages.push({
            role: "assistant",
            content: result.text,
          });
          messages.push({
            role: "user",
            content:
              `Your previous response did not match the required JSON schema.\n` +
              `Errors:\n${errorMsg}\n\n` +
              `Please return only valid JSON matching the schema. No prose, no code fences.`,
          });
        }
      } catch (err) {
        const latencyMs = Date.now() - startTime;
        void latencyMs; // logged by caller via observability hooks

        if (err instanceof AIError) {
          lastError = err;
        } else if (err instanceof Error) {
          const msg = err.message.toLowerCase();
          const category: AIErrorCategory = msg.includes("timeout")
            ? "timeout"
            : msg.includes("empty")
            ? "empty_response"
            : "transport";
          lastError = new AIError(category, err.message, {
            provider: provider.name,
            model: provider.model,
            taskType: options.taskType,
          });
        } else {
          lastError = new AIError("unknown", String(err), {
            provider: provider.name,
            model: provider.model,
            taskType: options.taskType,
          });
        }
        totalRetries++;
      }
    }

    // Exhausted this provider's retries — try the next fallback.
    if (i < chain.length - 1 && lastError) {
      // Continue to next provider.
      continue;
    }
  }

  // All providers exhausted.
  throw new AIError(
    "schema_validation",
    `All providers exhausted for task "${options.taskType}". Last error: ${
      (await Promise.resolve()).toString()
    }`,
    { provider: "exhausted", model: "exhausted", taskType: options.taskType }
  );
}
