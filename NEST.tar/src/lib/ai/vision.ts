/**
 * Property vision pipeline.
 *
 * Per docs/SPEC.md §9:
 *   - Vision begins after property photographs change.
 *   - Compute a deterministic hash of the relevant image object identifiers.
 *   - If the hash differs from the last successfully analyzed set:
 *       vision_status = pending → processing → complete (or failed)
 *   - Limit number/size of images.
 *   - Resize before model ingestion. Strip EXIF. Use controlled quality.
 *   - Vision failure does not prevent the property from being saved/listed.
 *
 * Per §7: "Never allow AI routes to accept arbitrary remote image URLs
 * from users. Resolve authorized storage paths server-side to prevent
 * SSRF and unauthorized inference against third-party URLs."
 *
 * Per §8.2: every structured AI response passes through aiJson() —
 * never call JSON.parse on raw model output here.
 */

import { createHash } from "node:crypto";
import path from "node:path";
import { aiJson, AIError } from "./structured";
import {
  VisionAnalysisSchema,
  VISION_SCHEMA_VERSION,
  type VisionAnalysis,
} from "./schemas";
import { resizeImageForVision, MAX_VISION_IMAGES, VISION_IMAGE_MAX_PX } from "@/lib/storage/resize";
import { createServiceClient } from "@/lib/supabase/service";

// ─── Hash + version tracking ────────────────────────────────────

/**
 * Deterministic hash of the photo set. Two properties with the same
 * ordered set of photo paths produce the same hash.
 */
export function computePhotosHash(photoPaths: string[]): string {
  const sorted = [...photoPaths].sort();
  return createHash("sha256").update(sorted.join("\n")).digest("hex");
}

// ─── Vision analysis request ────────────────────────────────────

const VISION_SYSTEM_PROMPT = `You are a property analysis AI for the Nest co-hosting marketplace.
You receive property photographs and must return a structured JSON analysis.

Strict rules:
- Return ONLY valid JSON. No prose. No code fences. No commentary.
- Compare ONLY what is visible in the photos.
- Do NOT infer facts about the property that the photos do not show.
- If you cannot tell something, set confidence to "low" and explain why
  in visual_justification.
- condition_score, interior_modernity_score, curb_appeal_score are
  integers from 1 (very poor) to 10 (excellent).
- notable_features and red_flags are bounded arrays of short strings
  (max 80 chars each, max 20 items each).
- quality_tier is one of: budget, mid_range, premium, luxury.
- aesthetic_vibe is one of: modern_minimal, scandinavian, industrial,
  bohemian, coastal, traditional, mid_century, rustic, luxury, other.
- estimated_size_bracket is one of: studio, small, medium, large, estate.
- lighting_quality is one of: poor, fair, good, excellent.
- confidence is one of: low, medium, high.

The JSON must conform to this TypeScript type:

{
  "quality_tier": "budget" | "mid_range" | "premium" | "luxury",
  "condition_score": number,          // 1-10
  "interior_modernity_score": number, // 1-10
  "curb_appeal_score": number,        // 1-10
  "notable_features": string[],       // max 20 items, each max 80 chars
  "red_flags": string[],              // max 20 items, each max 80 chars
  "aesthetic_vibe": "modern_minimal" | "scandinavian" | "industrial" | "bohemian" | "coastal" | "traditional" | "mid_century" | "rustic" | "luxury" | "other",
  "estimated_size_bracket": "studio" | "small" | "medium" | "large" | "estate",
  "lighting_quality": "poor" | "fair" | "good" | "excellent",
  "visual_justification": string,     // max 2000 chars
  "confidence": "low" | "medium" | "high"
}`;

export interface VisionAnalysisRequest {
  propertyId: string;
  /** Storage paths, e.g. properties/{propertyId}/{uuid}.jpg */
  photoPaths: string[];
  /** Optional override of max images for testing. */
  maxImages?: number;
}

export interface VisionAnalysisResult {
  analysis: VisionAnalysis;
  model: string;
  provider: string;
  schemaVersion: number;
  photosHash: string;
  latencyMs: number;
  retries: number;
}

/**
 * Run vision analysis on a property's photos.
 *
 * Pre-conditions (enforced by the caller, NOT here):
 *   - Caller has verified they own or manage the property.
 *   - photoPaths are existing private storage objects under
 *     `properties/{propertyId}/...`.
 *
 * Per §7: this function NEVER accepts arbitrary remote image URLs.
 * It downloads authorized storage paths server-side using the
 * service-role client, resizes them, and submits the resized
 * base64 to the AI provider.
 */
export async function analyzePropertyVision(
  req: VisionAnalysisRequest
): Promise<VisionAnalysisResult> {
  if (req.photoPaths.length === 0) {
    throw new AIError(
      "schema_validation",
      "Cannot run vision analysis with zero photos.",
      { provider: "vision", model: "n/a", taskType: "vision_property_analysis" }
    );
  }

  const maxImages = Math.min(
    req.maxImages ?? MAX_VISION_IMAGES,
    MAX_VISION_IMAGES
  );

  if (req.photoPaths.length > maxImages) {
    // Truncate to the configured max — never fail because the owner
    // uploaded too many. Vision failure must not prevent the property
    // from being saved/listed (§9).
    req.photoPaths = req.photoPaths.slice(0, maxImages);
  }

  const photosHash = computePhotosHash(req.photoPaths);

  // Download all photos server-side. Per §7: never trust client-supplied
  // URLs. The paths come from the database (properties.photos) which
  // the owner cannot manipulate directly (RLS + 0003_safe_mutations).
  const serviceClient = createServiceClient();
  const visionImages: { base64: string; mimeType: string }[] = [];

  for (const objectPath of req.photoPaths) {
    try {
      const { data, error } = await serviceClient.storage
        .from("property-photos")
        .download(objectPath);

      if (error || !data) {
        // Skip this image but continue with the others. Vision is
        // best-effort — one missing image should not abort analysis.
        continue;
      }

      const buf = Buffer.from(await data.arrayBuffer());

      // Resize + strip EXIF + re-encode as JPEG.
      const resized = await resizeImageForVision(buf);

      visionImages.push({
        base64: resized.toString("base64"),
        mimeType: "image/jpeg",
      });

      // Hard cap on the number of images actually sent to the model.
      if (visionImages.length >= maxImages) break;
    } catch {
      // Continue with whatever we have. Vision failure is non-fatal.
    }
  }

  if (visionImages.length === 0) {
    throw new AIError(
      "transport",
      "Could not download any photos from storage for vision analysis.",
      { provider: "vision", model: "n/a", taskType: "vision_property_analysis" }
    );
  }

  const userPrompt =
    `Analyze the following ${visionImages.length} property photograph(s). ` +
    `Return a single JSON object matching the schema described in the system prompt. ` +
    `Focus on what is visible. Do not infer features that are not shown.`;

  const result = await aiJson<VisionAnalysis>({
    taskType: "vision_property_analysis",
    schema: VisionAnalysisSchema,
    systemPrompt: VISION_SYSTEM_PROMPT,
    userPrompt,
    visionImages,
    timeoutMs: 60_000,
    temperature: 0.2,
    maxRetries: 1,
  });

  return {
    analysis: result.data,
    model: result.model,
    provider: result.provider,
    schemaVersion: VISION_SCHEMA_VERSION,
    photosHash,
    latencyMs: result.latencyMs,
    retries: result.retries,
  };
}

/**
 * Convenience guard: is vision enabled in the environment?
 */
export function isVisionEnabled(): boolean {
  return (process.env.VISION_ENABLED ?? "true").toLowerCase() === "true";
}

/**
 * Re-export vision config for tests + UI.
 */
export { MAX_VISION_IMAGES, VISION_IMAGE_MAX_PX };
export { VISION_SCHEMA_VERSION };

/**
 * Bucket + path conventions. Used by storage helpers and tested.
 */
export const VISION_BUCKET = "property-photos";

export function propertyPhotoPath(propertyId: string, fileUuid: string): string {
  // Per docs/SPEC.md §7: "properties/{propertyId}/{uuid}.jpg"
  return path.posix.join("properties", propertyId, `${fileUuid}.jpg`);
}
