/**
 * Zod schemas for every structured AI response.
 *
 * Per docs/SPEC.md §0 rule 3: "Every structured AI response must pass a Zod
 * schema before application code can use it. Never trust model-generated
 * JSON directly."
 *
 * Per §31: "Every AI result is treated as untrusted input until validated."
 *
 * These schemas are the single source of truth — the AI provider layer
 * (structured.ts) and the task-specific modules (vision.ts, matching.ts,
 * arbitration.ts) all import from here. Tests/ai-validation.test.ts pins
 * the behaviour.
 */

import { z } from "zod";

// ─── Vision analysis (§9) ────────────────────────────────────────

export const QualityTier = z.enum(["budget", "mid_range", "premium", "luxury"]);
export const Confidence = z.enum(["low", "medium", "high"]);
export const AestheticVibe = z.enum([
  "modern_minimal",
  "scandinavian",
  "industrial",
  "bohemian",
  "coastal",
  "traditional",
  "mid_century",
  "rustic",
  "luxury",
  "other",
]);
export const SizeBracket = z.enum(["studio", "small", "medium", "large", "estate"]);
export const LightingQuality = z.enum(["poor", "fair", "good", "excellent"]);

export const VisionAnalysisSchema = z.object({
  quality_tier: QualityTier,
  condition_score: z.number().int().min(1).max(10),
  interior_modernity_score: z.number().int().min(1).max(10),
  curb_appeal_score: z.number().int().min(1).max(10),
  notable_features: z.array(z.string().max(80)).max(20),
  red_flags: z.array(z.string().max(80)).max(20),
  aesthetic_vibe: AestheticVibe,
  estimated_size_bracket: SizeBracket,
  lighting_quality: LightingQuality,
  visual_justification: z.string().max(2000),
  confidence: Confidence,
});

export type VisionAnalysis = z.infer<typeof VisionAnalysisSchema>;

// ─── Host matching (§12) ─────────────────────────────────────────

export const HostMatchSchema = z.object({
  score: z.number().min(0).max(100),
  strengths: z.array(z.string().max(300)).max(10),
  concerns: z.array(z.string().max(300)).max(10),
  reasoning: z.string().max(2000),
  recommendation: z.enum(["strong_fit", "good_fit", "marginal", "not_recommended"]),
});

export type HostMatch = z.infer<typeof HostMatchSchema>;

// ─── Dispute assessment (§13) ───────────────────────────────────

export const DisputeAssessmentSchema = z.object({
  damage_detected: z.boolean(),
  severity: z.enum(["none", "minor", "moderate", "major", "severe"]),
  itemised_findings: z
    .array(
      z.object({
        description: z.string().max(500),
        confidence: z.enum(["low", "medium", "high"]),
      })
    )
    .max(30),
  evidence_quality: z.enum(["insufficient", "limited", "adequate", "strong"]),
  recommended_award_pct: z.number().min(0).max(100),
  rationale: z.string().max(3000),
  requires_human_review: z.boolean(),
});

export type DisputeAssessment = z.infer<typeof DisputeAssessmentSchema>;

// ─── Pricing refinement (§10 Layer 3) ───────────────────────────
//
// The `adjustment_multiplier` is bounded here at the schema layer so a
// hallucinating model can never return an out-of-range multiplier.
// The deterministic TypeScript pricing code further clamps the result
// to the owner's floor/ceiling per §10.

export const PricingRefinementSchema = z.object({
  adjustment_multiplier: z.number().min(0.5).max(2.0),
  confidence: z.enum(["low", "medium", "high"]),
  rationale: z.string().max(2000),
  risk_factors: z.array(z.string().max(200)).max(10),
  reasoning_notes: z.string().max(3000),
});

export type PricingRefinement = z.infer<typeof PricingRefinementSchema>;

// ─── Vision schema versioning (§9) ───────────────────────────────
//
// Per §9: "Schema version must be stored." Bump this when the schema
// shape changes — old analyses will be re-queued automatically because
// `vision_schema_version` won't match the current version.

export const VISION_SCHEMA_VERSION = 1;
