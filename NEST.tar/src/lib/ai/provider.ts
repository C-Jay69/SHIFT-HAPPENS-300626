/**
 * Model-agnostic AI provider abstraction.
 *
 * Per docs/SPEC.md §0 rule 4: "No application feature may depend on a
 * specific AI model name. Model identifiers are configuration, not
 * application logic."
 *
 * Per §8: "Configuration: AI_PROVIDER, AI_MODEL, AI_API_KEY, AI_BASE_URL.
 * Optional fallback configuration: AI_FALLBACK_1_PROVIDER, AI_FALLBACK_1_MODEL,
 * AI_FALLBACK_2_PROVIDER, AI_FALLBACK_2_MODEL."
 *
 * Per §8.1: "Provider implementations expose capabilities such as
 * supportsVision, supportsStructuredOutput, maximum known image
 * constraints where available. Capability information may be configured
 * or probed. Never make pricing/business logic depend on a hard-coded
 * model context length."
 *
 * The initial implementation uses the `z-ai-web-dev-sdk` (ZAI in-house
 * SDK available in this environment) which provides a vision-capable
 * chat completions API. To swap to OpenRouter later, add a new
 * `OpenRouterProvider` class implementing the same `AIProvider` interface
 * and select it via `AI_PROVIDER` env var.
 */

import ZAI from "z-ai-web-dev-sdk";

// ─── Types ──────────────────────────────────────────────────────

export interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface VisionImageInput {
  /** base64-encoded image bytes WITHOUT the data: prefix. */
  base64: string;
  /** MIME type, e.g. "image/jpeg". */
  mimeType: string;
}

export interface AIProvider {
  readonly name: string;
  readonly model: string;
  readonly supportsVision: boolean;
  readonly supportsStructuredOutput: boolean;

  /**
   * Plain text chat completion. Returns the model's text response.
   * Throws on transport error. Used internally by aiJson(); not for
   * direct call sites.
   */
  chat(
    messages: ChatMessage[],
    options?: {
      visionImages?: VisionImageInput[];
      timeoutMs?: number;
      temperature?: number;
    }
  ): Promise<{
    text: string;
    model: string;
    usage?: { promptTokens?: number; completionTokens?: number };
  }>;
}

// ─── ZAI provider implementation ────────────────────────────────

interface ZAICapabilities {
  supportsVision: boolean;
  supportsStructuredOutput: boolean;
}

const ZAI_MODEL_CAPABILITIES: Record<string, ZAICapabilities> = {
  // ZAI's GLM-4.6 supports vision. The exact model string is configurable.
  "glm-4.6": { supportsVision: true, supportsStructuredOutput: true },
  "glm-4.5v": { supportsVision: true, supportsStructuredOutput: true },
  "glm-4v": { supportsVision: true, supportsStructuredOutput: true },
};

export class ZAIProvider implements AIProvider {
  readonly name: string;
  readonly model: string;
  readonly supportsVision: boolean;
  readonly supportsStructuredOutput: boolean;

  constructor(model: string) {
    this.name = "zai";
    this.model = model;
    const caps = ZAI_MODEL_CAPABILITIES[model.toLowerCase()];
    this.supportsVision = caps?.supportsVision ?? true;
    this.supportsStructuredOutput = caps?.supportsStructuredOutput ?? true;
  }

  async chat(
    messages: ChatMessage[],
    options?: {
      visionImages?: VisionImageInput[];
      timeoutMs?: number;
      temperature?: number;
    }
  ): Promise<{
    text: string;
    model: string;
    usage?: { promptTokens?: number; completionTokens?: number };
  }> {
    // z-ai-web-dev-sdk exposes a default export. The SDK is server-only
    // per the fullstack-dev skill — never import this module from a
    // client component.
    const zai = await ZAI.create();
    const timeoutMs = options?.timeoutMs ?? 30_000;
    const temperature = options?.temperature ?? 0.2;

    // Build the ZAI request. ZAI accepts OpenAI-shaped messages. For
    // vision, we attach images to the final user message.
    const zaiMessages: Array<{
      role: string;
      content:
        | string
        | Array<
            | { type: "text"; text: string }
            | { type: "image_url"; image_url: { url: string } }
          >;
    }> = messages.map((m) => ({
      role: m.role,
      content: m.content,
    }));

    if (options?.visionImages && options.visionImages.length > 0) {
      const lastUserIdx = zaiMessages
        .map((m) => m.role)
        .lastIndexOf("user");
      if (lastUserIdx >= 0) {
        const textContent = zaiMessages[lastUserIdx].content as string;
        zaiMessages[lastUserIdx].content = [
          { type: "text", text: textContent },
          ...options.visionImages.map((img) => ({
            type: "image_url" as const,
            image_url: {
              url: `data:${img.mimeType};base64,${img.base64}`,
            },
          })),
        ];
      }
    }

    // Race the SDK call against a timeout — never let a hung provider
    // block the application indefinitely. The caller (structured.ts)
    // also has its own retry budget.
    const completionPromise = zai.chat.completions.create({
      messages: zaiMessages as any,
      temperature,
      // ZAI does not require a model param if the SDK is configured with one,
      // but passing it explicitly makes the audit metadata unambiguous.
      model: this.model,
    });

    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(
        () => reject(new Error(`AI_REQUEST_TIMEOUT after ${timeoutMs}ms`)),
        timeoutMs
      );
    });

    const completion = (await Promise.race([
      completionPromise,
      timeoutPromise,
    ])) as {
      choices?: Array<{ message?: { content?: string } }>;
      model?: string;
      usage?: { prompt_tokens?: number; completion_tokens?: number };
    };

    const text = completion?.choices?.[0]?.message?.content ?? "";
    if (!text) {
      throw new Error("AI_EMPTY_RESPONSE");
    }

    return {
      text,
      model: completion?.model ?? this.model,
      usage: {
        promptTokens: completion?.usage?.prompt_tokens,
        completionTokens: completion?.usage?.completion_tokens,
      },
    };
  }
}

// ─── Provider registry / factory ────────────────────────────────

const PROVIDER_REGISTRY: Record<string, (model: string) => AIProvider> = {
  zai: (model) => new ZAIProvider(model),
  // Future: openrouter, ollama, etc. Each gets its own class implementing
  // the AIProvider interface. Selected via AI_PROVIDER env var.
};

/**
 * Resolve the primary configured provider.
 */
export function getProvider(): AIProvider {
  const providerName = (process.env.AI_PROVIDER ?? "zai").toLowerCase();
  const model = process.env.AI_MODEL;
  if (!model) {
    throw new Error("Missing AI_MODEL env var. See .env.example.");
  }
  const factory = PROVIDER_REGISTRY[providerName];
  if (!factory) {
    throw new Error(
      `Unknown AI_PROVIDER "${providerName}". Known: ${Object.keys(PROVIDER_REGISTRY).join(", ")}`
    );
  }
  return factory(model);
}

/**
 * Resolve the list of fallback providers (primary first, then configured
 * fallbacks). Used by structured.ts to try each in order until one
 * returns a schema-valid response.
 */
export function getProviderChain(): AIProvider[] {
  const chain: AIProvider[] = [];
  try {
    chain.push(getProvider());
  } catch {
    // Primary not configured — fall through to fallbacks.
  }

  for (const slot of ["1", "2"] as const) {
    const providerName = process.env[`AI_FALLBACK_${slot}_PROVIDER`]?.toLowerCase();
    const model = process.env[`AI_FALLBACK_${slot}_MODEL`];
    if (providerName && model) {
      const factory = PROVIDER_REGISTRY[providerName];
      if (factory) chain.push(factory(model));
    }
  }

  if (chain.length === 0) {
    throw new Error(
      "No AI provider configured. Set AI_PROVIDER + AI_MODEL at minimum. See .env.example."
    );
  }
  return chain;
}
