/**
 * Host matching AI module.
 *
 * Per docs/SPEC.md §12: "AI can score compatibility between a host and
 * property. Structured result: score, strengths, concerns, reasoning,
 * recommendation. The score is advisory. It must not auto-reject
 * applicants."
 *
 * The HostMatchSchema lives in src/lib/ai/schemas.ts and is already
 * pinned by tests/ai-validation.test.ts.
 *
 * The actual host-matching implementation ships in Phase 4 — Trust.
 * This file exists to:
 *   1. Hold the system prompt + aiJson() call site when Phase 4 lands,
 *      so the schema and observability story is consistent with vision.ts.
 *   2. Make the spec-mandated file path exist (§8 lists src/lib/ai/matching.ts).
 *
 * Per §0 rule 7 ("no fake completeness"), this file does NOT contain
 * a working implementation yet — just the prompt scaffold + a clearly
 * marked `TODO(phase-4)` entry point that throws.
 */

import { aiJson } from "./structured";
import { HostMatchSchema, type HostMatch } from "./schemas";

const HOST_MATCH_SYSTEM_PROMPT = `You are a host-property matching AI for the Nest co-hosting marketplace.
You receive a host profile and a property description and must return a
structured JSON compatibility assessment.

Strict rules:
- Focus ONLY on legitimate factors: availability, experience, location/service
  area, property-management skills, guest ratings, relevant track record,
  and the host's proposal text.
- Do NOT request or infer protected/sensitive personal traits that are
  irrelevant to hosting suitability.
- Return ONLY valid JSON. No prose. No code fences.
- score is a number from 0 to 100 (higher = better fit).
- recommendation is one of: strong_fit, good_fit, marginal, not_recommended.
- strengths and concerns are bounded arrays of short strings
  (max 300 chars each, max 10 items each).
- This assessment is ADVISORY. It must never automatically reject an
  applicant. A human owner always makes the final decision.`;

export interface HostMatchRequest {
  hostId: string;
  propertyId: string;
  hostPitchText: string;
  hostBio: string;
  hostRatingAvg: number | null;
  hostRatingCount: number;
  propertyTitle: string;
  propertyDescription: string;
  propertyLocation: string;
}

/**
 * Run host-property compatibility scoring.
 *
 * Ships in Phase 4 — Trust. The schema, system prompt, and aiJson()
 * boundary are already in place. Phase 4 will wire the database reads
 * + the n8n workflow trigger.
 */
export async function scoreHostMatch(
  _req: HostMatchRequest
): Promise<HostMatch> {
  // TODO(phase-4): wire the actual aiJson() call.
  // For now, throw so any accidental call surface is loud.
  throw new Error(
    "scoreHostMatch() is implemented in Phase 4 — Trust. " +
      "Phase 2 only ships vision. See docs/SPEC.md §12, §28."
  );
}

// Exported for Phase 4 reuse:
export { aiJson, HostMatchSchema, HOST_MATCH_SYSTEM_PROMPT };
