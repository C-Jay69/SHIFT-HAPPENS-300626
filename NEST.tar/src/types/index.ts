/**
 * Shared application types.
 */

export type UserRole = 'owner' | 'host' | 'guest' | 'admin';
export type KycState = 'none' | 'pending' | 'verified' | 'rejected' | 'expired';

export interface Profile {
  id: string;
  email: string;
  role: UserRole;
  full_name: string;
  avatar_path: string | null;
  bio: string | null;
  rating_avg: number | null;
  rating_count: number;
  kyc_status: KycState;
  kyc_verified_at: string | null;
  created_at: string;
  updated_at: string;
}

export const SIGNUP_ROLES: UserRole[] = ['owner', 'host', 'guest'];
