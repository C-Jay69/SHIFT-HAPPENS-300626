import { defineConfig } from "vitest/config";
import { fileURLToPath } from "node:url";
import path from "node:path";

const r = (p: string) => path.resolve(fileURLToPath(import.meta.url), "..", p);

export default defineConfig({
  test: {
    environment: "node",
    include: ["tests/**/*.test.ts"],
  },
  resolve: {
    alias: {
      "@": r("./src"),
    },
  },
});
