# Nest — Master Agent Instruction

You are implementing the Nest application.

Before changing code, read `docs/SPEC.md` in full.

`docs/SPEC.md` is the project's authoritative product and engineering specification.

## Hard rules

- Do not implement multiple build phases unless explicitly instructed.
- Do not create placeholder implementations for future phases.
- Do not modify `docs/SPEC.md` as a side effect of implementation.
- If a requested implementation conflicts with `docs/SPEC.md`, report the conflict before making the conflicting change.
- If a security-critical or money-critical requirement is genuinely ambiguous, do not invent a convenient implementation. Identify the ambiguity.

## Security invariants (non-negotiable)

- Never expose the Supabase service-role key to client code.
- Never trust client-provided ownership, roles, prices, payout values or KYC states.
- Never bypass RLS merely to make a feature work.
- Never let an AI response directly determine or move money.
- Every structured AI output must pass its Zod schema.
- Never directly parse model output outside the shared structured-output layer.
- Never hard-code an AI model identifier into application business logic.
- Never assume an external provider remains free.
- Never call delayed marketplace payments "escrow" unless the project specification has explicitly changed to a legally appropriate escrow product.
- Never accept arbitrary remote image URLs for AI processing.
- All financial operations must be idempotent.
- Stripe webhook signatures must be verified before events are trusted.
- Duplicate and out-of-order webhooks must be safe.
- Do not weaken database constraints to make tests pass.
- Do not weaken authorization policies to make a page work.
- Admin role cannot be self-selected at signup.

## Money representation

Money is stored as integer minor currency units (e.g. USD 123.45 = 12345).
All financial arithmetic uses the shared `src/lib/money.ts` utilities.
Payout percentages are snapshotted onto each booking/payout at transaction time.

## Phase protocol

Before implementing a phase:

1. Read the relevant sections of `docs/SPEC.md`.
2. Inspect the existing repository.
3. State which files need to be created or modified.
4. Identify migrations or environment variables required.
5. Identify security or payment implications.
6. Wait for approval if the human has requested approval-before-code mode.

After implementing:

- Run TypeScript checks.
- Run lint.
- Run applicable automated tests.
- Run the phase acceptance criteria.

Report:

- files changed,
- tests run,
- tests passed,
- known limitations,
- required manual configuration.

A phase is not complete if its Definition of Done fails.

## Current phase status

- **Phase 1 — Foundation**: IN PROGRESS (this session)
- Phase 2 — Property + Vision: NOT STARTED
- Phase 3 — Bookings + Payments: NOT STARTED
- Phase 4 — Trust (KYC, host applications, messaging, reviews): NOT STARTED
- Phase 5 — Pricing + Disputes: NOT STARTED
- Phase 6 — Admin + Automation (n8n): NOT STARTED
- Phase 7 — Security + Operations + Launch: NOT STARTED

## Phase 1 scope (current)

- 4 Supabase migrations (`0001_init.sql`, `0002_rls.sql`, `0003_safe_mutations.sql`, `0004_storage.sql`)
- Adversarial test suite (`tests/rls.test.ts`, `tests/concurrency.test.ts`, `tests/webhooks.test.ts`, `tests/authorization.test.ts`)
- Next.js foundation: strict TypeScript, Tailwind, design tokens (Warm Amber × Electric Teal), Supabase Auth, role-based signup (owner / host / guest — admin never selectable), landing page, responsive navigation, role dashboards with empty states
- `.env.example`, `docs/SPEC.md`, `CLAUDE.md`

Out of scope for Phase 1 (do NOT stub): pricing, bookings, vision pipeline, KYC flow UI, host applications, messaging, disputes, admin portal, n8n workflows.

## Design system

Theme: Warm Amber × Electric Teal.
- void: `#0B0F14`
- surface: `#141B24`
- card: `#1C242F`
- divider: `#2A3441`
- ember-500: `#FF7A45` / ember-300: `#FFB067`
- teal-500: `#14B8A6` / teal-300: `#5EEAD4`
- gold-500: `#F5B841`
- foreground: `#F5F7FA` / muted: `#B4BCC8` / faint: `#7A8494`
- success: `#22C55E` / warning: `#F5B841` / danger: `#EF4444`

Primary button: ember→teal gradient. Secondary button: teal outline. Verified badge: gold shield/check.

Responsive at 375 / 768 / 1440 px. WCAG-conscious contrast, visible focus states, reduced-motion compatible.

## Architecture notes

- Next.js App Router (no `pages/`).
- Server components by default; `'use client'` only when needed for interactivity.
- Supabase clients split into:
  - `src/lib/supabase/client.ts` — browser anon client (RLS-enforced).
  - `src/lib/supabase/server.ts` — server anon client (RLS-enforced, user-scoped).
  - `src/lib/supabase/service.ts` — service-role client (server-only, NEVER imported by client components).
- Profile mutations go through `public.update_my_profile()` RPC (defined in `0003_safe_mutations.sql`).
- Booking/payout/KYC/audit writes are server-only — no client INSERT/UPDATE/DELETE policies on those tables.
