-- NEST v5
-- 0004_storage.sql
--
-- Private storage buckets for property photos, inspection photos,
-- message media, and avatars. Clients do not upload directly into
-- these buckets; the Next.js server issues validated upload permissions
-- or performs controlled uploads after checking ownership, size, file
-- count and path format.

begin;

insert into storage.buckets (
  id,
  name,
  public,
  file_size_limit,
  allowed_mime_types
) values
(
  'property-photos',
  'property-photos',
  false,
  10485760,
  array[
    'image/jpeg',
    'image/png',
    'image/webp'
  ]
),
(
  'inspection-photos',
  'inspection-photos',
  false,
  10485760,
  array[
    'image/jpeg',
    'image/png',
    'image/webp'
  ]
),
(
  'message-media',
  'message-media',
  false,
  10485760,
  array[
    'image/jpeg',
    'image/png',
    'image/webp'
  ]
),
(
  'avatars',
  'avatars',
  true,
  5242880,
  array[
    'image/jpeg',
    'image/png',
    'image/webp'
  ]
)
on conflict (id) do nothing;

-- Path conventions enforced by the server (not by storage policies alone):
--
--   property-photos/properties/{propertyId}/{uuid}.jpg
--   inspection-photos/inspections/{bookingId}/{check_in|check_out}/{uuid}.jpg
--   message-media/threads/{threadId}/{uuid}.jpg
--   avatars/{userId}/{uuid}.jpg
--
-- The server MUST verify ownership before issuing an upload URL or
-- performing a controlled upload. Never trust a client-supplied
-- propertyId / bookingId / threadId without a server-side check.

commit;
