-- NEST v5
-- 0005_seed_dev.sql
--
-- Development-only seed data. Safe to skip in production.
-- This migration creates demo users ONLY when run against a Supabase
-- instance that has the auth schema available AND the standard
-- Supabase auth.admin functions. It is idempotent.

begin;

-- Note: real Supabase auth.users must be created via auth.admin.create_user
-- in a server-side script. This migration only seeds platform_settings
-- that may have been wiped during a db reset, and inserts documentation
-- rows into platform_settings explaining the seeded test users.

insert into public.platform_settings (key, value_json, description) values
(
  'dev_seed_users',
  '{
    "owner_alice": "alice+owner@nest.local",
    "owner_bob":   "bob+owner@nest.local",
    "host_hannah": "hannah+host@nest.local",
    "guest_george":"george+guest@nest.local",
    "guest_grace": "grace+guest@nest.local",
    "admin_adam":  "adam+admin@nest.local"
  }'::jsonb,
  'Documented demo user emails. Passwords distributed in docs/deploy.md. Do not use in production.'
)
on conflict (key) do nothing;

commit;
